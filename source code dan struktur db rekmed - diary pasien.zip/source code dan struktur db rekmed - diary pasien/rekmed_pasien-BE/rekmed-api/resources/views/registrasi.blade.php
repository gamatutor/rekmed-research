Selamat datang, {{$to}}
<br/>
<p>Anda berhasil terdaftar, namun ada satu langkah lagi yang perlu Anda lakukan, silakan klik tautan ini : {{$link}} dalam jangka waktu kurang dari 24 jam setelah email ini diterima untuk mengaktifkan akun Anda.</p>
<br/>
Terima kasih