Terima kasih telah melakukan pendaftaran, {{$to}}
<br/>
<p>Anda telah terdaftar sebagai pasien dengan detail sebagai berikut :</p>
<table>
	<tr>
		<td>Klinik</td>
		<td>{{$klinik}}</td>
	</tr>
	<tr>
		<td>Kode MR Pasien</td>
		<td>{{$mr}}</td>
	</tr>
	<tr>
		<td>Tanggal periksa</td>
		<td>{{$periksa}}</td>
	</tr>
</table>
<br/>
Terima kasih telah menggunakan layanan Rekmed Pasien.<br/>
<br/>
Jika Anda tidak merasa mendaftar sebagai pasien, atau ingin membatalkan pendaftaran pasien, silakan kunjungi link berikut dalam waktu kurang dari 24 jam sejak email ini diterima : <br/>
<a href="{{$link}}">{{$link}}</a>