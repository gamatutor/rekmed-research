<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$app->get('/', function () use ($app) {
    return $app->version();
});
// USER
$app->post('signup','User@signup');
$app->post('login','User@login');
$app->get('account/{id}','User@account');
$app->put('update/{id}','User@update');
$app->delete('delete/{id}','User@delete');
$app->post('change/{id}','User@changePassword');
$app->get('getprovinsi','User@getProvinsi');
$app->get('getkabupaten/{id}','User@getKabupaten');
$app->get('getkecamatan/{id}','User@getKecamatan');
$app->get('getkelurahan/{id}','User@getKelurahan');
$app->get('verify','User@verify');
$app->get('reverify','User@resendVerify');
$app->get('forget','User@forgetPassword');
$app->get('forgetverify','User@forgetVerify');
$app->post('forget','User@forgetSubmit');
$app->get('gettoken','User@getToken');
$app->post('fblogin','User@fbLogin');
// PATIENT
$app->get('patient/{id}','Patient@all');
$app->get('getpatient/{id}','Patient@get');
$app->post('patient','Patient@insert');
$app->put('patient/{id}','Patient@update');
$app->delete('patient/{id}','Patient@delete');

// DAFTAR ONLINE
$app->get('cekpasien/{id}','Integrasi@check');
$app->get('klinik','Integrasi@getKlinik');
$app->get('dokter/{id}','Integrasi@getDokter');
$app->post('syncpasien','Integrasi@sync');
$app->post('pasien','Integrasi@insertPasien');
$app->post('kunjungan/{mrcode}','Integrasi@insertKunjungan');
$app->get('batalkunjungan','Integrasi@abortVerify');

// PROMO
$app->get('promo/{id}','Promo@all');
$app->get('getpromo/{id}','Promo@get');
$app->post('promo','Promo@insert');
$app->put('promo/{id}','Promo@update');
$app->delete('promo/{id}','Promo@delete');
// RECORD
$app->get('record/{id}','Record@all');
$app->get('searchrecord/{id}','Record@search');
$app->get('getrecord/{id}','Record@get');
$app->post('record','Record@insert');
$app->put('record/{id}','Record@update');
$app->delete('record/{id}','Record@delete');
// REMINDER MEDICINE
$app->get('checkmedicine/{id}','Remindermedicine@check');
// REMINDER QUEUE
$app->get('checkqueue/{id}','Reminderqueue@check');
// TERM
$app->get('term','Term@get');
// UPDATE
$app->get('checkupdates/{id}','Update@check');
// CONSULT
$app->get('consult/{id}','Consult@all');
$app->get('getconsult/{id}','Consult@get');
$app->post('consult','Consult@insert');
$app->put('consult/{id}','Consult@update');
$app->delete('consult/{id}','Consult@delete');