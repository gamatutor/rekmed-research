<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use \App\library\Base62;

class Reminderqueue extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $response;

    public function __construct()
    {
        date_default_timezone_set('Asia/Jakarta');
    }

    public function check($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $this->response['message']="Gagal";
        $this->response['status']=0;
        $result=[];

        $today=date('Y-m-d');
        // $today="2016-09-05";

        $get_mr=app('db')->table('mobile_patient')->where('user_id','=',$id)->get();
        $mrs=[];
        $klinik_id=0;
        foreach ($get_mr as $row) {
            array_push($mrs, $row->mr);
        }

        // get line number
        $order = app('db')->table('kunjungan')
        ->where('klinik_id', '=', $klinik_id)
        ->where('tanggal_periksa', '=', $today)
        ->count()+1;

        // DOKTER BIASA  : (status = antri || status = diperiksa) && kunjungan.dokter_periksa = $user_session->id && DATE(jam_masuk) = >date('Y-m-d')
        $data=app('db')->table('kunjungan')
            ->whereIn('mr',$mrs)
            ->where(function($q){
              $q->where('status','=','antri')
              ->orWhere('status','=','diperiksa')
            })
            ->whereRaw("DATE('jam_masuk') >= '".date('Y-m-d')."'")
            ->orderBy('jam_masuk','desc');
        if($data->get()){
            $data=$data->first();
            $klinik_id=$data->klinik_id;
            $dokter_periksa=$data->dokter_periksa;

            $data=app('db')->table('kunjungan')
                ->where(function($q){
                  $q->where('status','=','antri')
                  ->orWhere('status','=','diperiksa')
                })
                ->whereRaw("DATE('jam_masuk') >= '".date('Y-m-d')."'")
                ->where('dokter_periksa','=',$dokter_periksa)
                ->orderBy('jam_masuk','asc')->get();
            if($data){
                // get from queue setting for specific klinik_id
                $seconds=app('db')->table('mobile_queue_setting')->where('klinik_id','=',$klinik_id)->where('active','=',1)->orderBy('id','desc')->first();
                if(empty($seconds)){
                    $timeToCall=date("H:i:s");
                    // $timeToCall=date("H:i:s",strtotime(date("H:i:s"))+360);
                    $timeAlert=date("H:i:s");
                    // $timeAlert=date("H:i:s",strtotime(date("H:i:s"))+60);
                    $result['show_time']="no";
                }else{
                    $jam_masuk=explode(" ", $seconds->jam_masuk)[1];
                    // $timeToCall=date("h:i:s",strtotime(date("H:i:s"))+$seconds*$order);
                    $timeToCall=date("H:i:s",strtotime($jam_masuk)+$seconds->avg_time*$order);
                    // alert 15 minutes before due time
                    $timeAlert=date("H:i:s",strtotime($timeToCall)-(15*60));
                    $result['show_time']="yes";
                }
            }else{
                $timeToCall=date("H:i:s");
                $timeAlert=date("H:i:s");
                $result['show_time']="no";
            }

            $result['order']=$order;
            $result['time_to_call']=$timeToCall;
            $result['time_alert']=$timeAlert;

            $this->response['message']="Berhasil";
            $this->response['data']=$result;
            $this->response['status']=1;
        }else{
            $this->response['message']="Tidak dapat menemukan kode MR yang cocok di antrian";
        }

        return json_encode($this->response);
    }
}
