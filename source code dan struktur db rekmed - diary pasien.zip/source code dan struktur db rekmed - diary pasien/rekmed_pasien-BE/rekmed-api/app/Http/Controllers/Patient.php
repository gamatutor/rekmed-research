<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use \App\library\Base62;

class Patient extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $response;

    public function __construct()
    {
        date_default_timezone_set('Asia/Jakarta');
    }

    public function all($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $data=app('db')->table('mobile_patient')->where('user_id','=',$id)->get();
        $result=[];
        foreach($data as $row){
            $local=[];
            $local['id']=$row->id;
            $local['mr']=$row->mr;
            array_push($result, $local);
        }
        $this->response['message']="Berhasil";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function get($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $data=app('db')->table('mobile_patient')->where('id','=',$id)->first();
        $result=[];
        $result['id']=$data->id;
        $result['mr']=$data->mr;
        
        $this->response['message']="Berhasil";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }    

    public function insert(Request $request){
        $user_id=$request->input('user_id');
        $mr=$request->input('mr');

        app('db')->table('mobile_patient')->insert([
                'user_id'       => $user_id,
                'mr'            => $mr,
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);
        $this->response['message']="Data ditambahkan";
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function update($id,Request $request){
        $base62=new Base62;
        $id=$base62->decode($id);

        $user_id=$request->input('user_id');
        $mr=$request->input('mr');
        
        $check=app('db')->table('mobile_patient')->where('id','=',$id)->count();
        if($check < 1){
            $this->response['message']  ="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            app('db')->table('mobile_patient')->where('id','=',$id)->update([
                'user_id'       => $user_id,
                'mr'            => $mr,
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);
            $this->response['message']="Data diperbarui";
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }

    public function delete($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $check=app('db')->table('mobile_patient')->where('id','=',$id)->count();
        if($check < 1){
            $this->response['message']  ="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            app('db')->table('mobile_patient')->where('id','=',$id)->delete();
            $this->response['message']="Data dihapus";
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }
}
