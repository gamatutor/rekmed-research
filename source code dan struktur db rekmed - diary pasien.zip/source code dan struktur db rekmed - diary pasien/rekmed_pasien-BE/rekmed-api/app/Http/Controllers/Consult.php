<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use \App\library\Base62;

class Consult extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $response;

    public function __construct()
    {
        date_default_timezone_set('Asia/Jakarta');
    }

    public function all($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $data=app('db')->table('mobile_consult')->where('user_id','=',$id)->get();
        $result=[];
        foreach($data as $row){
            $local=[];
            $local['id']=$row->id;
            $local['title']=$row->title;
            $local['due']=$row->due;
            if($row->active=='1'){
                if(strtotime(date('Y-m-d H:i:s')) > strtotime($row->due)){
                    $local['active']=0;
                }else{
                    $local['active']=1;
                }
            }else{
                $local['active']=$row->active;
            }
            array_push($result, $local);
        }
        $this->response['message']="Berhasil";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function get($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $data=app('db')->table('mobile_consult')->where('id','=',$id)->first();
        $result=[];
        $local['id']=$data->id;
        $local['title']=$data->title;
        $local['due']=$data->due;
        $local['active']=$data->active;
        
        $this->response['message']="Berhasil";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }    

    public function insert(Request $request){
        $user_id=$request->input('user_id');
        $title=$request->input('title');
        $due=$request->input('due');
        $active=$request->input('active');

        app('db')->table('mobile_consult')->insert([
                'user_id'       => $user_id,
                'title'         => $title,
                'due'           => $due,
                'active'        => $active,
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);
        $this->response['message']="Data ditambahkan";
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function update($id,Request $request){
        $base62=new Base62;
        $id=$base62->decode($id);

        $user_id=$request->input('user_id');
        $title=$request->input('title');
        $due=$request->input('due');
        $active=$request->input('active');
        
        $check=app('db')->table('mobile_consult')->where('id','=',$id)->count();
        if($check < 1){
            $this->response['message']  ="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            app('db')->table('mobile_consult')->where('id','=',$id)->update([
                'user_id'       => $user_id,
                'title'         => $title,
                'due'           => $due,
                'active'        => $active,
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);
            $this->response['message']="Data diperbarui";
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }

    public function delete($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $check=app('db')->table('mobile_consult')->where('id','=',$id)->count();
        if($check < 1){
            $this->response['message']  ="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            app('db')->table('mobile_consult')->where('id','=',$id)->delete();
            $this->response['message']="Data dihapus";
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }
}
