<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use \App\library\Base62;

class Remindermedicine extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $response;

    public function __construct()
    {
        date_default_timezone_set('Asia/Jakarta');
    }

    public function check($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $this->response['message']="FAILED";
        $this->response['status']=0;

        $today=date('Y-m-d');
        // $today="2016-09-05";

        $get_mr=app('db')->table('mobile_patient')->where('user_id','=',$id)->get();
        $mrs=[];
        $result=[];
        foreach ($get_mr as $row) {
            array_push($mrs, $row->mr);
        }

        $data=app('db')->table('rm_obat')
            ->join('rekam_medis','rekam_medis.rm_id','=','rm_obat.rm_id')
            ->whereIn('mr',$mrs)->get();
        foreach ($data as $row) {
            $local=[];
            $created=$row->created;
            $signa=explode("x", $row->signa)[0];
            $jumlah=$row->jumlah;
            $durasi=ceil($jumlah/$signa)*24*60*60;
            $expired=date("Y-m-d",strtotime($row->created)+$durasi);
            if(strtotime($expired)-strtotime($today) > 0){
                $local['expired']="no";
            }else{
                $local['expired']="yes";
                continue;
            }
            $local['expired_date']=$expired;
            $local['created']=$row->created;
            $local['dosis']=$row->signa;
            $local['nama_obat']=$row->nama_obat;
            $local['jumlah']=$row->jumlah;
            array_push($result, $local);
        }

        $this->response['message']="Berhasil";
        $this->response['data']=$result;
        $this->response['status']=1;

        return json_encode($this->response);
    }
}
