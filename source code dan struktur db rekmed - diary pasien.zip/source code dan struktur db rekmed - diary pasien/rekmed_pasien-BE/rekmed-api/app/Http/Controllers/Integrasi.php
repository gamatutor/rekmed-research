<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use \App\library\Base62;
use Illuminate\Support\Facades\Mail;

class Integrasi extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $response;

    public function __construct()
    {
        date_default_timezone_set('Asia/Jakarta');
    }

    public function sync(Request $request){
        $userId=$request->input('user_id');
        $klinikId=$request->input('klinik_id');

        $check=json_decode(self::check($userId,$klinikId));
        $mrCode;

        if ($check->status==0) {
            $insert=self::insertPasien($request);
            if(json_decode($insert)->status==0){
                return $insert;
            }
        }
        $check=json_decode(self::check($userId,$klinikId));

        $mrCode=$check->data;
        return self::insertKunjungan($mrCode,$request);
    }

    public function check($id,$klinikId){
        $base62=new Base62;
        $id=$base62->decode($id);

        $mrs=app('db')->table('mobile_patient')->where('user_id','=',$id)->get();
        $mrCode=0;
        foreach($mrs as $row){
            // check whether user defined mr code is exist in pasien table
            $check=app('db')->table('pasien')->where('mr','=',$row->mr)->count();
            if($check > 0){
                $getKlinikId=substr($row->mr, 0, -6);
                if((int)$getKlinikId == (int)$klinikId){
                    $mrCode=$row->mr;
                    break;
                }
            }
        }
        if($mrCode==0){
            $this->response['message']="Data tidak ditemukan";
            $this->response['status']=0;
        }else{
            $this->response['message']="Data ditemukan";
            $this->response['status']=1;
            $this->response['data']=$mrCode;
        }
        return json_encode($this->response);
    }

    public function getDokter($id){
        $base62=new Base62;
        $id=$base62->decode($id);
        $doctors=app('db')->table('user')
            ->select(['dokter.user_id', 'dokter.nama', 'spesialis.nama as spesialis', 'waktu_praktek'])
            ->join('dokter','dokter.user_id','=','user.id')
            ->leftJoin('spesialis','spesialis.spesialis_id','=','dokter.spesialis')
            ->where('klinik_id','=',$id)->where('user.email','<>','')->get();
        $result=[];
        foreach($doctors as $row){
            $local=[];
            $local['id']=$row->user_id;
            $local['nama']=$row->nama;
            $local['spesialis']=$row->spesialis;
            $local['waktu_praktek']=$row->waktu_praktek;
            array_push($result, $local);
        }

        $this->response['message']="Data ditemukan";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function getKlinik(Request $request){
        $page=1;
        $perPage=50;
        if($request->input('query')==null || $request->input('query')==""){
            if($request->input('page') > 1){
                $page=$request->input('page')-1;
                $data=app('db')->table('klinik')
                    ->where('klinik_nama','<>','')
                    ->where('alamat','<>','')
                    ->where('nomor_telp_1','<>','')
                    ->where('kepala_klinik','<>','')
                    ->limit($perPage)->offset(($perPage*$page)+1)->get();
            }else{
                $data=app('db')->table('klinik')
                    ->where('klinik_nama','<>','')
                    ->where('alamat','<>','')
                    ->where('nomor_telp_1','<>','')
                    ->where('kepala_klinik','<>','')
                    ->limit($perPage)->get();
            }
        }else{
            if($request->input('page') > 1){
                $page=$request->input('page')-1;
                $data=app('db')->table('klinik')
                    ->where('klinik_nama','<>','')
                    ->where('alamat','<>','')
                    ->where('nomor_telp_1','<>','')
                    ->where('kepala_klinik','<>','')
                    ->where('klinik_nama','like','%'.$request->input('query').'%')
                    ->orWhere('alamat','like','%'.$request->input('query').'%')
                    ->limit($perPage)
                    ->offset(($perPage*$page)+1)
                    ->get();
            }else{
                $data=app('db')->table('klinik')
                    ->where('klinik_nama','<>','')
                    ->where('alamat','<>','')
                    ->where('nomor_telp_1','<>','')
                    ->where('kepala_klinik','<>','')
                    ->where('klinik_nama','like','%'.$request->input('query').'%')
                    ->orWhere('alamat','like','%'.$request->input('query').'%')
                    ->limit($perPage)->get();
            }
        }

        $result=[];
        foreach($data as $row){
            $local=[];
            $local['id']=$row->klinik_id;
            $local['nama']=$row->klinik_nama;
            $local['alamat']=$row->alamat;
            $local['telp']=$row->nomor_telp_1;
            array_push($result, $local);
        }

        $this->response['message']="Data ditemukan";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function insertPasien(Request $request){
        $base62=new Base62;
        $userId=$base62->decode($request->input('user_id'));
        $klinikId=$request->input('klinik_id');

        $check=app('db')->table('mobile_user')->where('id','=',$userId)->count();
        if($check < 1){
            $this->response['message']="Akun tidak ditemukan";
            $this->response['status']=0;
        }else{
            $user=app('db')->table('mobile_user')->where('id','=',$userId)->first();

            if($user->kelurahan_id==null){
                $this->response['message']="Silakan lengkapi profil Anda terlebih dahulu";
                $this->response['status']=0;
            }else{
                $pasien=app('db')->table('pasien')->where('klinik_id','=',$klinikId)->orderBy('mr','desc')->first();
                if(empty($pasien)){
                    $nextMr=$klinikId."000001";
                }else{
                    $nextMr=(int)$pasien->mr+1;
                }
                if($user->gender==0){
                    $jk='Perempuan';
                }else{
                    $jk='Laki-Laki';
                }
                $kelurahan=app('db')->table('mobile_ref_kelurahan')->where('id','=',$user->kelurahan_id)->first()->kelurahan;
                $kecamatan=app('db')->table('mobile_ref_kecamatan')->where('id','=',substr($user->kelurahan_id,0,7))->first()->kecamatan;
                $kabupaten=app('db')->table('mobile_ref_kabupaten')->where('id','=',substr($user->kelurahan_id,0,4))->first()->kabupaten;
                $provinsi=app('db')->table('mobile_ref_provinsi')->where('id','=',substr($user->kelurahan_id,0,2))->first()->provinsi;

                app('db')->table('pasien')->insert([
                    'mr'            =>  $nextMr,
                    'klinik_id'     =>  $klinikId,
                    'nama'          =>  $user->name,
                    'tanggal_lahir' =>  $user->birth_at,
                    'jk'            =>  $jk,
                    'alamat'        =>  $user->address.', '.$kelurahan.', '.$kecamatan.', '.$kabupaten.', '.$provinsi,
                    'no_telp'       =>  $user->phone,
                    'created'       =>  date('Y-m-d H:i:s'),
                    'modified'      =>  date('Y-m-d H:i:s'),
                    'user_input'    =>  'android',
                    'user_modified' =>  'android',
                ]);
                app('db')->table('mobile_patient')->insert([
                    'user_id'       =>  $userId,
                    'mr'            =>  $nextMr,
                    'created_at'    =>  date('Y-m-d H:i:s'),
                    'updated_at'    =>  date('Y-m-d H:i:s'),
                ]);
                $this->response['message']="Berhasil menambahkan pasien";
                $this->response['status']=1;
            }
        }
        return json_encode($this->response);
    }

    public function insertKunjungan($mrCode, Request $request){
        $firstUser=app('db')->table('user')->orderBy('id','asc')->first();
        $tglPeriksa=explode(' ', $request->input('tanggal_periksa'))[0];
        $check=app('db')->table('kunjungan')
            ->where('klinik_id','=',$request->input('klinik_id'))
            ->where('mr','=',$mrCode)
            ->where('tanggal_periksa','=',$tglPeriksa)
            // ->where('jam_masuk','=',$request->input('tanggal_periksa'))
            ->count();
        if($check > 0){
            $this->response['message']="Anda sudah pernah terdaftar sebelumnya";
            $this->response['status']=0;
            return json_encode($this->response);
        }

        app('db')->table('kunjungan')->insert([
            'klinik_id'         =>  $request->input('klinik_id'),
            'dokter_periksa'    =>  $request->input('dokter_id'),
            'mr'                =>  $mrCode,
            'tanggal_periksa'   =>  $request->input('tanggal_periksa'),
            'jam_masuk'         =>  $request->input('tanggal_periksa'),
            'status'            =>  'antri',
            'created'           =>  date('Y-m-d H:i:s'),
            'user_input'        =>  'android',
            'user_id'           =>  $firstUser->id,
        ]);

        // SEND EMAIL
        $base62=new Base62;
        $userId=$base62->decode($request->input('user_id'));

        $user=app('db')->table('mobile_user')->where('id','=',$userId)->first();
        $klinik=app('db')->table('klinik')->where('klinik_id','=',$request->input('klinik_id'))->first();
        $doctors=app('db')->table('user')->where('klinik_id','=',$request->input('klinik_id'))->where('email','<>','')->get();
        $emails=[];
        foreach ($doctors as $doctor) {
            array_push($emails, $doctor->email);
        }

        $data=[];
        $data['to']=$user->email;
        $data['cc']=$emails;
        $data['subject']='Pendaftaran Kunjungan Pasien';
        $data['klinik']=$klinik->klinik_nama;
        $data['mr']=$mrCode;
        $data['periksa']=$request->input('tanggal_periksa');
        $data['link']=app('url')->to('/').'/batalkunjungan?id='.$base62->encode($user->id).'&email='.$user->email.'&mr='.$mrCode.'&kid='.$request->input('klinik_id').'&tgl='.urlencode($request->input('tanggal_periksa'));
        $data['view']='pasien';
        self::sendEmail(json_encode($data));

        $result=[];
        $result['klinik']=$klinik->klinik_nama;
        $result['alamat']=$klinik->alamat;
        $this->response['message']="Berhasil menambahkan kunjungan";
        $this->response['status']=1;
        $this->response['data']=$result;
        $this->response['link']=app('url')->to('/').'/batalkunjungan?id='.$base62->encode($user->id).'&email='.$user->email.'&mr='.$mrCode.'&kid='.$request->input('klinik_id').'&tgl='.urlencode($request->input('tanggal_periksa'));
        return json_encode($this->response);
    }

    public function sendEmail($data){
        $info=json_decode($data);
        $data=[];
        $data['to']=$info->to;
        $data['cc']=$info->cc;
        $data['subject']=$info->subject;
        $data['klinik']=$info->klinik;
        $data['mr']=$info->mr;
        $data['periksa']=$info->periksa;
        $data['link']=$info->link;
        $data['view']=$info->view;

        Mail::send($data['view'], $data, function ($message) use ($data) {
            if(count($data['cc']) > 0){
                $message->cc($data['cc']);
            }
            $message->from('support@rekmed.com', 'Rekmed Pasien');
            $message->to($data['to']);
            $message->subject($data['subject']);
        });
    }

    public function abortVerify(Request $request){
        $base62=new Base62;
        $id=$base62->decode($request->input('id'));
        $email=$request->input('email');
        $mrCode=$request->input('mr');
        $klinikId=$request->input('kid');
        $tglPeriksa=$request->input('tgl');

        $check=app('db')->table('mobile_user')->where('id','=',$id)->where('email','=',$email)->count();
        if($check < 1){
            $message="Data tidak ditemukan, mungkin link Anda telah rusak atau masa tunggu telah berakhir.";
            return view('error',['message'=>$message]);
        }else{
            app('db')->table('kunjungan')
                ->where('klinik_id','=',$klinikId)
                ->where('mr','=',$mrCode)
                ->where('jam_masuk','=',$tglPeriksa)
                ->delete();

            $klinik=app('db')->table('klinik')->where('klinik_id','=',$klinikId)->first();
            $waktu=strtotime($tglPeriksa)-(30*60);
            app('db')->table('mobile_consult')
                ->where('user_id','=',$id)
                ->where('title','=',$klinik->klinik_nama)
                ->where('due','=',date("Y-m-d H:i:s",$waktu))
                ->delete();
            $message = 'Pendaftaran Pasien berhasil dibatalkan';
            return view('success',['message'=>$message]);
        }
    }
}
