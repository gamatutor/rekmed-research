<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use \App\library\Base62;

class Promo extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $response;

    public function __construct()
    {
        date_default_timezone_set('Asia/Jakarta');
    }

    public function all($uid){
        $base62=new Base62;
        $id=$base62->decode($uid);

        $mrs=[];
        $user=app('db')->table('mobile_patient')->where('user_id','=',$id)->get();
        foreach($user as $row){
            array_push($mrs, $row->mr);
        }
        $klinik_id=[];
        $klinik=app('db')->table('pasien')->whereIn('mr',$mrs)->get();
        foreach($klinik as $row){
            array_push($klinik_id, $row->klinik_id);
        }
        // $data=app('db')->table('mobile_promo')->whereIn('klinik_id',$klinik_id)->get();
        $data=app('db')->table('mobile_promo')->get();
        $result=[];
        foreach($data as $row){
            $local=[];
            $local['id']=$row->id;
            $local['title']=$row->title;
            $local['description']=$row->description;
            $local['img']=$row->img;
            $local['url']=$row->url;
            array_push($result, $local);
        }
        $this->response['message']="Berhasil";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function get($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $data=app('db')->table('mobile_promo')->where('id','=',$id)->first();
        $result=[];
        $result['id']=$data->id;
        $result['title']=$data->title;
        $result['description']=$data->description;
        $result['img']=$data->img;

        $this->response['message']="Berhasil";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function insert(Request $request){
        $description=$request->input('description');
        $klinik_id=$request->input('klinik_id');
        $title=$request->input('title');
        $img=$request->input('img');

        app('db')->table('mobile_promo')->insert([
                'description'   => $description,
                'klinik_id'     => $klinik_id,
                'title'         => $title,
                'img'           => $img,
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);
        $this->response['message']="Data ditambahkan";
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function update($id,Request $request){
        $base62=new Base62;
        $id=$base62->decode($id);

        $description=$request->input('description');
        $klinik_id=$request->input('klinik_id');
        $title=$request->input('title');
        $img=$request->input('img');
        
        $check=app('db')->table('mobile_promo')->where('id','=',$id)->count();
        if($check < 1){
            $this->response['message']  ="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            app('db')->table('mobile_promo')->where('id','=',$id)->update([
                'description'   => $description,
                'klinik_id'     => $klinik_id,
                'title'         => $title,
                'img'           => $img,
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);
            $this->response['message']="Data diperbarui";
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }

    public function delete($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $check=app('db')->table('mobile_promo')->where('id','=',$id)->count();
        if($check < 1){
            $this->response['message']  ="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            app('db')->table('mobile_promo')->where('id','=',$id)->delete();
            $this->response['message']="Data dihapus";
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }
}
