<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use \App\library\Base62;
use Illuminate\Support\Facades\Mail;

class User extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $response;

    public function __construct()
    {
        date_default_timezone_set('Asia/Jakarta');
    }

    public function signup(Request $request){
        $email=$request->input('email');
        $password=hash('sha256',$request->input('password'));

        $check=app('db')->table('mobile_user')->where('email','=',$email)->count();
        if($check > 0){
            $this->response['message']="Your email is already registered, please login instead";
            $this->response['status']=0;
        }else{
            app('db')->table('mobile_user')->insert([
                'email'         => $email,
                'password'      => $password,
                'active'        => 0,
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);
            $this->response['message']="Sign up succeed";
            $this->response['status']=1;

            $base62=new Base62;
            $last=app('db')->table('mobile_user')->where('email','=',$email)->first();
            $data=[];
            $data['to']=$last->email;
            $data['subject']='Verifikasi pengguna baru';
            $data['link']=app('url')->to('/').'/verify?id='.$base62->encode($last->id).'&email='.$last->email;
            $data['view']='registrasi';
            self::sendEmail(json_encode($data));
            $this->response['message']="Silakan cek email Anda untuk verifikasi akun";
        }
        return json_encode($this->response);
    }

    public function verify(Request $request){
        $base62=new Base62;
        $id=$base62->decode($request->input('id'));
        $email=$request->input('email');

        $check=app('db')->table('mobile_user')->where('id','=',$id)->where('email','=',$email)->count();
        if($check < 1){
            $reverify='<a href="'.app('url')->to('/').'/reverify?email='.$email.'">'.app('url')->to('/').'/reverify?email='.$email.'</a>';
            $message="Data tidak ditemukan, mungkin link Anda telah rusak atau masa tunggu verifikasi telah berakhir.<br/>Silakan klik ".$reverify." untuk mengulang proses verifikasi ke email Anda.";
            return view('error',['message'=>$message]);
        }else{
            app('db')->table('mobile_user')->where('id','=',$id)->where('email','=',$request->input('email'))->update([
                'active'        => 1,
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);
            $message="Anda telah terverifikasi, silakan tutup halaman ini dan login pada aplikasi";
            return view('success',['message'=>$message]);
        }
    }

    public function resendVerify(Request $request){
        $email=$request->input('email');
        $base62=new Base62;
        $check=app('db')->table('mobile_user')->where('email','=',$email)->count();
        if($check < 1){
            $this->response['message']="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            $last=app('db')->table('mobile_user')->where('email','=',$email)->first();
            $data=[];
            $data['to']=$last->email;
            $data['subject']='Verifikasi pengguna baru';
            $data['link']=app('url')->to('/').'/verify?id='.$base62->encode($last->id).'&email='.$last->email;
            $data['view']='registrasi';
            self::sendEmail(json_encode($data));

            $this->response['message']="Permintaan verifikasi berhasil, silakan cek email Anda";
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }

    public function forgetPassword(Request $request){
        $base62=new Base62;
        $email=$request->input('email');
        $check=app('db')->table('mobile_user')->where('email','=',$email)->count();
        if($check < 1){
            $this->response['message']="Email tidak ditemukan";
            $this->response['status']=0;
        }else{
            $last=app('db')->table('mobile_user')->where('email','=',$email)->first();
            $data=[];
            $data['to']=$last->email;
            $data['subject']='Permintaan lupa password';
            $data['link']=app('url')->to('/').'/forgetverify?id='.$base62->encode($last->id).'&email='.$last->email;
            $data['view']='forget';
            self::sendEmail(json_encode($data));

            $this->response['message']="Permintaan ubah password berhasil, silakan cek email Anda";
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }

    public function forgetVerify(Request $request){
        $base62=new Base62;
        $id=$base62->decode($request->input('id'));
        $email=$request->input('email');

        $check=app('db')->table('mobile_user')->where('id','=',$id)->where('email','=',$email)->count();
        if($check < 1){
            $message="Data tidak ditemukan, mungkin link Anda telah rusak atau masa tunggu telah berakhir.";
            return view('error',['message'=>$message]);
        }else{
            return view('forgetform',['email'=>$email]);
        }
    }

    public function forgetSubmit(Request $request){
        $password=$request->input('password');
        $password_again=$request->input('password_again');
        $email=$request->input('email');

        if($password != $password_again){
            $error="Password baru dan password baru sekali lagi harus sama";
            return view('forgetform',['error'=>$error,'email'=>$email]);
        }else{
            app('db')->table('mobile_user')->where('email','=',$email)->update([
                'password'  => hash('sha256',$password)
            ]);
            $message="Password berhasil diubah, silakan tutup halaman ini dan login pada aplikasi";
            return view('success',['message'=>$message]);
        }
    }

    public function login(Request $request){
        $email=$request->input('email');
        $password=hash('sha256',$request->input('password'));

        $check=app('db')->table('mobile_user')->where('email','=',$email)->where('password','=',$password)->where('social','=',0)->count();
        if($check < 1){
            $this->response['message']="Invalid credentials, are you sure your input is correct?";
            $this->response['status']=0;
        }else{
            $data=app('db')->table('mobile_user')->where('email','=',$email)->where('password','=',$password)->first();
            if($data->active=='0'){
                $this->response['message']="Akun Anda belum diaktifkan";
                $this->response['status']=0;
                return json_encode($this->response);
            }
            $result=[];
            $result['id']=$data->id;
            $result['email']=$data->email;
            $this->response['message']="Login succeed";
            $this->response['data']=$result;
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }

    public function fbLogin(Request $request){
        $token=$request->input('token');
        $email=$request->input('email');
        $name=$request->input('name');
        $gender=$request->input('gender');
        // Check if token exists
        $check=app('db')->table('mobile_token')->where('token','=',$token)->count();
        if($check < 1){
            $this->response['message']="Incorrect token";
            $this->response['status']=0;
        }else{
            // Check if email already exists
            $check=app('db')->table('mobile_user')->where('email','=',$email)->count();
            if($check < 1){
                // add new user
                app('db')->table('mobile_user')->insert([
                    'email'         => $email,
                    'gender'        => $gender,
                    'name'          => $name,
                    'social'        => 1,
                    'active'        => 1,
                    'created_at'    => date('Y-m-d H:i:s'),
                    'updated_at'    => date('Y-m-d H:i:s'),
                ]);
                $this->response['message']="Sign up succeed";
                $this->response['status']=1;
            }else{
                // get credentials
                $data=app('db')->table('mobile_user')->where('email','=',$email)->first();
                $result=[];
                $result['id']=$data->id;
                $result['email']=$data->email;
                $this->response['message']="Login succeed";
                $this->response['data']=$result;
                $this->response['status']=1;
            }
        }
        return json_encode($this->response);
    }

    public function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function getToken(Request $request){
        $token=date('Y-m-d').'rekmed-token'.self::generateRandomString(16);
        $token=hash('sha256',$token);
        app('db')->table('mobile_token')->where('expired_at','<',date('Y-m-d H:i:s'))->delete();
        app('db')->table('mobile_token')->insert([
                'token'         => $token,
                'created_at'    => date('Y-m-d H:i:s'),
                'expired_at'    => date('Y-m-d H:i:s',strtotime(date('Y-m-d H:i:s'))+(8*60*60))
            ]);
        $this->response['message']="Token generated";
        $this->response['data']=$token;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function account($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $kelurahan='';
        $kecamatan='';
        $kabupaten='';
        $provinsi='';

        $check=app('db')->table('mobile_user')->where('id','=',$id)->count();
        if($check < 1){
            $this->response['message']="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            $data=app('db')->table('mobile_user')->where('id','=',$id)->first();
            if(!empty($data->kelurahan_id)){
                $kelurahan=app('db')->table('mobile_ref_kelurahan')->where('id','=',$data->kelurahan_id)->first()->kelurahan;
                $kecamatan=app('db')->table('mobile_ref_kecamatan')->where('id','=',substr($data->kelurahan_id,0,7))->first()->kecamatan;
                $kabupaten=app('db')->table('mobile_ref_kabupaten')->where('id','=',substr($data->kelurahan_id,0,4))->first()->kabupaten;
                $provinsi=app('db')->table('mobile_ref_provinsi')->where('id','=',substr($data->kelurahan_id,0,2))->first()->provinsi;
            }
            $mr=app('db')->table('mobile_patient')->where('user_id','=',$data->id)->get();
            $array_mr=[];
            foreach($mr as $row){
                array_push($array_mr, $row->mr);
            }
            $result=[];
            $result['name']=$data->name;
            $result['email']=$data->email;
            $result['phone']=$data->phone;
            $result['img']=$data->img;
            $result['kelurahan_id']=$data->kelurahan_id;
            $result['birth_at']=$data->birth_at;
            if($data->gender==1){
                $result['gender']='MALE';
            }else{
                $result['gender']='FEMALE';
            }
            $result['address']=$data->address;
            $result['mr']=$array_mr;

            $this->response['message']="User ditemukan";
            $this->response['data']=$result;
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }

    public function update($id,Request $request){
        $base62=new Base62;
        $id=$base62->decode($id);

        $name=$request->input('name');
        $phone=$request->input('phone');
        $birth_at=$request->input('birth_at');
        $gender=$request->input('gender');
        $address=$request->input('address');
        $kelurahan_id=$request->input('kelurahan_id');
        $mrs=$request->input('mrs');

        $check=app('db')->table('mobile_user')->where('id','=',$id)->count();
        if($check < 1){
            $this->response['message']="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            app('db')->table('mobile_user')->where('id','=',$id)->update([
                'name'          => $name,
                'phone'         => $phone,
                'birth_at'      => $birth_at,
                'gender'        => $gender,
                'address'       => $address,
                'kelurahan_id'  => $kelurahan_id,
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);

            $mrs=str_replace(" ", "", $mrs);
            $mrs=explode(",", $mrs);
            app('db')->table('mobile_patient')->where('user_id','=',$id)->delete();
            foreach($mrs as $row){
                app('db')->table('mobile_patient')->insert([
                    'user_id'       => $id,
                    'mr'            => $row,
                    'created_at'    => date('Y-m-d H:i:s'),
                    'updated_at'    => date('Y-m-d H:i:s'),
                ]);
            }

            $this->response['message']="Data berhasil diperbarui";

            if($request->hasFile('upload')){
                $extension=$request->file('upload')->getClientOriginalExtension();
                if(in_array($extension, ['jpg','png','jpeg','gif','JPG','JPEG','PNG','GIF'])){
                    try{
                        $filename=date('Y-m-d').'_'.date('H-i-s').'-'.$id.'-'.$request->file('upload')->getClientOriginalName();
                        $request->file('upload')->move(app()->basePath('public').'/uploads', $filename);

                        app('db')->table('mobile_user')->where('id','=',$id)->update([
                            'img'    => $filename,
                            'updated_at'    => date('Y-m-d H:i:s'),
                        ]);

                        $this->response['message']="Data is updated";
                        $this->response['status']=1;
                    }catch(Exception $e){
                        $this->response['message']=$e->getMessage();
                        $this->response['status']=1;
                    }
                }else{
                    $this->response['message']="Your uploaded file is not an image";
                    $this->response['status']=1;
                }
            }else{
              $this->response['status']=1;
            }
        }
        return json_encode($this->response);
    }

    public function changePassword($id,Request $request){
        $base62=new Base62;
        $id=$base62->decode($id);

        $check=app('db')->table('mobile_user')->where('id','=',$id)->count();
        if($check < 1){
            $this->response['message']="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            $password=$request->input('password');
            $password_again=$request->input('password_again');
            if($password!=$password_again){
                $this->response['message']="Password dan ulang password harus sama";
                $this->response['status']=0;
            }else{
                app('db')->table('mobile_user')->where('id','=',$id)->update([
                    'password'  => hash('sha256',$request->input('password'))
                ]);
                $this->response['status']=1;
                $this->response['message']="Password diubah, silakan logout";
            }
        }
        return json_encode($this->response);
    }

    public function resetPassword($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $check=app('db')->table('mobile_user')->where('id','=',$id)->count();
        if($check < 1){
            $this->response['message']="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            app('db')->table('mobile_user')->where('id','=',$id)->update([
                'password'  => hash('sha256','password')
            ]);
            $this->response['message']="Password di-reset";
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }

    public function delete($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $check=app('db')->table('mobile_user')->where('id','=',$id)->count();
        if($check < 1){
            $this->response['message']  ="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            app('db')->table('mobile_user')->where('id','=',$id)->delete();
            $this->response['message']="Data dihapus";
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }

    public function getProvinsi(){
        $data=app('db')->table('mobile_ref_provinsi')->get();
        $result=[];
        foreach($data as $row){
            $local=[];
            $local['id']=$row->id;
            $local['provinsi']=$row->provinsi;
            array_push($result, $local);
        }
        $this->response['message']="Data ditemukan";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function getKabupaten($prov_id){
        $data=app('db')->table('mobile_ref_kabupaten')->where('provinsi_id','=',$prov_id)->get();
        $result=[];
        foreach($data as $row){
            $local=[];
            $local['id']=$row->id;
            $local['kabupaten']=$row->kabupaten;
            array_push($result, $local);
        }
        $this->response['message']="Data ditemukan";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function getKecamatan($kab_id){
        $data=app('db')->table('mobile_ref_kecamatan')->where('kabupaten_id','=',$kab_id)->get();
        $result=[];
        foreach($data as $row){
            $local=[];
            $local['id']=$row->id;
            $local['kecamatan']=$row->kecamatan;
            array_push($result, $local);
        }
        $this->response['message']="Data ditemukan";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function getKelurahan($kec_id){
        $data=app('db')->table('mobile_ref_kelurahan')->where('kecamatan_id','=',$kec_id)->get();
        $result=[];
        foreach($data as $row){
            $local=[];
            $local['id']=$row->id;
            $local['kelurahan']=$row->kelurahan;
            array_push($result, $local);
        }
        $this->response['message']="Data ditemukan";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function sendEmail($data){
        $info=json_decode($data);
        $data=[];
        $data['to']=$info->to;
        $data['subject']=$info->subject;
        $data['link']=$info->link;
        $data['view']=$info->view;

        Mail::send($data['view'], $data, function ($message) use ($data) {
            $message->from('support@rekmed.com', 'Rekmed Pasien');
            $message->to($data['to']);
            $message->subject($data['subject']);
        });
    }

}
