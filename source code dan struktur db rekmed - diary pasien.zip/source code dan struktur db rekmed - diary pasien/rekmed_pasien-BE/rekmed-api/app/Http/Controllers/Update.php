<?php

namespace App\Http\Controllers;

class Update extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $response;
    private static $versionCode=14;
    private static $versionName='2.1.4';

    public function __construct()
    {
        date_default_timezone_set('Asia/Jakarta');
    }

    public function check($version){
        if($version < static::$versionCode){
            $this->response['message']="Update versi ".static::$versionName." telah tersedia";
            $this->response['status']=0;
        }else{
            $this->response['message']="You are using the latest version";
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }
}
