<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use \App\library\Base62;

class Record extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $response;

    public function __construct()
    {
        date_default_timezone_set('Asia/Jakarta');
    }

    public function all($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $data=app('db')->table('mobile_record')->where('user_id','=',$id)->orderBy('id','desc')->get();
        $result=[];
        foreach($data as $row){
            $local=[];
            $local['id']=$row->id;
            $local['title']=$row->title;
            $local['content']=$row->content;
            $local['attachment']=$row->attachment;
            $local['filetype']=$row->filetype;
            $local['updated_at']=$row->updated_at;
            $local['mr']=$row->mr;
            array_push($result, $local);
        }

        $this->response['message']="Berhasil";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function search($id,Request $request){
        $base62=new Base62;
        $id=$base62->decode($id);
        $search=$request->input('search');

        $data=app('db')->table('mobile_record')->where('user_id','=',$id)->where('title','like','%'.$search.'%')->orWhere('content','like','%'.$search.'%')->orderBy('id','desc')->get();
        $result=[];
        foreach($data as $row){
            $local=[];
            $local['id']=$row->id;
            $local['title']=$row->title;
            $local['content']=$row->content;
            $local['attachment']=$row->attachment;
            $local['filetype']=$row->filetype;
            $local['updated_at']=$row->updated_at;
            $local['mr']=$row->mr;
            array_push($result, $local);
        }

        $this->response['message']="Berhasil";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function get($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $data=app('db')->table('mobile_record')->where('id','=',$id)->first();
        $result=[];
        $result['title']=$data->title;
        $result['content']=$data->content;
        $result['attachment']=$data->attachment;
        $result['filetype']=$data->filetype;
        $result['updated_at']=$data->updated_at;
        $result['mr']=$data->mr;
        
        $this->response['message']="Berhasil";
        $this->response['data']=$result;
        $this->response['status']=1;
        return json_encode($this->response);
    }

    public function insert(Request $request){
        $user_id=$request->input('user_id');
        $content=$request->input('content');
        $title=$request->input('title');
        $attachment=$request->input('attachment');
        $filetype=$request->input('filetype');
        $mr=$request->input('mr');

        if($request->hasFile('upload')){
            $extension=$request->file('upload')->getClientOriginalExtension();
            if(in_array($extension, ['jpg','png','jpeg','gif','JPG','JPEG','PNG','GIF'])){
                try{
                    $filename=date('Y-m-d').'_'.date('H-i-s').'-'.$user_id.'-'.$request->file('upload')->getClientOriginalName();
                    $request->file('upload')->move(app()->basePath('public').'/uploads', $filename);

                    app('db')->table('mobile_record')->insert([
                        'user_id'       => $user_id,
                        'content'       => $content,
                        'title'         => $title,
                        'attachment'    => $filename,
                        'filetype'      => $filetype,
                        'mr'            => $mr,
                        'created_at'    => date('Y-m-d H:i:s'),
                        'updated_at'    => date('Y-m-d H:i:s'),
                    ]);

                    $this->response['message']="Data ditambahkan";
                    $this->response['status']=1;
                }catch(Exception $e){
                    app('db')->table('mobile_record')->insert([
                        'user_id'       => $user_id,
                        'content'       => $content,
                        'title'         => $title,
                        'attachment'    => $attachment,
                        'filetype'      => $filetype,
                        'mr'            => $mr,
                        'created_at'    => date('Y-m-d H:i:s'),
                        'updated_at'    => date('Y-m-d H:i:s'),
                    ]);

                    $this->response['message']=$e->getMessage();
                    $this->response['status']=0;
                }
            }else{
                app('db')->table('mobile_record')->insert([
                    'user_id'       => $user_id,
                    'content'       => $content,
                    'title'         => $title,
                    'attachment'    => $attachment,
                    'filetype'      => $filetype,
                    'mr'            => $mr,
                    'created_at'    => date('Y-m-d H:i:s'),
                    'updated_at'    => date('Y-m-d H:i:s'),
                ]);

                $this->response['message']="Data ditambahkan";
                $this->response['status']=1;
            }
        }else{
            app('db')->table('mobile_record')->insert([
                    'user_id'       => $user_id,
                    'content'       => $content,
                    'title'         => $title,
                    'attachment'    => $attachment,
                    'filetype'      => $filetype,
                    'mr'            => $mr,
                    'created_at'    => date('Y-m-d H:i:s'),
                    'updated_at'    => date('Y-m-d H:i:s'),
                ]);

            $this->response['message']="Data ditambahkan";
            $this->response['status']=1;
        }
        
        return json_encode($this->response);
    }

    public function update($id,Request $request){
        $base62=new Base62;
        $id=$base62->decode($id);
        $user_id=$request->input('user_id');
        $content=$request->input('content');
        $title=$request->input('title');
        $attachment=$request->input('attachment');
        $filetype=$request->input('filetype');
        $mr=$request->input('mr');

        if($request->hasFile('upload')){
            $extension=$request->file('upload')->getClientOriginalExtension();
            if(in_array($extension, ['jpg','png','jpeg','gif','JPG','JPEG','PNG','GIF'])){
                try{
                    $filename=date('Y-m-d').'_'.date('H-i-s').'-'.$user_id.'-'.$request->file('upload')->getClientOriginalName();
                    $request->file('upload')->move(app()->basePath('public').'/uploads', $filename);

                    app('db')->table('mobile_record')->where('id','=',$id)->update([
                        'content'       => $content,
                        'title'         => $title,
                        'attachment'    => $filename,
                        'filetype'      => $filetype,
                        'mr'            => $mr,
                        'updated_at'    => date('Y-m-d H:i:s'),
                    ]);

                    $this->response['message']="Unggah berhasil, data diperbarui";
                    $this->response['status']=1;
                }catch(Exception $e){
                    app('db')->table('mobile_record')->where('id','=',$id)->update([
                        'content'       => $content,
                        'title'         => $title,
                        'attachment'    => $attachment,
                        'filetype'      => $filetype,
                        'mr'            => $mr,
                        'updated_at'    => date('Y-m-d H:i:s'),
                    ]);

                    $this->response['message']=$e->getMessage();
                    $this->response['status']=0;
                }
            }else{
                app('db')->table('mobile_record')->where('id','=',$id)->update([
                    'content'       => $content,
                    'title'         => $title,
                    'filetype'      => $filetype,
                    'mr'            => $mr,
                    'updated_at'    => date('Y-m-d H:i:s'),
                ]);

                $this->response['message']="Tidak ada yang diunggah, tetapi pembaruan berhasil";
                $this->response['status']=1;
            }
        }else{
            app('db')->table('mobile_record')->where('id','=',$id)->update([
                    'content'       => $content,
                    'title'         => $title,
                    'filetype'      => $filetype,
                    'mr'            => $mr,
                    'updated_at'    => date('Y-m-d H:i:s'),
                ]);

            $this->response['message']="Tidak ada yang diunggah, tetapi pembaruan berhasil";
            $this->response['status']=1;
        }
        
        return json_encode($this->response);
    }

    public function delete($id){
        $base62=new Base62;
        $id=$base62->decode($id);

        $check=app('db')->table('mobile_record')->where('id','=',$id)->count();
        if($check < 1){
            $this->response['message']  ="Data tidak ditemukan, mohon cek kembali";
            $this->response['status']=0;
        }else{
            app('db')->table('mobile_record')->where('id','=',$id)->delete();
            $this->response['message']="Data dihapus";
            $this->response['status']=1;
        }
        return json_encode($this->response);
    }
}