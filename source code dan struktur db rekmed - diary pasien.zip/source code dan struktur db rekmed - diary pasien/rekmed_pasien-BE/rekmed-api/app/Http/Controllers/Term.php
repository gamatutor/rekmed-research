<?php

namespace App\Http\Controllers;

class Term extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    private $response;

    public function __construct()
    {
        date_default_timezone_set('Asia/Jakarta');
    }

    public function get(){
        return view('term');
    }
}
