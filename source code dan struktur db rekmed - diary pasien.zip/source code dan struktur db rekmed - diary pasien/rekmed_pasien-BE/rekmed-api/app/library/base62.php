<?php 
	namespace App\library;
	use App\library\Math;
    class Base62 {
    	function generateRandomString($length = 5) {
		    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		    $charactersLength = strlen($characters);
		    $randomString = '';
		    for ($i = 0; $i < $length; $i++) {
		        $randomString .= $characters[rand(0, $charactersLength - 1)];
		    }
		    return $randomString;
		}

    	function encode($number){
    		date_default_timezone_set('Asia/Jakarta');
    		return self::generateRandomString().Math::to_base($number+(date('Y')*date('m')*date('d')),62);
    	}
    	function decode($encoded){
    		date_default_timezone_set('Asia/Jakarta');
    		return Math::to_base_10(substr($encoded,5),62)-(date('Y')*date('m')*date('d'));	
    	}
    }
?>