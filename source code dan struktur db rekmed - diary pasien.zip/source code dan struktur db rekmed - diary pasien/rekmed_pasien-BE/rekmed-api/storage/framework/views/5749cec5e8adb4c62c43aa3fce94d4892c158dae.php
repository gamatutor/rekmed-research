<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ubah Password</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <style type="text/css">
      body{
        background-color: #eee;
      }
      .mini{
        background-color: #fff;
        padding: 20px;
        margin-top: 100px;
      }
      .mini form input{
        margin-bottom: 20px;
      }
    </style>
  </head>
  <body>
    <div class="row">
      <div class="container">
        <div class="mini">
          <?php
            if(isset($error)){
              ?>
              <div class="alert alert-danger"><?php echo e($error); ?></div>
              <?php
            }
          ?>
          <form action="<?php echo e(url('/')); ?>/forget" method="post">
            <div>
              <label>Password baru</label>
              <input type="password" name="password" class="form-control" required="required">
            </div>
            <div>
              <label>Password baru sekali lagi</label>
              <input type="password" name="password_again" class="form-control" required="required">
            </div>
            <input type="hidden" name="email" value="<?php echo e($email); ?>">
            <button class="btn btn-primary" type="submit">Ubah password</button>
          </form>
        </div>
      </div>
    </div>
  </body>
</html>