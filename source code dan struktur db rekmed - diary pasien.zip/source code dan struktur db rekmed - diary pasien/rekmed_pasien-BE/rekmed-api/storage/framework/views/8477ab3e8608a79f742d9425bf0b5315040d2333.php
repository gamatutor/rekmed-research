Selamat datang, <?php echo e($to); ?>

<br/>
<p>Baru-baru ini kami menerima permintaan untuk mengubah password login akun Anda di Diary Pasien, jika Anda tidak melakukan ini, maka abaikan pesan ini. Jika Anda benar melakukan ini, silakan klik tautan ini : <?php echo e($link); ?> dalam jangka waktu kurang dari 24 jam setelah email ini diterima untuk mengubah password Anda.</p>
<br/>
Terima kasih