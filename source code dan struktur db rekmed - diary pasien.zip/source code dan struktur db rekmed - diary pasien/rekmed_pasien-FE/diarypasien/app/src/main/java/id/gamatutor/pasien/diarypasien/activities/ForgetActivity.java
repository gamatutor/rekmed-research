package id.gamatutor.pasien.diarypasien.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wang.avi.AVLoadingIndicatorView;

import org.json.JSONException;
import org.json.JSONObject;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgetActivity extends AppCompatActivity {
    private TextView txtAlertForgot;
    private ImageView imgBack;
    private EditText editEmail;
    private Button btnForget;
    private AVLoadingIndicatorView loadingForgot;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget);

        txtAlertForgot=(TextView)findViewById(R.id.txtAlertForgot);
        imgBack=(ImageView)findViewById(R.id.imgForgotBack);
        editEmail=(EditText)findViewById(R.id.editEmailForgot);
        btnForget=(Button)findViewById(R.id.btnForgot);
        loadingForgot=(AVLoadingIndicatorView)findViewById(R.id.loadingForgot);

        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });

        btnForget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doForget();
            }
        });

        loadingForgot.hide();
        txtAlertForgot.setVisibility(View.GONE);
    }

    private void doForget() {
        loadingForgot.show();
        Call<Object> call = ApiClient.connect().doForget(editEmail.getText().toString());
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                Log.i("RESPONSE",responseStr.toString());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        loadingForgot.hide();
                        txtAlertForgot.setText(obj.getString("message"));
                        txtAlertForgot.setVisibility(View.VISIBLE);
                    }else {
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_LONG).show();
                        loadingForgot.hide();
                        txtAlertForgot.setVisibility(View.GONE);
                        finish();
                        overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                loadingForgot.hide();
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }
}
