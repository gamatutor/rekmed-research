package id.gamatutor.pasien.diarypasien.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wang.avi.AVLoadingIndicatorView;

import org.json.JSONException;
import org.json.JSONObject;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity {
    EditText editEmail,editPassword,editRepassword;
    Button btnSignup;
    TextView txtAlertSignup;
    AVLoadingIndicatorView loadingSignup;
    ImageView imgBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
//        initialize
        editEmail=(EditText)findViewById(R.id.editEmailSignup);
        editPassword=(EditText)findViewById(R.id.editPasswordSignup);
        editRepassword=(EditText)findViewById(R.id.editRepasswordSignup);
        btnSignup=(Button)findViewById(R.id.btnSignup);
        txtAlertSignup=(TextView)findViewById(R.id.txtAlertSignup);
        loadingSignup=(AVLoadingIndicatorView)findViewById(R.id.loadingSignup);
        imgBack=(ImageView)findViewById(R.id.imgSignUpBack);

        txtAlertSignup.setVisibility(View.GONE);
        loadingSignup.hide();
        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editPassword.getText().toString().equals(editRepassword.getText().toString()) == false ){
                    txtAlertSignup.setText("Password dan ulangi password harus sama");
                    txtAlertSignup.setVisibility(View.VISIBLE);
                }else{
                    txtAlertSignup.setVisibility(View.GONE);
                    doSignUp();
                }
            }
        });
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
    }

    private void doSignUp() {
        loadingSignup.show();
        Call<Object> call= ApiClient.connect().doSignup(editEmail.getText().toString(),editPassword.getText().toString());
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                loadingSignup.hide();
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        txtAlertSignup.setText(obj.getString("message"));
                        txtAlertSignup.setVisibility(View.VISIBLE);
                    }else{
                        txtAlertSignup.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                loadingSignup.hide();
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }
}
