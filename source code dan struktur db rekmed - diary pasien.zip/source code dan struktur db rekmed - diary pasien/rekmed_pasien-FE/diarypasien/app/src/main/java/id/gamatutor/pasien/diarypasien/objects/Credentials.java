package id.gamatutor.pasien.diarypasien.objects;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by zmachmobile on 4/15/17.
 */

public class Credentials {
    private int id;
    private int gender=0;
    private String name,email,phone,address,kelurahanId,img;
    private List<String> mrs=new ArrayList<String>();
    private Date birth;

    public Credentials(int id, String email){
        this.id=id;
        this.email=email;
    }

    public void setName(String name){
        this.name=name;
    }

    public void setPhone(String phone){
        this.phone=phone;
    }

    public void setGender(int gender){
        this.gender=gender;
    }

    public void setAddress(String address){
        this.address=address;
    }

    public void setBirth(Date birth){
        this.birth=birth;
    }

    public void setMrs(List mrs){
        this.mrs=mrs;
    }

    public void setKelurahanId(String kelurahanId){
        this.kelurahanId=kelurahanId;
    }

    public void setImg(String img){
        this.img=img;
    }

    public int getId(){
        return this.id;
    }

    public String getName(){
        return this.name;
    }

    public String getEmail(){
        return this.email;
    }

    public String getPhone(){
        return this.phone;
    }

    public int getGender(){
        return this.gender;
    }

    public String getAddress(){
        return this.address;
    }

    public Date getBirth(){
        return this.birth;
    }

    public List<String> getMrs(){
        return this.mrs;
    }

    public String getKelurahanId(){
        return this.kelurahanId;
    }

    public String getImg(){
        return this.img;
    }
}
