package id.gamatutor.pasien.diarypasien.activities;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class KunjunganActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener{

    private Button btnConfirm;
    private TextView txtDate, txtDateChange, txtTime, txtTimeChange, txtKlinikTitle, txtKlinikAddress, txtJadwal;
    private Calendar selectedDateTime;
    private int selectedKlinikId, selectedDokterId;
    private Bundle extras;
    private Toolbar toolbar;
    private int userId;
    private Spinner spinDokter;
    private SharedPreferences settings,savedConsult;
    private List<String> listSchedule = new ArrayList<String>();
    private List<Integer> listDokter = new ArrayList<Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kunjungan);

        toolbar=(Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle("Pilih waktu kunjungan");
        setSupportActionBar(toolbar);

        ActionBar actionBar=getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        spinDokter=(Spinner)findViewById(R.id.spinDokter);
        btnConfirm=(Button)findViewById(R.id.btnConfirm);
        txtDate=(TextView)findViewById(R.id.txtDate);
        txtDateChange=(TextView)findViewById(R.id.txtDateChange);
        txtTime=(TextView)findViewById(R.id.txtTime);
        txtTimeChange=(TextView)findViewById(R.id.txtTimeChange);
        txtKlinikTitle=(TextView)findViewById(R.id.txtKlinikTitle);
        txtKlinikAddress=(TextView)findViewById(R.id.txtKlinikAddress);
        txtJadwal=(TextView)findViewById(R.id.txtSchedule);
        settings=getSharedPreferences(Config.sharedPrefName,MODE_PRIVATE);
        savedConsult=getSharedPreferences(Config.sharedPrefConsult, MODE_PRIVATE);
        extras=getIntent().getExtras();

        userId=settings.getInt("userId",0);
        selectedKlinikId=extras.getInt("klinikId");
        txtKlinikTitle.setText(extras.getString("klinikTitle"));
        txtKlinikAddress.setText(extras.getString("klinikAddress"));

        loadDokter();

        selectedDateTime=Calendar.getInstance();
        SimpleDateFormat dateFormat=new SimpleDateFormat("dd MMM yyyy");
        txtDate.setText(dateFormat.format(selectedDateTime.getTime()));

        dateFormat=new SimpleDateFormat("HH:mm");
        txtTime.setText(dateFormat.format(selectedDateTime.getTime()));

        txtDateChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog=new DatePickerDialog(KunjunganActivity.this,KunjunganActivity.this,selectedDateTime.get(Calendar.YEAR),selectedDateTime.get(Calendar.MONTH),selectedDateTime.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();
            }
        });

        txtTimeChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TimePickerDialog timePickerDialog=new TimePickerDialog(KunjunganActivity.this,KunjunganActivity.this,selectedDateTime.get(Calendar.HOUR_OF_DAY),selectedDateTime.get(Calendar.MINUTE),true);
                timePickerDialog.show();
            }
        });

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doRegister();
            }
        });

        spinDokter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(listSchedule.size()>0){
                    txtJadwal.setText(listSchedule.get(i));
                    selectedDokterId=listDokter.get(i);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void loadDokter() {
        listSchedule.clear();
        listDokter.clear();
        String encodedId= EncodeDecode.encode(selectedKlinikId);
        Log.i("klinikId",encodedId);
        Call<Object> call=ApiClient.connect().getDokter(encodedId);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                Log.i("response",response.body().toString());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        JSONArray dokter=obj.getJSONArray("data");
                        List<String> list=new ArrayList<String>();
                        for(int i=0;i<dokter.length();i++){
                            JSONObject data=dokter.getJSONObject(i);
                            try{
                                list.add(data.getString("nama")+" - "+data.getString("spesialis"));
                                listSchedule.add(data.getString("waktu_praktek"));
                                listDokter.add(data.getInt("id"));
                            }catch (Exception e){
                                list.add(data.getString("nama")+" - umum");
                                listDokter.add(data.getInt("id"));
                            }
                        }
                        if(listDokter.size()>0){
                            selectedDokterId=listDokter.get(0);
                        }else{
                            selectedDokterId=1;
                        }
                        Log.i("list dokter nama",list.toString());
                        Log.i("list dokter id",listDokter.toString());
                        ArrayAdapter<String> dataAdapter=new ArrayAdapter<String>(getApplicationContext(),R.layout.spinner_style,list);
                        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown_style);
                        spinDokter.setAdapter(dataAdapter);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private void doRegister() {
        String encodedId= EncodeDecode.encode(userId);
        final SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm");
        final long selectedTime=selectedDateTime.getTimeInMillis()-(30*60*1000); //        remind 30 mins before due
        Log.i("user_id",encodedId);
        Log.i("klinik_id",String.valueOf(selectedKlinikId));
        Log.i("tanggal_periksa",dateFormat.format(selectedDateTime.getTime()));

        Call call= ApiClient.connect().syncPasien(encodedId,selectedKlinikId,dateFormat.format(selectedDateTime.getTimeInMillis()),selectedDokterId);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        JSONObject data=obj.getJSONObject("data");
                        Log.i("link",obj.getString("link"));
                        SimpleDateFormat jamFormat=new SimpleDateFormat("HH:mm");
                        SimpleDateFormat tglFormat=new SimpleDateFormat("yyyy-MM-dd");
                        addReminder(data.getString("klinik"),tglFormat.format(selectedTime),jamFormat.format(selectedTime));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        selectedDateTime.set(Calendar.YEAR,i);
        selectedDateTime.set(Calendar.MONTH,i1);
        selectedDateTime.set(Calendar.DAY_OF_MONTH,i2);

        SimpleDateFormat dateFormat=new SimpleDateFormat("dd MMM yyyy");
        txtDate.setText(dateFormat.format(selectedDateTime.getTime()));
    }

    @Override
    public void onTimeSet(TimePicker timePicker, int i, int i1) {
        selectedDateTime.set(Calendar.HOUR_OF_DAY,i);
        selectedDateTime.set(Calendar.MINUTE,i1);

        SimpleDateFormat dateFormat=new SimpleDateFormat("HH:mm");
        txtTime.setText(dateFormat.format(selectedDateTime.getTime()));
    }

    public void addReminder(String title, String dueDate, String dueTime) {
        Call<Object> call;

        RequestBody reqUserId=RequestBody.create(MultipartBody.FORM,String.valueOf(Config.credentials.getId()));
        RequestBody reqTitle=RequestBody.create(MultipartBody.FORM,title);
        RequestBody reqDue=RequestBody.create(MultipartBody.FORM,dueDate+" "+dueTime);
        RequestBody reqActive=RequestBody.create(MultipartBody.FORM,String.valueOf(1));

        call=ApiClient.connect().addConsult(reqUserId,reqTitle,reqDue,reqActive);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
        startActivity(new Intent(getApplicationContext(),SuccessActivity.class));
    }
}
