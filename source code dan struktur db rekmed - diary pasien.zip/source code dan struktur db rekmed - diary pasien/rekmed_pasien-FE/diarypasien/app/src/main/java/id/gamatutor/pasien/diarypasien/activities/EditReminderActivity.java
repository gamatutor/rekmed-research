package id.gamatutor.pasien.diarypasien.activities;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.models.ReminderDetailModel;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.objects.ReminderDetail;
import id.gamatutor.pasien.diarypasien.receivers.MedicineBroadcastReceiver;

public class EditReminderActivity extends AppCompatActivity {

    @BindView(R.id.imgBack) ImageView imgBack;
    @BindView(R.id.editTitle) EditText title;
    @BindView(R.id.txtDueDate) TextView dueDate;
    @BindView(R.id.txtDueTime) TextView dueTime;
    @BindView(R.id.btnSubmit) Button submit;
    @BindView(R.id.btnDelete) Button delete;
    ReminderDetailModel reminderDetailModel;
    static TextView dueTimeStatic;
    private DatePickerDialog.OnDateSetListener setDueDate;
    private int selectedDay, selectedMonth, selectedYear;
    private static int selectedHour, selectedMinute;
    private int pid;
    private MedicineBroadcastReceiver medicineBroadcastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_reminder);
        ButterKnife.bind(this);
        Bundle bundle = getIntent().getExtras();
        pid = bundle.getInt("pid");
        medicineBroadcastReceiver=new MedicineBroadcastReceiver();
        dueTimeStatic = dueTime;
        reminderDetailModel=new ReminderDetailModel();
        setDueDate=new DatePickerDialog.OnDateSetListener(){
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                selectedDay = dayOfMonth;
                selectedMonth = month;
                selectedYear = year;
                Calendar cal=Calendar.getInstance();
                cal.set(year,month,dayOfMonth);
                DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
                dueDate.setText(dateFormat.format(cal.getTime()));
            }
        };
        loadData();
    }

    private void loadData() {
        ReminderDetail reminderDetail = (ReminderDetail) reminderDetailModel.getItem(pid);
        title.setText(reminderDetail.getTitle());
        dueDate.setText(formatDate(reminderDetail.getCalendarMillis()));
        dueTime.setText(formatTime(reminderDetail.getCalendarMillis()));
    }

    private String formatTime(long calendarMillis) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(calendarMillis);
        selectedHour = calendar.get(Calendar.HOUR_OF_DAY);
        selectedMinute = calendar.get(Calendar.MINUTE);
        DateFormat dateFormat = new SimpleDateFormat("HH:mm");
        return dateFormat.format(calendar.getTime());
    }

    private String formatDate(long calendarMillis) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(calendarMillis);
        selectedDay = calendar.get(Calendar.DAY_OF_MONTH);
        selectedMonth = calendar.get(Calendar.MONTH);
        selectedYear = calendar.get(Calendar.YEAR);
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return dateFormat.format(calendar.getTime());
    }

    @OnClick(R.id.imgBack)
    void getBack(){
        finish();
        overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @OnClick(R.id.txtDueDate)
    void openCalendar(){
        Calendar calendar=Calendar.getInstance();
        new DatePickerDialog(this,setDueDate, calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    @OnClick(R.id.txtDueTime)
    void openTimePicker(){
        DialogFragment newFragment=new AddReminderActivity.TimePickerFragment();
        newFragment.show(getFragmentManager(),"timePicker");
    }

    @OnClick(R.id.btnSubmit)
    void doSubmit(){
        Calendar calendar=Calendar.getInstance();
        calendar.set(selectedYear,selectedMonth,selectedDay,selectedHour,selectedMinute);
        Bundle bundle = new Bundle();
        bundle.putInt("reminderId", Config.currentReminderId);
        bundle.putString("title",title.getText().toString());
        bundle.putLong("calendarMillis",calendar.getTimeInMillis());
        bundle.putBoolean("isActive",true);
        reminderDetailModel.updateItem(pid,bundle);
        medicineBroadcastReceiver.cancelAlert(getApplicationContext(),pid);
        medicineBroadcastReceiver.startAlertbyPid(getApplicationContext(),pid,calendar);
        finish();
    }

    @OnClick(R.id.btnDelete)
    void doDelete(){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Konfirmasi");
        alert.setMessage("Anda yakin ingin menghapus ini?");
        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                reminderDetailModel.deleteItem(pid);
                medicineBroadcastReceiver.cancelAlert(getApplicationContext(),pid);
                finish();
            }
        });
        alert.show();
    }

    public static class TimePickerFragment extends DialogFragment implements TimePickerDialog.OnTimeSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            Calendar calendar=Calendar.getInstance();
            return new TimePickerDialog(getActivity(),this,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),true);
        }

        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            selectedHour = hourOfDay;
            selectedMinute = minute;
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY,hourOfDay);
            calendar.set(Calendar.MINUTE,minute);
            DateFormat dateFormat = new SimpleDateFormat("HH:mm");
            dueTimeStatic.setText(dateFormat.format(calendar));
        }
    }
}
