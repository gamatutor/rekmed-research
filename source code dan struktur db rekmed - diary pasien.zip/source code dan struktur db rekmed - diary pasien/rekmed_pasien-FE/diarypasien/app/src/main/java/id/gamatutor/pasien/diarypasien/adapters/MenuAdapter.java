package id.gamatutor.pasien.diarypasien.adapters;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import id.gamatutor.pasien.diarypasien.objects.Cell;
import id.gamatutor.pasien.diarypasien.R;

/**
 * Created by zmachmobile on 8/21/17.
 */

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MyViewHolder>{
    private ArrayList<Cell> cells;
    private Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public ImageView imgIcon;
        public TextView caption;
        public MyViewHolder(View itemView) {
            super(itemView);
            imgIcon=(ImageView)itemView.findViewById(R.id.imgIcon);
            caption=(TextView)itemView.findViewById(R.id.txtCaption);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    gotoMenu(getAdapterPosition());
                }
            });
        }
    }

    private void gotoMenu(int adapterPosition) {
        Cell cell=cells.get(adapterPosition);
        context.startActivity(cell.intent);
    }

    public MenuAdapter(Context context, ArrayList<Cell> cells){
        this.context=context;
        this.cells=cells;
    }

    @Override
    public MenuAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.menu_cell,parent,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MenuAdapter.MyViewHolder holder, int position) {
        Cell cell=cells.get(position);
        holder.caption.setText(cell.caption);
        if(cell.imageDrawable != 0){
            holder.imgIcon.setImageResource(cell.imageDrawable);
            holder.imgIcon.setColorFilter(Color.parseColor("#5E40BF"));
        }else{
            Picasso.with(context).load(cell.imageUrl).into(holder.imgIcon);
        }
    }

    @Override
    public int getItemCount() {
        return cells.size();
    }
}
