package id.gamatutor.pasien.diarypasien.activities;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import id.gamatutor.pasien.diarypasien.components.DaggerComponentMedicine;
import id.gamatutor.pasien.diarypasien.models.ReminderDetailModel;
import id.gamatutor.pasien.diarypasien.models.ReminderModel;
import id.gamatutor.pasien.diarypasien.modules.MedicineModule;
import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.adapters.MedicineAdapter;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.objects.Reminder;
import id.gamatutor.pasien.diarypasien.objects.ReminderDetail;
import id.gamatutor.pasien.diarypasien.receivers.MedicineBroadcastReceiver;
import io.realm.RealmList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MedicineActivity extends AppCompatActivity {
    private SharedPreferences settings,savedObat,totalReminderId;
    private int userId;
    private String savedObatJson;
    @BindView(R.id.recyclerMedicine) RecyclerView recyclerView;
    private MedicineAdapter medicineAdapter;
    private ArrayList<Reminder> medicineList=new ArrayList<>();
    @BindView(R.id.btnSyncMedicine) Button btnSync;
    @BindView(R.id.imgMedicineBack) ImageView imgBack;
    private MedicineBroadcastReceiver medicineBroadcastReceiver;
    private ReminderModel reminderModel;
    private ReminderDetailModel reminderDetailModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medicine);
        ButterKnife.bind(this);
//        Initialize
        settings=getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        savedObat=getSharedPreferences(Config.sharedPrefObat, MODE_PRIVATE);
        totalReminderId=getSharedPreferences(Config.sharedPrefTotalReminderId,MODE_PRIVATE);

        userId=settings.getInt("userId",0);
        savedObatJson=savedObat.getString("obat","none");
        medicineBroadcastReceiver=new MedicineBroadcastReceiver();

        reminderModel=new ReminderModel();
        reminderDetailModel=new ReminderDetailModel();
        medicineList=reminderModel.getAll();

        medicineAdapter = DaggerComponentMedicine.builder()
                .medicineModule(new MedicineModule(medicineList,recyclerView,getApplicationContext()))
                .build()
                .getAdapter();

    }

    @OnClick(R.id.imgMedicineBack)
    void getBack(){
        //                startActivity(new Intent(getApplicationContext(),MainActivity.class));
        finish();
        overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
    }

    @OnClick(R.id.btnSyncMedicine)
    void getData() {
        String encodedId= EncodeDecode.encode(userId);
        Call<Object> call= ApiClient.connect().getMedicine(encodedId);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        reminderModel.flushAll();
                        medicineList.clear();
                        medicineAdapter.notifyDataSetChanged();
                        JSONArray arrdata=obj.getJSONArray("data");
                        Log.d("medicineList",arrdata.toString());
                        int seqNum=100;
                        if(arrdata.length() > 0){
                            for(int i=0;i<arrdata.length();i++){
                                JSONObject localdata=arrdata.getJSONObject(i);
                                String namaObat=localdata.getString("nama_obat");
                                int signa=Integer.parseInt(localdata.getString("dosis").replace(" ","").toLowerCase().split("x")[0]);
                                Bundle bundle=new Bundle();
                                bundle.putInt("pid",seqNum);
                                bundle.putString("obat",namaObat);
                                bundle.putInt("signa",signa);
                                bundle.putString("expired",localdata.getString("expired_date"));
                                bundle.putInt("amount",localdata.getInt("jumlah"));
                                bundle.putBoolean("isActive",true);
                                ArrayList<Bundle> schedules = getSchedules(seqNum,signa,localdata.getString("expired_date"));
                                reminderModel.addItem(bundle);
                                reminderDetailModel.addAll(schedules);
                                seqNum+=localdata.getInt("jumlah");
                            }
                            medicineList.addAll(reminderModel.getAll());
                            medicineAdapter.notifyDataSetChanged();
                        }else{
                            Toast.makeText(getApplicationContext(),"Belum ada jadwal obat",Toast.LENGTH_SHORT).show();
                        }
                    }
                    Log.d("jml",medicineList.toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private ArrayList<Bundle> getSchedules(int pid, int signa, String expired) {
        ArrayList<String> times;
        ArrayList<Bundle> schedules=new ArrayList<>();
        MedicineBroadcastReceiver medicineBroadcastReceiver=new MedicineBroadcastReceiver();
        times = medicineBroadcastReceiver.generateSchedule(expired,signa);
        for(int i=0;i<times.size();i++){
            String tanggal=times.get(i).split(" ")[0];
            String waktu=times.get(i).split(" ")[1];
            Calendar calendar=Calendar.getInstance();
            int year=Integer.parseInt(tanggal.split("-")[0]);
            int month=Integer.parseInt(tanggal.split("-")[1])-1;
            int day=Integer.parseInt(tanggal.split("-")[2]);
            int hour=Integer.parseInt(waktu.split(":")[0]);
            int minute=Integer.parseInt(waktu.split(":")[1]);
            calendar.set(Calendar.YEAR,year);
            calendar.set(Calendar.MONTH,month);
            calendar.set(Calendar.DAY_OF_MONTH,day);
            calendar.set(Calendar.HOUR_OF_DAY,hour);
            calendar.set(Calendar.MINUTE,minute);
            Bundle detail = new Bundle();
            detail.putInt("reminderId",pid);
            detail.putInt("pid",pid+(i+1));
            detail.putString("title","Saatnya minum obat");
            detail.putLong("calendarMillis",calendar.getTimeInMillis());
            detail.putBoolean("isActive",true);
            schedules.add(detail);
        }
        return schedules;
    }
}
