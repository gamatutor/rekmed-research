package id.gamatutor.pasien.diarypasien.activities;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;

public class SettingActivity extends AppCompatActivity {
    private SharedPreferences settings;
    private String serverAddress;
    private EditText editServer;
    private Button btnSave;
    private ImageView imgBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
//        initialize
        editServer=(EditText)findViewById(R.id.editServerSetting);
        btnSave=(Button)findViewById(R.id.btnSimpanSetting);
        settings=getSharedPreferences(Config.sharedPrefServer, MODE_PRIVATE);
        serverAddress=settings.getString("server", Config.getBaseUrl());
        imgBack=(ImageView)findViewById(R.id.imgSettingBack);

        editServer.setText(Config.getBaseUrl());
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor=settings.edit();
                editor.putString("server",editServer.getText().toString());
                editor.commit();
                Config.baseUrl=editServer.getText().toString();

                Toast.makeText(getApplicationContext(),"Pengaturan berhasil disimpan",Toast.LENGTH_SHORT).show();
            }
        });
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
    }
}
