package id.gamatutor.pasien.diarypasien.activities;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import id.gamatutor.pasien.diarypasien.objects.Queue;
import id.gamatutor.pasien.diarypasien.receivers.AlertBroadcastReceiver;
import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QueueActivity extends AppCompatActivity {
    private SharedPreferences settings, savedQueue;
    private int userId;
    private String queueJson;
    private Button btnQueue,btnCancelQueue;
    private ImageView imgBack;
    private AlertBroadcastReceiver alertBroadcastReceiver;
    private TextView txtQueueNum,txtQueueTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_queue);
//        initialize
        btnQueue=(Button)findViewById(R.id.btnCheckQueue);
        btnCancelQueue=(Button)findViewById(R.id.btnCancelQueue);
        imgBack=(ImageView)findViewById(R.id.imgQueueBack);
        txtQueueNum=(TextView)findViewById(R.id.txtQueueNum);
        txtQueueTime=(TextView)findViewById(R.id.txtQueueTime);
        settings=getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        savedQueue=getSharedPreferences(Config.sharedPrefQueue, MODE_PRIVATE);
        userId=settings.getInt("userId",0);
        queueJson=savedQueue.getString("queue","none");

        alertBroadcastReceiver=new AlertBroadcastReceiver();

        btnQueue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                syncQueue();
            }
        });
        btnCancelQueue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopQueue();
            }
        });

        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });

        if(queueJson.equals("none")==false){
            try {
                JSONObject data=new JSONObject(queueJson);
                txtQueueNum.setText(String.valueOf(data.getInt("order")));
                if(data.getString("timeToCall").equals("none")==true){
                    txtQueueTime.setText("--:--:--");
                }else{
                    txtQueueTime.setText(data.getString("timeToCall"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }else{
            txtQueueNum.setText("-");
            txtQueueTime.setText("--:--:--");
        }
    }

    private void syncQueue(){
        String encodedId= EncodeDecode.encode(userId);
        Call<Object> call= ApiClient.connect().getQueue(encodedId);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        JSONObject data=obj.getJSONObject("data");
                        if(data.has("time_to_call")){
                            String title="Antrian Siap";
                            String description="Anda antrian ke-"+data.getInt("order");
                            alertBroadcastReceiver.startAlert(getApplicationContext(),1,data.getString("time_alert"),title,description);
                            Queue queue;
                            if(data.getString("show_time").equals("yes")==true){
                                txtQueueTime.setText(data.getString("time_to_call"));
                                queue=new Queue(data.getInt("order"),data.getString("time_alert"),data.getString("time_to_call"));
                            }else{
                                txtQueueTime.setText("--:--:--");
                                queue=new Queue(data.getInt("order"),data.getString("time_alert"),"none");
                            }
                            txtQueueNum.setText(String.valueOf(data.getInt("order")));

                            SharedPreferences.Editor editor= savedQueue.edit();
                            Gson gson=new Gson();
                            queueJson=gson.toJson(queue);
                            editor.putString("queue",queueJson);
                            editor.commit();

                            Toast.makeText(getApplicationContext(),description,Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getApplicationContext(),"Antrian kosong",Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private void stopQueue(){
        alertBroadcastReceiver.cancelAlert(getApplicationContext(),1);
        txtQueueNum.setText("-");
        txtQueueTime.setText("--:--:--");
        SharedPreferences.Editor editor= savedQueue.edit();
        editor.putString("queue","none");
        editor.commit();
        Toast.makeText(getApplicationContext(),"Pengingat dibatalkan",Toast.LENGTH_SHORT).show();
    }
}
