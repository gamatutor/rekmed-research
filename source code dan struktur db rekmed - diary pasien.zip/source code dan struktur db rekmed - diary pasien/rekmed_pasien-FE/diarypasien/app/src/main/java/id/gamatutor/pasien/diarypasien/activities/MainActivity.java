package id.gamatutor.pasien.diarypasien.activities;

import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.login.LoginManager;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.BuildConfig;
import id.gamatutor.pasien.diarypasien.objects.Credentials;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.objects.Record;
import id.gamatutor.pasien.diarypasien.adapters.RecordAdapter;
import id.gamatutor.pasien.diarypasien.receivers.MedicineBroadcastReceiver;
import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private SharedPreferences settings, settingServer, totalReminderId, savedObat, savedQueue;
    private int userId;
    private List<Record> recordList=new ArrayList<>();
    private RecyclerView recyclerView;
    private RecordAdapter recordAdapter;
    private float y1,y2;
    private TextView txtNameNav, txtEmailNav, txtUpdate;
    private ImageView imgProfileNav;
    private MedicineBroadcastReceiver medicineBroadcastReceiver;
    private SwipeRefreshLayout swipeRefresh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
                startActivity(new Intent(getApplicationContext(),AddRecordActivity.class));
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        View hView =  navigationView.getHeaderView(0);
        txtNameNav=(TextView)hView.findViewById(R.id.txtNameNav);
        txtEmailNav=(TextView)hView.findViewById(R.id.txtEmailNav);
        imgProfileNav=(ImageView)hView.findViewById(R.id.imgProfileNav);

//        Initialize
        settings=getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        settingServer=getSharedPreferences(Config.sharedPrefServer, MODE_PRIVATE);
        totalReminderId=getSharedPreferences(Config.sharedPrefTotalReminderId,MODE_PRIVATE);
        savedObat=getSharedPreferences(Config.sharedPrefObat,MODE_PRIVATE);
        savedQueue=getSharedPreferences(Config.sharedPrefQueue,MODE_PRIVATE);
        txtUpdate=(TextView)findViewById(R.id.txtUpdate);
        swipeRefresh=(SwipeRefreshLayout)findViewById(R.id.swipeRefreshRecord);

        recyclerView=(RecyclerView)findViewById(R.id.recyclerView);
        recordAdapter=new RecordAdapter(getApplicationContext(),recordList);
        RecyclerView.LayoutManager mLayoutManager=new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(recordAdapter);

        Config.baseUrl=settingServer.getString("server", Config.getBaseUrl());
        userId=settings.getInt("userId",0);
//        if cannot find saved userId, then go to login
        if(userId==0){
            startActivity(new Intent(this,LoginActivity.class));
        }else{
            swipeRefresh.setRefreshing(true);
            getBasicCredentials(userId);
            recordList.clear();
            recordAdapter.notifyDataSetChanged();
            prepareRecordData();
        }

        txtUpdate.setVisibility(View.GONE);
        checkUpdates();
        txtUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=id.gamatutor.pasien.diarypasien")));
            }
        });
        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefresh.setRefreshing(true);
                recordList.clear();
                recordAdapter.notifyDataSetChanged();
                prepareRecordData();
            }
        });
//        handle search
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            String query = intent.getStringExtra(SearchManager.QUERY);
            Toast.makeText(getApplicationContext(),query,Toast.LENGTH_SHORT).show();
            //use the query to search your data somehow
        }
    }

    private void checkUpdates() {
        Call<Object> call= ApiClient.connect().getUpdates(BuildConfig.VERSION_CODE);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        txtUpdate.setText(obj.getString("message"));
                        txtUpdate.setVisibility(View.VISIBLE);
                    }else{
                        Log.i("UPDATE",obj.getString("message"));
                        txtUpdate.setVisibility(View.GONE);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private void prepareRecordData() {
        String encodedId= EncodeDecode.encode(userId);
        Call<Object> call= ApiClient.connect().getRecords(encodedId);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        JSONArray arrdata=obj.getJSONArray("data");
                        for(int i=0;i<arrdata.length();i++){
                            JSONObject data=arrdata.getJSONObject(i);
                            Log.i("RECORDS",data.toString());
                            Record record=new Record(data.getInt("id"),data.getString("title"),data.getString("content"),data.getString("updated_at"));
                            record.setFiletype(data.getString("filetype"));
                            if(data.getString("filetype").equals("none")==false){
                                record.setAttachment(Config.getBaseUrl()+"/uploads/"+data.getString("attachment"));
                            }
                            recordList.add(record);
                        }
//                        add empty record
                        Record record=new Record(0,"","","");
                        recordList.add(record);
                        recordAdapter.notifyDataSetChanged();
                        swipeRefresh.setRefreshing(false);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);

        // Associate searchable configuration with the SearchView
        SearchManager searchManager=(SearchManager)getSystemService(SEARCH_SERVICE);
        SearchView searchView=(SearchView)menu.findItem(R.id.action_search).getActionView();
//        search in another activity
        ComponentName cn = new ComponentName(this, SearchResultsActivity.class);
        searchView.setSearchableInfo(searchManager.getSearchableInfo(cn));
//        search in own activity
//        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_refresh) {
//            recordList.clear();
//            recordAdapter.notifyDataSetChanged();
//            prepareRecordData();
//        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_medicine) {
            startActivity(new Intent(getApplicationContext(),MedicineActivity.class));
        } else if (id == R.id.nav_queue) {
            startActivity(new Intent(getApplicationContext(),QueueActivity.class));
        } else if (id == R.id.nav_promo) {
            startActivity(new Intent(getApplicationContext(),PromoActivity.class));
        } else if (id == R.id.nav_account) {
            startActivity(new Intent(getApplicationContext(),AccountActivity.class));
        } else if (id == R.id.nav_password) {
            startActivity(new Intent(getApplicationContext(),PasswordActivity.class));
        } else if (id == R.id.nav_logout) {
            doLogout();
//        } else if (id == R.id.nav_setting){
//            startActivity(new Intent(getApplicationContext(),SettingActivity.class));
        } else if (id == R.id.nav_about){
            startActivity(new Intent(getApplicationContext(),AboutActivity.class));
        } else if (id == R.id.nav_whatsapp){
            PackageManager pm=getPackageManager();
            try {
                PackageInfo info=pm.getPackageInfo("com.whatsapp",PackageManager.GET_META_DATA);
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.setPackage("com.whatsapp");
                intent.putExtra(Intent.EXTRA_TEXT,"Saya telah menggunakan "+getResources().getString(R.string.app_name)+", unduh aplikasinya di https://play.google.com/store/apps/details?id=id.gamatutor.pasien.diarypasien");
                startActivity(intent);
            } catch (PackageManager.NameNotFoundException e) {
                Toast.makeText(getApplicationContext(),"WhatsApp tidak terpasang di perangkat Anda",Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        } else if (id == R.id.nav_term){
            startActivity(new Intent(getApplicationContext(),TermActivity.class));
        } else if (id == R.id.nav_consult){
            startActivity(new Intent(getApplicationContext(),ConsultActivity.class));
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void doLogout() {
//        clear reminder obat
        int totalId=totalReminderId.getInt("total",0);
        if(totalId != 0){
            medicineBroadcastReceiver=new MedicineBroadcastReceiver();
            for(int i=100;i<=totalId;i++){
                medicineBroadcastReceiver.cancelAlert(getApplicationContext(),i);
            }
        }

        SharedPreferences.Editor editor=settings.edit();
        editor.clear();
        editor.commit();

        editor=totalReminderId.edit();
        editor.clear();
        editor.commit();

        editor=savedObat.edit();
        editor.clear();
        editor.commit();

        editor=savedQueue.edit();
        editor.clear();
        editor.commit();

        LoginManager.getInstance().logOut();

        Toast.makeText(getApplicationContext(),"Berhasil keluar, mengarahkan...",Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
        startActivity(intent);
    }

    private void getBasicCredentials(final int id) {
        String encodedId=EncodeDecode.encode(id);
        Log.i("ENCODED",encodedId);
        Call<Object> call=ApiClient.connect().getCredentials(encodedId);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                Log.i("RESPONSE",responseStr);
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_LONG).show();
                    }else{
                        JSONObject data=obj.getJSONObject("data");
                        DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
                        if(data.has("email")){
                            Config.credentials=new Credentials(id,data.getString("email"));
                            txtEmailNav.setText(Config.credentials.getEmail());
                        }
                        if(data.has("name")){
                            Config.credentials.setName(data.getString("name"));
                            txtNameNav.setText(Config.credentials.getName());
                        }
                        if(data.has("address")){
                            Config.credentials.setAddress(data.getString("address"));
                        }
                        if(data.has("birth_at")){
                            try {
                                Config.credentials.setBirth(dateFormat.parse(data.getString("birth_at")));
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                        }
                        if(data.has("gender")){
                            if(data.getString("gender").equals("MALE")){
                                Config.credentials.setGender(1);
                            }else{
                                Config.credentials.setGender(0);
                            }
                        }
                        if(data.has("phone")){
                            Config.credentials.setPhone(data.getString("phone"));
                        }
                        if(data.has("kelurahan_id")){
                            Config.credentials.setKelurahanId(data.getString("kelurahan_id"));
                        }
                        if(data.has("mr")){
                            Log.i("MR",data.getJSONArray("mr").toString());
                            List<String> mrsList=new ArrayList<String>();
                            JSONArray arrdata=data.getJSONArray("mr");
                            for(int i=0;i<arrdata.length();i++){
                                mrsList.add(arrdata.get(i).toString());
                            }
                            Config.credentials.setMrs(mrsList);
                        }
                        if(data.has("img")){
                            if(data.getString("img").equals("")){
                                imgProfileNav.setImageResource(R.drawable.anonymous);
                            }else{
                                Config.credentials.setImg(data.getString("img"));
                                Picasso.with(getApplicationContext())
                                        .load(Config.getBaseUrl()+"/uploads/"+ Config.credentials.getImg())
                                        .resize(60,60)
                                        .centerCrop()
                                        .into(imgProfileNav);
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }
}
