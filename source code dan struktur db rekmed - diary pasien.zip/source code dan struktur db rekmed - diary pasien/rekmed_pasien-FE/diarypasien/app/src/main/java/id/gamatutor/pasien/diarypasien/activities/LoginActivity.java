package id.gamatutor.pasien.diarypasien.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.gson.Gson;
import com.wang.avi.AVLoadingIndicatorView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.Credentials;
import id.gamatutor.pasien.diarypasien.objects.FBClient;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    EditText editEmailLogin,editPasswordLogin;
    Button btnLogin;
    TextView txtSignup,txtAlertLogin,txtForgot;
    AVLoadingIndicatorView loadingLogin;
    ImageView imgLogo;
    SharedPreferences settings;
    LoginButton fbLogin;
    CallbackManager callbackManager;
    String rmAccessToken;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
//        Initialize
        editEmailLogin=(EditText)findViewById(R.id.editEmailLogin);
        editPasswordLogin=(EditText)findViewById(R.id.editPasswordLogin);
        btnLogin=(Button)findViewById(R.id.btnLogin);
        txtSignup=(TextView)findViewById(R.id.txtSignup);
        txtAlertLogin=(TextView)findViewById(R.id.txtAlertLogin);
        loadingLogin=(AVLoadingIndicatorView)findViewById(R.id.loadingLogin);
        txtForgot=(TextView)findViewById(R.id.txtForgot);
        imgLogo=(ImageView)findViewById(R.id.imgLogo);
        settings = getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        fbLogin=(LoginButton)findViewById(R.id.fbLogin);

        fbLogin.setBackgroundResource(R.drawable.round_button_fb);
        txtAlertLogin.setVisibility(View.GONE);
        loadingLogin.hide();
        txtSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),SignupActivity.class));
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doLogin();
            }
        });
        txtForgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),ForgetActivity.class));
            }
        });
        callbackManager=CallbackManager.Factory.create();
        fbLogin.setReadPermissions("email");
        fbLogin.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                Log.i("FB_USER_ID",loginResult.getAccessToken().getUserId());
                Log.i("FB_ACCESS_TOKEN",loginResult.getAccessToken().getToken());
                String userId=loginResult.getAccessToken().getUserId();
                String accessToken=loginResult.getAccessToken().getToken();
                getAccessToken();
                getFBProfile(userId,accessToken);
            }

            @Override
            public void onCancel() {
                Log.i("FB_RESULT","FB LOGIN CANCELLED");
            }

            @Override
            public void onError(FacebookException error) {
                Log.e("FB_RESULT",error.toString());
            }
        });
//        fbLogin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                doFacebookLogin();
//            }
//        });
    }

    private void getAccessToken() {
        Call<Object> call= ApiClient.connect().getToken();
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                Log.i("TOKEN",responseStr);
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    rmAccessToken=obj.getString("data");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private void getFBProfile(String userId, String accessToken) {
        String fields="email,name,birthday,gender";
        Call<Object> call= FBClient.connect().getProfile(userId,fields,accessToken);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getString("gender").equals("male")){
                        fbLogin(obj.getString("email"),obj.getString("name"),1,rmAccessToken);
                    }else{
                        fbLogin(obj.getString("email"),obj.getString("name"),0,rmAccessToken);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.i("FB_RESPONSE",responseStr.toString());
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private void doFacebookLogin() {
        LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile"));
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    private void fbLogin(String email, String name, int gender, String accessToken) {
        imgLogo.setVisibility(View.INVISIBLE);
        loadingLogin.show();
        Call<Object> call= ApiClient.connect().fbLogin(email,name, gender, accessToken);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                loadingLogin.hide();
                imgLogo.setVisibility(View.VISIBLE);
                String responseStr=new Gson().toJson(response.body());
                Log.i("RESPONSE",responseStr.toString());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        txtAlertLogin.setText(obj.getString("message"));
                        txtAlertLogin.setVisibility(View.VISIBLE);
                    }else{
                        txtAlertLogin.setVisibility(View.GONE);
                        JSONObject data=obj.getJSONObject("data");
                        SharedPreferences.Editor editor=settings.edit();
                        editor.putInt("userId",data.getInt("id"));
                        editor.commit();
                        Config.credentials=new Credentials(data.getInt("id"),data.getString("email"));
                        Toast.makeText(getApplicationContext(),"Berhasil masuk, selamat datang "+data.getString("email"),Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),HomeActivity.class));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private void doLogin() {
        imgLogo.setVisibility(View.INVISIBLE);
        loadingLogin.show();
        Call<Object> call= ApiClient.connect().doLogin(editEmailLogin.getText().toString(),editPasswordLogin.getText().toString());
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                loadingLogin.hide();
                imgLogo.setVisibility(View.VISIBLE);
                String responseStr=new Gson().toJson(response.body());
                Log.i("RESPONSE",responseStr.toString());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        txtAlertLogin.setText(obj.getString("message"));
                        txtAlertLogin.setVisibility(View.VISIBLE);
                    }else{
                        txtAlertLogin.setVisibility(View.GONE);
                        JSONObject data=obj.getJSONObject("data");
                        SharedPreferences.Editor editor=settings.edit();
                        editor.putInt("userId",data.getInt("id"));
                        editor.commit();
                        Config.credentials=new Credentials(data.getInt("id"),data.getString("email"));
                        Toast.makeText(getApplicationContext(),"Berhasil masuk, selamat datang "+data.getString("email"),Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(),HomeActivity.class));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }
}
