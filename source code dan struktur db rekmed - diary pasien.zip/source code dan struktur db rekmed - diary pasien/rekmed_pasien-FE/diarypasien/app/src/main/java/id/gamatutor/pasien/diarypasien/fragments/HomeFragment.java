package id.gamatutor.pasien.diarypasien.fragments;


import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import id.gamatutor.pasien.diarypasien.activities.KlinikActivity;
import id.gamatutor.pasien.diarypasien.activities.RecordActivity;
import id.gamatutor.pasien.diarypasien.activities.SettingActivity;
import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.Cell;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.objects.Promo;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.activities.ConsultActivity;
import id.gamatutor.pasien.diarypasien.activities.MedicineActivity;
import id.gamatutor.pasien.diarypasien.activities.QueueActivity;
import id.gamatutor.pasien.diarypasien.adapters.MenuAdapter;
import id.gamatutor.pasien.diarypasien.adapters.SliderAdapter;
import me.relex.circleindicator.CircleIndicator;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.MODE_PRIVATE;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {
    private ViewPager viewPager;
    private CircleIndicator circleIndicator;
    private SliderAdapter sliderAdapter;
    private int currentPage,userId;
    private ArrayList<Promo> promos=new ArrayList<>();
    private SharedPreferences settings;
    private RecyclerView recyclerView;
    private MenuAdapter menuAdapter;
    private ArrayList<Cell> cells=new ArrayList<>();
    private TextView txtUpdate;
    private RelativeLayout slideshowLayout;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_home, container, false);
        viewPager=(ViewPager)view.findViewById(R.id.pager);
        circleIndicator=(CircleIndicator)view.findViewById(R.id.indicator);
        recyclerView=(RecyclerView)view.findViewById(R.id.recyclerView);
        txtUpdate=(TextView)view.findViewById(R.id.txtUpdate);
        slideshowLayout=(RelativeLayout)view.findViewById(R.id.slideshowLayout);
        settings= getContext().getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);

//        resize slideshow layout to 16:9
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        int height = width/16*9;
        ViewGroup.LayoutParams layoutParams=slideshowLayout.getLayoutParams();
        layoutParams.width=width;
        layoutParams.height=height;
        slideshowLayout.setLayoutParams(layoutParams);

        userId=settings.getInt("userId",0);
        sliderAdapter =new SliderAdapter(view.getContext(),promos);
        viewPager.setAdapter(sliderAdapter);

        final Handler handler=new Handler();
        final Runnable update=new Runnable() {
            @Override
            public void run() {
                if(currentPage==promos.size()){
                    currentPage=0;
                }
                viewPager.setCurrentItem(currentPage++,true);
            }
        };
        Timer swipeTimer=new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(update);
            }
        },2500,2500);

        initSlideshow();

        recyclerView.setLayoutManager(new GridLayoutManager(view.getContext(),3));
        menuAdapter=new MenuAdapter(view.getContext(),cells);
        recyclerView.setAdapter(menuAdapter);

        recyclerView.setFocusable(false);
        viewPager.setFocusable(false);

        loadMenu();
        Config.checkUpdates(txtUpdate);

        txtUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=id.gamatutor.pasien.diarypasien")));
            }
        });

        return view;
    }

    private void loadMenu() {
        cells.clear();

        Intent intent = new Intent(getContext(),KlinikActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Cell cell=new Cell(1,R.drawable.icon_calendar_add,"Daftar Online",intent);
        cells.add(cell);

        intent = new Intent(getContext(),RecordActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        cell=new Cell(2,R.drawable.icon_write,"Catatan Medis",intent);
        cells.add(cell);

        intent = new Intent(getContext(),ConsultActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        cell=new Cell(3,R.drawable.icon_heart_rate,"Pengingat Periksa",intent);
        cells.add(cell);

        intent = new Intent(getContext(),QueueActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        cell=new Cell(4,R.drawable.icon_human,"Pengingat Antrian",intent);
        cells.add(cell);

        intent = new Intent(getContext(),MedicineActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        cell=new Cell(5,R.drawable.icon_nutrition,"Pengingat Obat",intent);
        cells.add(cell);

        intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.setPackage("com.whatsapp");
        intent.putExtra(Intent.EXTRA_TEXT,"Saya telah menggunakan "+getResources().getString(R.string.app_name)+", unduh aplikasinya di https://play.google.com/store/apps/details?id=id.gamatutor.pasien.diarypasien");
        cell=new Cell(6,R.drawable.icon_whatsapp,"Buka WhatsApp",intent);
        cells.add(cell);

        if(Config.development==true){
            intent = new Intent(getContext(),SettingActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            cell=new Cell(7,R.drawable.icon_wrench,"Pengaturan",intent);
            cells.add(cell);
        }
    }

    private void initSlideshow() {
        String encodedId= EncodeDecode.encode(userId);
        Call<Object> call= ApiClient.connect().getPromo(encodedId);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                Log.d("DEBUG",responseStr);
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        JSONArray arrdata=obj.getJSONArray("data");
                        for(int i=0;i<arrdata.length();i++){
                            JSONObject data=arrdata.getJSONObject(i);
                            Log.i("DATA",data.toString());
                            promos.add(
                                    new Promo(
                                            data.getString("title"),
                                            data.getString("description"),
                                            Config.getBaseUrl()+"/uploads/"+data.getString("img"),
                                            data.getString("url")
                                    ));
                            sliderAdapter.notifyDataSetChanged();
                            circleIndicator.setViewPager(viewPager);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

}
