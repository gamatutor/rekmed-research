package id.gamatutor.pasien.diarypasien.components;

import dagger.Component;
import id.gamatutor.pasien.diarypasien.adapters.MedicineAdapter;
import id.gamatutor.pasien.diarypasien.modules.MedicineModule;

@Component(modules= {MedicineModule.class})
public interface ComponentMedicine {
    MedicineAdapter getAdapter();
}
