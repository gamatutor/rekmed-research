package id.gamatutor.pasien.diarypasien.adapters;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.activities.EditReminderActivity;
import id.gamatutor.pasien.diarypasien.activities.ReminderListActivity;
import id.gamatutor.pasien.diarypasien.models.ReminderDetailModel;
import id.gamatutor.pasien.diarypasien.models.ReminderModel;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.objects.Reminder;
import id.gamatutor.pasien.diarypasien.objects.ReminderDetail;
import id.gamatutor.pasien.diarypasien.receivers.MedicineBroadcastReceiver;

public class ReminderAdapter extends RecyclerView.Adapter<ReminderAdapter.MyViewHolder> {
    private Context context;
    private List<ReminderDetail> schedules;
    private MedicineBroadcastReceiver medicineBroadcastReceiver;
    private ReminderDetailModel reminderDetailModel;

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView title, subtitle;
        public SwitchCompat switchReminder;
        public View separatorReminder;
        public MyViewHolder(View itemView) {
            super(itemView);
            title=(TextView)itemView.findViewById(R.id.txtTitleReminder);
            subtitle=(TextView)itemView.findViewById(R.id.txtSubtitleReminder);
            switchReminder=(SwitchCompat)itemView.findViewById(R.id.switchReminder);
            separatorReminder=(View)itemView.findViewById(R.id.separatorReminder);
        }
    }

    public ReminderAdapter(Context context,List<ReminderDetail> schedules){
        this.context=context;
        this.schedules=schedules;
        this.reminderDetailModel=new ReminderDetailModel();
        medicineBroadcastReceiver=new MedicineBroadcastReceiver();
    }

    @Override
    public ReminderAdapter.MyViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.reminder_list_row,parent,false);
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ReminderDetail reminderDetail = schedules.get(parent.indexOfChild(v));
                Intent intent=new Intent(context,EditReminderActivity.class);
                intent.putExtra("pid",reminderDetail.getPid());
                context.startActivity(intent);
            }
        });
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ReminderAdapter.MyViewHolder holder, final int position) {
        final Calendar calendar=Calendar.getInstance();
        ReminderDetail reminderDetail=schedules.get(position);
        Log.d("DEBUG",reminderDetail.toString());
        calendar.setTimeInMillis(reminderDetail.getCalendarMillis());
        final int pid = reminderDetail.getPid();
        holder.title.setText(reminderDetail.getTitle());
        holder.subtitle.setText(doFormatDay(calendar.get(Calendar.DAY_OF_WEEK))+", "+calendar.get(Calendar.DATE)+" "+doFormatDate(calendar.get(Calendar.MONTH))+" "+calendar.get(Calendar.YEAR)+" "+doFormat(calendar.get(Calendar.HOUR_OF_DAY))+":"+doFormat(calendar.get(Calendar.MINUTE)));
        if(reminderDetail.isActive()==true){
            holder.switchReminder.setChecked(true);
        }else{
            holder.switchReminder.setChecked(false);
        }
        holder.switchReminder.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                try{
                    ReminderDetail reminderDetail=schedules.get(position);
                    Bundle bundle=new Bundle();
                    bundle.putString("title",reminderDetail.getTitle());
                    bundle.putLong("calendarMillis",reminderDetail.getCalendarMillis());
                    if(isChecked==true){
                        bundle.putBoolean("isActive",true);
                        medicineBroadcastReceiver.startAlertbyPid(context,pid,calendar);
                        Toast.makeText(context,"Pengingat diaktifkan",Toast.LENGTH_SHORT).show();
                    }else{
                        bundle.putBoolean("isActive",false);
                        medicineBroadcastReceiver.cancelAlert(context,pid);
                        Toast.makeText(context,"Pengingat dibatalkan",Toast.LENGTH_SHORT).show();
                    }
                    reminderDetailModel.updateItem(reminderDetail.getPid(),bundle);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }

    private String doFormatDay(int i) {
        List<String> hari=new ArrayList<>();
        hari.add("");
        hari.add("Minggu");
        hari.add("Senin");
        hari.add("Selasa");
        hari.add("Rabu");
        hari.add("Kamis");
        hari.add("Jumat");
        hari.add("Sabtu");

        return hari.get(i);
    }

    private String doFormatDate(int i) {
        List<String> bulan=new ArrayList<>();
        bulan.add("Januari");
        bulan.add("Februari");
        bulan.add("Maret");
        bulan.add("April");
        bulan.add("Mei");
        bulan.add("Juni");
        bulan.add("Juli");
        bulan.add("Agustus");
        bulan.add("September");
        bulan.add("Oktober");
        bulan.add("Nopember");
        bulan.add("Desember");

        return bulan.get(i);
    }

    @Override
    public int getItemCount() {
        return schedules.size();
    }

    private String doFormat(int i) {
        if(i < 10){
            return "0"+i;
        }else{
            return i+"";
        }
    }
}
