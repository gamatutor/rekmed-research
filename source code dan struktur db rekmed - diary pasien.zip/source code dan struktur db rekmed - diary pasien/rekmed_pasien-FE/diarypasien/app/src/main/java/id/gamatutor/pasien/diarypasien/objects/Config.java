package id.gamatutor.pasien.diarypasien.objects;

import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import id.gamatutor.pasien.diarypasien.BuildConfig;
import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by zmachmobile on 4/15/17.
 */

public class Config {
    public static String baseUrl="http://192.168.33.10/rekmed-api/public/";
    public static String termUrl="http://api.rekmed.com/term";
    public static String fbUrl="https://graph.facebook.com";
    public static final String sharedPrefName = "DiaryPasienPrefs";
    public static final String sharedPrefServer = "DiaryPasienServerPref";
    public static final String sharedPrefObat = "DiaryPasienObatPref";
    public static final String sharedPrefQueue = "DiaryPasienQueuePref";
    public static final String sharedPrefConsult = "DiaryPasienConsultPref";
    public static final String sharedPrefTotalReminderId = "DiaryPasienTotRemIdPref";
    public static Credentials credentials;
    public static boolean development=false;
    public static int currentReminderId;

    public static String getBaseUrl(){
        if(development==false){
            return "http://api.rekmed.com";
        }else{
            return baseUrl;
        }
    }

    public static void checkUpdates(final TextView txtUpdate) {
        txtUpdate.setVisibility(View.GONE);
        Call<Object> call= ApiClient.connect().getUpdates(BuildConfig.VERSION_CODE);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        txtUpdate.setText(obj.getString("message"));
                        txtUpdate.setVisibility(View.VISIBLE);
                    }else{
                        Log.i("UPDATE",obj.getString("message"));
                        txtUpdate.setVisibility(View.GONE);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }
}
