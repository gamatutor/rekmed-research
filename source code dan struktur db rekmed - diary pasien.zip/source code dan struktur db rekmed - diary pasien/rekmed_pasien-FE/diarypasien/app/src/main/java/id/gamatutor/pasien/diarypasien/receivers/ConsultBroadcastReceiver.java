package id.gamatutor.pasien.diarypasien.receivers;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;

import java.util.Calendar;
import java.util.Random;

import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.activities.ConsultActivity;

import static android.content.Context.NOTIFICATION_SERVICE;

public class ConsultBroadcastReceiver extends BroadcastReceiver {
    Bundle extras;
    String title;
    @Override
    public void onReceive(Context context, Intent intent) {
        extras=intent.getExtras();
        title=extras.getString("title");
        Intent mainIntent;
        PendingIntent pendingIntent;
        mainIntent=new Intent(context, ConsultActivity.class);
        pendingIntent=PendingIntent.getActivity(context,0,mainIntent,PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(context)
                        .setSmallIcon(R.drawable.logo_mini)
                        .setContentTitle(title)
                        .setContentIntent(pendingIntent)
                        .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        Random random = new Random();
        int randomized = random.nextInt(9999 - 1000) + 1000;
        notificationManager.notify(randomized, mBuilder.build());
    }

    public void startAlert(Context context, int pid, String title, String due){
        AlarmManager alarmMgr;
        PendingIntent alarmIntent;
        Intent pendingintent;

        alarmMgr = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        pendingintent = new Intent(context, ConsultBroadcastReceiver.class);

        String tanggal=due.split(" ")[0];
        String waktu=due.split(" ")[1];
        Calendar calendar=Calendar.getInstance();
        int year=Integer.parseInt(tanggal.split("-")[0]);
        int month=Integer.parseInt(tanggal.split("-")[1])-1;
        int day=Integer.parseInt(tanggal.split("-")[2]);
        int hour=Integer.parseInt(waktu.split(":")[0]);
        int minute=Integer.parseInt(waktu.split(":")[1]);
        calendar.set(Calendar.YEAR,year);
        calendar.set(Calendar.MONTH,month);
        calendar.set(Calendar.DAY_OF_MONTH,day);
        calendar.set(Calendar.HOUR_OF_DAY,hour);
        calendar.set(Calendar.MINUTE,minute);
        calendar.set(Calendar.SECOND,0);

        pendingintent.putExtra("title",title);
        alarmIntent= PendingIntent.getBroadcast(context,pid,pendingintent,PendingIntent.FLAG_UPDATE_CURRENT);
        alarmMgr.set(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),alarmIntent);
    }

    public void cancelAlert(Context context,int pid){
        AlarmManager alarmMgr;
        PendingIntent alarmIntent;
        Intent pendingintent;
        pendingintent = new Intent(context, ConsultBroadcastReceiver.class);
        alarmIntent = PendingIntent.getBroadcast(context, pid, pendingintent, PendingIntent.FLAG_UPDATE_CURRENT);
        alarmMgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmMgr.cancel(alarmIntent);
    }
}
