package id.gamatutor.pasien.diarypasien.adapters;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Handler;

import id.gamatutor.pasien.diarypasien.activities.MedicineActivity;
import id.gamatutor.pasien.diarypasien.activities.ReminderListActivity;
import id.gamatutor.pasien.diarypasien.models.ReminderDetailModel;
import id.gamatutor.pasien.diarypasien.models.ReminderModel;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.objects.KeyValue;
import id.gamatutor.pasien.diarypasien.objects.Reminder;
import id.gamatutor.pasien.diarypasien.receivers.MedicineBroadcastReceiver;
import io.realm.Realm;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by zmachmobile on 4/30/17.
 */

public class MedicineAdapter extends RecyclerView.Adapter<MedicineAdapter.MyViewHolder> {
    private SharedPreferences savedObat;
    private ArrayList<Reminder> reminderList;
    private Context context;
    private String savedObatJson;
    private MedicineBroadcastReceiver medicineBroadcastReceiver;
    private ReminderModel reminderModel;
    private ReminderDetailModel reminderDetailModel;

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView title, content, tanggal, jadwal;
        public SwitchCompat switchMedicine;
        public MyViewHolder(View itemView) {
            super(itemView);
            title=(TextView)itemView.findViewById(R.id.txtTitleMedicine);
            content=(TextView)itemView.findViewById(R.id.txtContentMedicine);
            tanggal=(TextView)itemView.findViewById(R.id.txtDateMedicine);
            jadwal=(TextView)itemView.findViewById(R.id.txtScheduleMedicine);
            switchMedicine=(SwitchCompat)itemView.findViewById(R.id.switchMedicine);
        }
    }
    public MedicineAdapter (Context context,ArrayList<Reminder> reminderList){
        this.context=context;
        this.reminderList=reminderList;
        savedObat=context.getSharedPreferences(Config.sharedPrefObat, MODE_PRIVATE);
        medicineBroadcastReceiver=new MedicineBroadcastReceiver();
        this.reminderModel=new ReminderModel();
        this.reminderDetailModel=new ReminderDetailModel();
    }
    @Override
    public MedicineAdapter.MyViewHolder onCreateViewHolder(final ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.medicine_list_row,parent,false);
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Reminder reminder= reminderList.get(parent.indexOfChild(v));
                Intent intent=new Intent(context,ReminderListActivity.class);
                intent.putExtra("reminderId",reminderList.get(parent.indexOfChild(v)).getPid());
                Config.currentReminderId = reminderList.get(parent.indexOfChild(v)).getPid();
                context.startActivity(intent);
            }
        });
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final MedicineAdapter.MyViewHolder holder, int position) {
        Log.d("debug","call again");
        final Reminder reminder= reminderList.get(position);
        holder.title.setText(reminder.getObat());
        holder.content.setText("Dosis "+reminder.getSigna()+" kali sehari");
        if(reminder.getActive()==true){
            holder.switchMedicine.setChecked(true);
        }else{
            holder.switchMedicine.setChecked(false);
        }
        holder.tanggal.setText("Exp : "+reminder.getExpired());
        int startHour=6;
        String jadwal="Aktif : ";
        ArrayList<String> hours = new ArrayList<String>();
        for(int i=0;i<reminderDetailModel.getItemByPid(reminder.getPid()).size();i++){
            Calendar calendar=Calendar.getInstance();
            calendar.setTimeInMillis(reminderDetailModel.getItemByPid(reminder.getPid()).get(i).getCalendarMillis());
            String hour = doFormat(calendar.get(Calendar.HOUR_OF_DAY))+":"+doFormat(calendar.get(Calendar.MINUTE));
            if(hours.contains(hour)==false){
                hours.add(hour);
            }
        }
        Log.d("HOURS",hours.toString());
        jadwal += doJoin(hours);

        holder.jadwal.setText(jadwal);
        holder.switchMedicine.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                try{
                    final ArrayList<Bundle> schedules = new ArrayList<>();
                    final Bundle bundle=new Bundle();
                    bundle.putInt("pid",reminder.getPid());
                    bundle.putString("obat",reminder.getObat());
                    bundle.putInt("signa",reminder.getSigna());
                    bundle.putString("expired",reminder.getExpired());
                    bundle.putInt("amount",reminder.getAmount());

                    if(isChecked==true){
                        holder.switchMedicine.setChecked(true);
                        reminderDetailModel.updateAll(reminder.getPid(),true);
                        medicineBroadcastReceiver.startAlert(context,reminderDetailModel.getItemByPid(reminder.getPid()));
                        Toast.makeText(context,"Pengingat diaktifkan",Toast.LENGTH_SHORT).show();
                    }else{
                        holder.switchMedicine.setChecked(false);
                        for(int i=0;i<reminder.getAmount();i++){
                            medicineBroadcastReceiver.cancelAlert(context,reminder.getPid()+i);
                        }
                        reminderDetailModel.updateAll(reminder.getPid(),false);
                        bundle.putSerializable("schedules",schedules);
                        bundle.putBoolean("isActive",false);
                        Toast.makeText(context,"Pengingat dibatalkan",Toast.LENGTH_SHORT).show();
                    }
                    reminderModel.updateItem(reminder.getPid(),bundle);
                    Log.d("DB",reminderModel.getAll().toString());
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }

    private String doJoin(ArrayList<String> hours) {
        String result="";
        for(int i=0;i<hours.size();i++){
            if(i<hours.size()-1){
                result += hours.get(i)+", ";
            }else{
                result += hours.get(i);
            }
        }
        return result;
    }

    private String doFormat(int i) {
        if(i < 10){
            return "0"+i;
        }else{
            return i+"";
        }
    }

    @Override
    public int getItemCount() {
        return reminderList.size();
    }
}
