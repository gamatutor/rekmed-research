package id.gamatutor.pasien.diarypasien.activities;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.ThreadLocalRandom;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.models.ReminderDetailModel;
import id.gamatutor.pasien.diarypasien.objects.Config;

public class AddReminderActivity extends AppCompatActivity{

    @BindView(R.id.imgBack) ImageView imgBack;
    @BindView(R.id.editTitle) EditText title;
    @BindView(R.id.txtDueDate) TextView dueDate;
    @BindView(R.id.txtDueTime) TextView dueTime;
    @BindView(R.id.btnSubmit) Button submit;
    ReminderDetailModel reminderDetailModel;
    static TextView dueTimeStatic;
    private DatePickerDialog.OnDateSetListener setDueDate;
    private int selectedDay, selectedMonth, selectedYear;
    private static int selectedHour, selectedMinute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_reminder);

        ButterKnife.bind(this);
        dueTimeStatic = dueTime;

        reminderDetailModel=new ReminderDetailModel();

        setDueDate=new DatePickerDialog.OnDateSetListener(){
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                selectedDay = dayOfMonth;
                selectedMonth = month;
                selectedYear = year;
                Calendar cal=Calendar.getInstance();
                cal.set(year,month,dayOfMonth);
                DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
                dueDate.setText(dateFormat.format(cal.getTime()));
            }
        };
    }

    @OnClick(R.id.imgBack)
    void getBack(){
        finish();
        overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @OnClick(R.id.txtDueDate)
    void openCalendar(){
        Calendar calendar=Calendar.getInstance();
        new DatePickerDialog(this,setDueDate, calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    @OnClick(R.id.txtDueTime)
    void openTimePicker(){
        DialogFragment newFragment=new AddReminderActivity.TimePickerFragment();
        newFragment.show(getFragmentManager(),"timePicker");
    }

    @OnClick(R.id.btnSubmit)
    void doSubmit(){
        Calendar calendar=Calendar.getInstance();
        calendar.set(selectedYear,selectedMonth,selectedDay,selectedHour,selectedMinute);
        Bundle bundle = new Bundle();
        bundle.putInt("reminderId",Config.currentReminderId);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            bundle.putInt("pid", reminderDetailModel.getLastPid()+1);
        }
        bundle.putString("title",title.getText().toString());
        bundle.putLong("calendarMillis",calendar.getTimeInMillis());
        bundle.putBoolean("isActive",true);
        reminderDetailModel.addItem(bundle);
        finish();
    }

    public static class TimePickerFragment extends DialogFragment implements TimePickerDialog.OnTimeSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            Calendar calendar=Calendar.getInstance();
            return new TimePickerDialog(getActivity(),this,calendar.get(Calendar.HOUR_OF_DAY),calendar.get(Calendar.MINUTE),true);
        }

        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            selectedHour = hourOfDay;
            selectedMinute = minute;
            String jam=String.valueOf(hourOfDay);
            if(hourOfDay < 10){
                jam="0"+hourOfDay;
            }
            String menit=String.valueOf(minute);
            if(minute < 10){
                menit="0"+menit;
            }
            dueTimeStatic.setText(jam+":"+menit);
        }
    }
}
