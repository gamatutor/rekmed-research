package id.gamatutor.pasien.diarypasien.objects;


import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by zmachmobile on 4/16/17.
 */

public class Record {
    private int id;
    private String title, content, attachment, mr_number, updated_at, filetype;
    private Timestamp modified;

    public Record(int id, String title, String content, String updated_at){
        this.id=id;
        this.title=title;
        this.content=content;
        this.updated_at=updated_at;
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
        try {
            Date parsedDate=simpleDateFormat.parse(updated_at);
            this.modified=new Timestamp(parsedDate.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }

    }

    public void setTitle(String title){
        this.title=title;
        this.modified=new Timestamp(System.currentTimeMillis());
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
        this.updated_at=simpleDateFormat.format(this.modified);
    }

    public void setContent(String content){
        this.content=content;
        this.modified=new Timestamp(System.currentTimeMillis());
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
        this.updated_at=simpleDateFormat.format(this.modified);
    }

    public void setAttachment(String attachment){
        this.attachment=attachment;
        this.modified=new Timestamp(System.currentTimeMillis());
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
        this.updated_at=simpleDateFormat.format(this.modified);
    }

    public void setFiletype(String filetype){
        this.filetype=filetype;
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
        this.updated_at=simpleDateFormat.format(this.modified);
    }

    public void setMr_number(String mr_number){
        this.mr_number=mr_number;
        this.modified=new Timestamp(System.currentTimeMillis());
        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
        this.updated_at=simpleDateFormat.format(this.modified);
    }

    public int getId(){
        return this.id;
    }

    public String getTitle(){
        return this.title;
    }

    public String getContent(){
        return this.content;
    }

    public String getAttachment(){
        return this.attachment;
    }

    public String getMr_number(){
        return this.mr_number;
    }

    public Timestamp getModified(){
        return this.modified;
    }

    public String getFiletype(){
        return this.filetype;
    }
}
