package id.gamatutor.pasien.diarypasien.objects;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by zmachmobile on 6/29/17.
 */

public interface FBInterface {
    @GET("v2.9/{userId}")
    Call<Object> getProfile(@Path("userId") String userId, @Query("fields") String fields, @Query("access_token") String accessToken);
}
