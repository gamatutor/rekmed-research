package id.gamatutor.pasien.diarypasien.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wang.avi.AVLoadingIndicatorView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.Consult;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.adapters.ConsultAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ConsultActivity extends AppCompatActivity {
    private SharedPreferences savedConsult;
    private ImageView imgBack;
    private FloatingActionButton btnAdd;
    private RecyclerView recyclerView;
    private List<Consult> consultList=new ArrayList<>();
    private ConsultAdapter consultAdapter;
    private AVLoadingIndicatorView loadingConsult;
    private TextView txtInfo;
    private String savedConsultJson;
    private SwipeRefreshLayout swipeRefresh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consult);

        imgBack=(ImageView)findViewById(R.id.imgPeriksaBack);
        btnAdd=(FloatingActionButton) findViewById(R.id.fab);
        recyclerView=(RecyclerView)findViewById(R.id.recyclerPeriksa);
        loadingConsult=(AVLoadingIndicatorView)findViewById(R.id.loadingConsult);
        txtInfo=(TextView)findViewById(R.id.txtInfoConsult);
        savedConsult=getSharedPreferences(Config.sharedPrefConsult, MODE_PRIVATE);
        swipeRefresh=(SwipeRefreshLayout)findViewById(R.id.swipeRefreshConsult);

        savedConsultJson=savedConsult.getString("data","none");
        consultAdapter=new ConsultAdapter(getApplicationContext(),consultList);
        RecyclerView.LayoutManager mLayoutManager=new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(consultAdapter);

        loadingConsult.show();
        txtInfo.setVisibility(View.GONE);
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),HomeActivity.class));
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),AddConsultActivity.class));
            }
        });

        if(savedConsultJson.equals("none")==false){
//            getLocalData();
            loadData();
        }else{
            loadData();
        }
        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefresh.setRefreshing(true);
                loadData();
            }
        });
    }

    private void getLocalData() {
        loadingConsult.hide();
        consultList.clear();
        consultAdapter.notifyDataSetChanged();
        try {
            JSONArray arrdata=new JSONArray(savedConsultJson);
            for(int i=0;i<arrdata.length();i++){
                JSONObject data=arrdata.getJSONObject(i);
                Consult consult=new Consult(data.getInt("id"),data.getInt("pid"),data.getString("title"),data.getString("due"),data.getBoolean("active"));
                consultList.add(consult);
                consultAdapter.notifyDataSetChanged();
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void loadData() {
        consultList.clear();
        consultAdapter.notifyDataSetChanged();
        String encodedId= EncodeDecode.encode(Config.credentials.getId());
        Call<Object> call= ApiClient.connect().getConsults(encodedId);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                loadingConsult.hide();
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        txtInfo.setText(obj.getString("message"));
                        txtInfo.setVisibility(View.VISIBLE);
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        JSONArray arrdata=obj.getJSONArray("data");
                        if(arrdata.length()==0){
                            txtInfo.setText("Tidak ada data");
                            txtInfo.setVisibility(View.VISIBLE);
                        }
                        int sequenceId=1000;
                        for(int i=0;i<arrdata.length();i++){
                            JSONObject data=arrdata.getJSONObject(i);
                            Log.i("CONSULTS",data.toString());
                            boolean active=false;
                            if(data.getInt("active")==0){
                                active=false;
                            }else{
                                active=true;
                            }
                            Consult consult=new Consult(data.getInt("id"),sequenceId,data.getString("title"),data.getString("due"),active);
                            consultList.add(consult);
                            sequenceId++;
                        }
                        consultAdapter.notifyDataSetChanged();

                        SharedPreferences.Editor editor= savedConsult.edit();
                        Gson gson=new Gson();
                        editor.putString("data",gson.toJson(consultList));
                        editor.commit();
                        swipeRefresh.setRefreshing(false);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }
}
