package id.gamatutor.pasien.diarypasien.adapters;

import android.content.Context;
import android.graphics.Color;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.objects.Cell;

/**
 * Created by zmachmobile on 8/21/17.
 */

public class NavbarAdapter extends RecyclerView.Adapter<NavbarAdapter.MyViewHolder> {
    private ArrayList<Cell> cells;
    private int selectedPosition=0;
    private Context context;
    private FragmentManager fragmentManager;

    public NavbarAdapter(Context context,ArrayList<Cell> cells, FragmentManager fragmentManager){
        this.context=context;
        this.cells=cells;
        this.fragmentManager=fragmentManager;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.navbar_row,parent,false);
        return new NavbarAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final NavbarAdapter.MyViewHolder holder, final int position) {
        final Cell cell=cells.get(position);
        holder.miniLine.setBackgroundColor(Color.parseColor(cell.color));
        holder.miniLine.setVisibility(View.INVISIBLE);
        holder.imgIcon.setImageResource(cell.imageDrawable);
        holder.txtCaption.setText(cell.caption);

        if(position == selectedPosition){
            holder.miniLine.setVisibility(View.VISIBLE);
            holder.imgIcon.setColorFilter(Color.parseColor(cell.color));
            holder.txtCaption.setTextColor(Color.parseColor(cell.color));
        }else{
            holder.miniLine.setVisibility(View.INVISIBLE);
            holder.imgIcon.setColorFilter(Color.parseColor("#777777"));
            holder.txtCaption.setTextColor(Color.parseColor("#777777"));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedPosition=position;
                notifyDataSetChanged();

                fragmentManager.beginTransaction().replace(R.id.frameLayout,cell.fragment).commit();
            }
        });
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public int getItemCount() {
        return cells.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public View miniLine;
        public ImageView imgIcon;
        public TextView txtCaption;
        public MyViewHolder(View itemView) {
            super(itemView);
            miniLine=(View)itemView.findViewById(R.id.miniLine);
            imgIcon=(ImageView)itemView.findViewById(R.id.imgIcon);
            txtCaption=(TextView)itemView.findViewById(R.id.txtCaption);
        }
    }
}
