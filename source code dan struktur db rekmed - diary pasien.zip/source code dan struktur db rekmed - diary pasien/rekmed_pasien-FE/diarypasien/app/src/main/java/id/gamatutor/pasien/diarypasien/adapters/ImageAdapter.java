package id.gamatutor.pasien.diarypasien.adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zmachmobile on 5/7/17.
 */

public class ImageAdapter extends BaseAdapter {
    private Context mContext;
    private List<String> mThumbIds=new ArrayList<String>();

    public ImageAdapter(Context context, List<String> imageList) {
        mContext=context;
        mThumbIds=imageList;
    }

    @Override
    public int getCount() {
        return mThumbIds.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        if(convertView==null){
            imageView=new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams(250,250));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
//            imageView.setPadding(4,8,4,8);
        }else{
            imageView=(ImageView)convertView;
        }
        File photo=new File(mThumbIds.get(position));
        Picasso.with(mContext).load(photo).resize(100,100).into(imageView);
        return imageView;
    }
}
