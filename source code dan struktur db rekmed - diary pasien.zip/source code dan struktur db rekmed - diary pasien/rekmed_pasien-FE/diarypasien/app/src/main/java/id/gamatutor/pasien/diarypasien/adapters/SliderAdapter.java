package id.gamatutor.pasien.diarypasien.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import id.gamatutor.pasien.diarypasien.objects.Promo;
import id.gamatutor.pasien.diarypasien.R;

/**
 * Created by zmachmobile on 8/21/17.
 */

public class SliderAdapter extends PagerAdapter {
    private ArrayList<Promo> promos;
    private LayoutInflater inflater;
    private Context context;

    public SliderAdapter(Context context, ArrayList<Promo> promos){
        this.context=context;
        this.promos=promos;
        inflater=LayoutInflater.from(context);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return promos.size();
    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {
        View imageLayout=inflater.inflate(R.layout.slider_row,container,false);
        ImageView imageView=(ImageView)imageLayout.findViewById(R.id.image);
        Picasso.with(context).load(promos.get(position).getImg()).resize(1280,720).into(imageView);
        container.addView(imageLayout,0);
        imageLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    Promo promo=promos.get(position);
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(promo.getUrl()));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }catch (Exception e){
                    e.printStackTrace();
                }

            }
        });
        return imageLayout;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view.equals(object);
    }
}
