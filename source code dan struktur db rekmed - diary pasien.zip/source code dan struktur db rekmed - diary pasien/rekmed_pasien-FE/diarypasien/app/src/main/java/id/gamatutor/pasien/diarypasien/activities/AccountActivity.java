package id.gamatutor.pasien.diarypasien.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;

public class AccountActivity extends AppCompatActivity {

    private ImageView imgAccount,imgAccountBack,imgEditAccount;
    private TextView txtName, txtEmail, txtPhone, txtBirthAt, txtAddress, txtGender, txtKodeMR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        imgAccount=(ImageView)findViewById(R.id.imgAccount);
        imgEditAccount=(ImageView)findViewById(R.id.imgEditAccount);
        imgAccountBack=(ImageView)findViewById(R.id.imgAccountBack);
        txtName=(TextView)findViewById(R.id.txtAccountName);
        txtEmail=(TextView)findViewById(R.id.txtAccountEmail);
        txtPhone=(TextView)findViewById(R.id.txtAccountPhone);
        txtBirthAt=(TextView)findViewById(R.id.txtAccountBirthAt);
        txtAddress=(TextView)findViewById(R.id.txtAccountAddress);
        txtGender=(TextView)findViewById(R.id.txtAccountGender);
        txtKodeMR=(TextView)findViewById(R.id.txtAccountMR);

        try{
            txtName.setText(Config.credentials.getName());
        }catch (Exception e){
            e.printStackTrace();
        }
        try{
            txtEmail.setText(Config.credentials.getEmail());
        }catch (Exception e){
            e.printStackTrace();
        }
        try{
            txtPhone.setText(Config.credentials.getPhone());
        }catch (Exception e){
            e.printStackTrace();
        }

        DateFormat dateFormat=new SimpleDateFormat("dd-MMM-yyyy");
        try{
            txtBirthAt.setText(dateFormat.format(Config.credentials.getBirth()));
        }catch (Exception e){
            e.printStackTrace();
        }
        try{
            txtAddress.setText(Config.credentials.getAddress());
        }catch (Exception e){
            e.printStackTrace();
        }
        if(Config.credentials.getGender() == 0){
            txtGender.setText("WANITA");
        }else{
            txtGender.setText("PRIA");
        }
        if(Config.credentials.getImg()==null){
            imgAccount.setImageResource(R.drawable.anonymous);
        }else{
            try{
                Picasso.with(getApplicationContext())
                        .load(Config.getBaseUrl()+"/uploads/"+ Config.credentials.getImg())
                        .resize(150,150)
                        .centerCrop()
                        .into(imgAccount);
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        String mrs= Config.credentials.getMrs().toString();
        mrs=mrs.replaceAll("\\[", "").replaceAll("\\]","");
        Log.i("MRS",mrs);
        txtKodeMR.setText(mrs);

        imgAccountBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
        imgEditAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),EditAccountActivity.class));
            }
        });
    }
}
