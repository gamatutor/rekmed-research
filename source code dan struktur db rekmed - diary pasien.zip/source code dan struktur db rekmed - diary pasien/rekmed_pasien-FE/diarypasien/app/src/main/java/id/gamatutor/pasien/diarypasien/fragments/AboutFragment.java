package id.gamatutor.pasien.diarypasien.fragments;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import id.gamatutor.pasien.diarypasien.BuildConfig;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.objects.Config;

/**
 * A simple {@link Fragment} subclass.
 */
public class AboutFragment extends Fragment {

    private TextView txtUpdate;
    private TextView version, contactWeb, contactPhone;

    public AboutFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_about, container, false);
        txtUpdate=(TextView) view.findViewById(R.id.txtUpdate);

        Config.checkUpdates(txtUpdate);

        contactWeb = (TextView)view.findViewById(R.id.contactWeb);
        contactPhone = (TextView)view.findViewById(R.id.contactPhone);
        version = (TextView)view.findViewById(R.id.txtVersionAbout);

        contactWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(getResources().getString(R.string.contact_web)));
                startActivity(intent);
            }
        });
        contactPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://api.whatsapp.com/send?phone="+getResources().getString(R.string.contact_phone_number)));
                intent.setPackage("com.whatsapp");
                startActivity(intent);
            }
        });

        version.setText("v"+ BuildConfig.VERSION_NAME);
        return view;
    }

}
