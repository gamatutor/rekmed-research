package id.gamatutor.pasien.diarypasien.objects;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.Calendar;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class ReminderDetail extends RealmObject {
    private int reminderId;
    private int pid;
    private long calendarMillis;
    private boolean isActive;
    private String title;

    public ReminderDetail(){

    }

    public void setReminderId(int reminderId) {
        this.reminderId = reminderId;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setCalendarMillis(long calendarMillis) {
        this.calendarMillis = calendarMillis;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public int getReminderId() {
        return reminderId;
    }

    public int getPid() {
        return pid;
    }

    public String getTitle() {
        return title;
    }

    public boolean isActive() {
        return isActive;
    }

    public long getCalendarMillis() {
        return calendarMillis;
    }
}
