package id.gamatutor.pasien.diarypasien.objects;

import android.content.Intent;
import android.support.v4.app.Fragment;

/**
 * Created by zmachmobile on 8/21/17.
 */

public class Cell {
    public int imageDrawable,id;
    public String imageUrl, caption, color;
    public Intent intent;
    public Fragment fragment;
    public Cell(int id,int imageDrawable, String caption, Intent intent){
        this.imageDrawable=imageDrawable;
        this.caption=caption;
        this.id=id;
        this.intent=intent;
    }
    public Cell(int id,String imageUrl, String caption, Intent intent){
        this.imageUrl=imageUrl;
        this.caption=caption;
        this.id=id;
        this.intent=intent;
    }

    public Cell(int id,int imageDrawable, String caption, String color){
        this.imageDrawable=imageDrawable;
        this.caption=caption;
        this.id=id;
        this.color=color;
    }

    public Cell(int id,int imageDrawable, String caption, String color, Fragment fragment){
        this.imageDrawable=imageDrawable;
        this.caption=caption;
        this.id=id;
        this.color=color;
        this.fragment=fragment;
    }
}
