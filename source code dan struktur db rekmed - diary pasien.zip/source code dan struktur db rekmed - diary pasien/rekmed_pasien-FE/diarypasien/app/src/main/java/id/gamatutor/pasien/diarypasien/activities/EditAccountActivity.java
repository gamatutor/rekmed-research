package id.gamatutor.pasien.diarypasien.activities;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditAccountActivity extends AppCompatActivity {

    private ImageView imgAccount,imgBack;
    private Spinner spinProv, spinKab, spinKec, spinKel, spinGender;
    private String mCurrentPhotoPath,selectedKelurahan;
    static final int REQUEST_TAKE_PHOTO = 1;
    private File photoFile;
    private Uri photoUri;
    private Button btnAccountSave;
    private int selectedGender=0;
    private List<String> kodeProvinsi,kodeKabupaten,kodeKecamatan,kodeKelurahan;
    private List<Integer> kodeGender;
    private EditText editName, editEmail, editPhone, editBirth, editMR, editAddress;
    private SharedPreferences settings;
    private int userId;
    private int initProv=1;
    private int initKab=1;
    private int initKec=1;
    private int initKel=1;
    private DatePickerDialog.OnDateSetListener setBirth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_account);

        editName=(EditText)findViewById(R.id.editAccountName);
        editEmail=(EditText)findViewById(R.id.editAccountEmail);
        editPhone=(EditText)findViewById(R.id.editAccountTelp);
        editBirth=(EditText)findViewById(R.id.editAccountBirthAt);
        editMR=(EditText)findViewById(R.id.editAccountMr);
        editAddress=(EditText)findViewById(R.id.editAccountAddress);
        imgBack=(ImageView)findViewById(R.id.imgEditAccountBack);
        settings=getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        userId=settings.getInt("userId",0);

        spinProv=(Spinner)findViewById(R.id.spinProv);
        spinKab=(Spinner)findViewById(R.id.spinKab);
        spinKec=(Spinner)findViewById(R.id.spinKec);
        spinKel=(Spinner)findViewById(R.id.spinKel);
        spinGender=(Spinner)findViewById(R.id.spinGender);
        imgAccount=(ImageView)findViewById(R.id.imgAccount);
        btnAccountSave=(Button)findViewById(R.id.btnAccountSave);
        kodeGender=new ArrayList<Integer>();
        kodeKabupaten=new ArrayList<String>();
        kodeKecamatan=new ArrayList<String>();
        kodeKelurahan=new ArrayList<String>();
        kodeProvinsi=new ArrayList<String>();
        selectedKelurahan="1101010001";

        loadGender();
        getProvinsi();
        spinGender.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedGender=position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinProv.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                getKabupaten(kodeProvinsi.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinKab.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                getKecamatan(kodeKabupaten.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinKec.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                getKelurahan(kodeKecamatan.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinKel.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedKelurahan=kodeKelurahan.get(position);
                Log.i("SELECTED",selectedKelurahan);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        imgAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_TAKE_PHOTO);
                    }else{
                        dispatchTakePictureIntent();
                    }
                }else{
                    dispatchTakePictureIntent();
                }
            }
        });
        btnAccountSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doSaveAccount();
            }
        });
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),AccountActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
        setBirth=new DatePickerDialog.OnDateSetListener(){
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                Calendar cal=Calendar.getInstance();
                cal.set(year,month,dayOfMonth);
                DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
                editBirth.setText(dateFormat.format(cal.getTime()));
            }
        };
        editBirth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar=Calendar.getInstance();
                try{
                    DateFormat yearFormat=new SimpleDateFormat("yyyy");
                    DateFormat monthFormat=new SimpleDateFormat("MM");
                    DateFormat dayFormat=new SimpleDateFormat("dd");
                    String date=yearFormat.format(Config.credentials.getBirth());
                    calendar.set(
                            Integer.parseInt(yearFormat.format(Config.credentials.getBirth())),
                            Integer.parseInt(monthFormat.format(Config.credentials.getBirth()))-1,
                            Integer.parseInt(dayFormat.format(Config.credentials.getBirth()))
                    );
                }catch (Exception e){
                    e.printStackTrace();
                }
                new DatePickerDialog(EditAccountActivity.this,setBirth, calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        loadForm();
    }



    private void loadForm() {
        try{
            editName.setText(Config.credentials.getName());
        }catch (Exception e){
            e.printStackTrace();
        }
        try{
            editEmail.setText(Config.credentials.getEmail());
        }catch (Exception e){
            e.printStackTrace();
        }
        try{
            editPhone.setText(Config.credentials.getPhone());
        }catch (Exception e){
            e.printStackTrace();
        }
        try{
            DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
            editBirth.setText(dateFormat.format(Config.credentials.getBirth()));
        }catch (Exception e){
            e.printStackTrace();
        }
        spinGender.setSelection(Config.credentials.getGender());
        try{
            editAddress.setText(Config.credentials.getAddress());
        }catch (Exception e){
            e.printStackTrace();
        }

        try{
            String mrs= Config.credentials.getMrs().toString();
            mrs=mrs.replaceAll("\\[", "").replaceAll("\\]","");
            editMR.setText(mrs);
        }catch (Exception e){
            e.printStackTrace();
        }

        if(Config.credentials.getImg()==null){
            imgAccount.setImageResource(R.drawable.anonymous);
        }else{
            try{
                Picasso.with(getApplicationContext())
                        .load(Config.getBaseUrl()+"/uploads/"+ Config.credentials.getImg())
                        .resize(150,150)
                        .centerCrop()
                        .into(imgAccount);
                Log.i("PROFPIC", Config.getBaseUrl()+"/uploads/"+ Config.credentials.getImg());
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    private void loadGender() {
        List<String> list=new ArrayList<String>();
        list.add("WANITA");
        list.add("PRIA");

        kodeGender.clear();
        kodeGender.add(1);
        kodeGender.add(0);

        ArrayAdapter<String> dataAdapter=new ArrayAdapter<String>(getApplicationContext(),R.layout.spinner_style,list);
        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown_style);
        spinGender.setAdapter(dataAdapter);
    }

    private void getKelurahan(String kecid) {
        Call<Object> call= ApiClient.connect().getKelurahan(kecid);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_LONG).show();
                    }else{
                        JSONArray arrdata=obj.getJSONArray("data");
                        Log.i("DATA",arrdata.toString());
                        List<String> list=new ArrayList<String>();
                        kodeKelurahan.clear();
                        for(int i=0;i<arrdata.length();i++){
                            JSONObject data=arrdata.getJSONObject(i);
                            list.add(data.getString("kelurahan"));
                            kodeKelurahan.add(data.getString("id"));
                        }

                        ArrayAdapter<String> dataAdapter=new ArrayAdapter<String>(getApplicationContext(),R.layout.spinner_style,list);
                        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown_style);
                        spinKel.setAdapter(dataAdapter);

                        if(initKel==1){
                            try{
                                String kelid = Config.credentials.getKelurahanId();
                                int selectedKelIndex=0;
                                for(int i=0;i<kodeKelurahan.size();i++){
                                    if(kodeKelurahan.get(i).equals(kelid)){
                                        selectedKelIndex=i;
                                    }
                                }
                                spinKel.setSelection(selectedKelIndex);
                                initKel=0;
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private void getKecamatan(String kabid) {
        Call<Object> call= ApiClient.connect().getKecamatan(kabid);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_LONG).show();
                    }else{
                        JSONArray arrdata=obj.getJSONArray("data");
                        Log.i("DATA",arrdata.toString());
                        List<String> list=new ArrayList<String>();
                        kodeKecamatan.clear();
                        for(int i=0;i<arrdata.length();i++){
                            JSONObject data=arrdata.getJSONObject(i);
                            list.add(data.getString("kecamatan"));
                            kodeKecamatan.add(data.getString("id"));
                        }
                        ArrayAdapter<String> dataAdapter=new ArrayAdapter<String>(getApplicationContext(),R.layout.spinner_style,list);
                        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown_style);
                        spinKec.setAdapter(dataAdapter);

                        if(initKec==1){
                            try{
                                String kecid = Config.credentials.getKelurahanId().substring(0,7);
                                int selectedKecIndex=0;
                                for(int i=0;i<kodeKecamatan.size();i++){
                                    if(kodeKecamatan.get(i).equals(kecid)){
                                        selectedKecIndex=i;
                                    }
                                }
                                spinKec.setSelection(selectedKecIndex);
                                initKec=0;
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private void getKabupaten(String provid) {
        Call<Object> call= ApiClient.connect().getKabupaten(provid);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_LONG).show();
                    }else{
                        JSONArray arrdata=obj.getJSONArray("data");
                        Log.i("DATA",arrdata.toString());
                        List<String> list=new ArrayList<String>();
                        kodeKabupaten.clear();
                        for(int i=0;i<arrdata.length();i++){
                            JSONObject data=arrdata.getJSONObject(i);
                            list.add(data.getString("kabupaten"));
                            kodeKabupaten.add(data.getString("id"));
                        }
                        ArrayAdapter<String> dataAdapter=new ArrayAdapter<String>(getApplicationContext(),R.layout.spinner_style,list);
                        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown_style);
                        spinKab.setAdapter(dataAdapter);

                        if(initKab==1){
                            try{
                                String kabid = Config.credentials.getKelurahanId().substring(0,4);
                                int selectedKabIndex=0;
                                for(int i=0;i<kodeKabupaten.size();i++){
                                    if(kodeKabupaten.get(i).equals(kabid)){
                                        selectedKabIndex=i;
                                    }
                                }
                                spinKab.setSelection(selectedKabIndex);
                                initKab=0;
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private void getProvinsi() {
        Call<Object> call= ApiClient.connect().getProvinsi();
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_LONG).show();
                    }else{
                        JSONArray arrdata=obj.getJSONArray("data");
                        Log.i("DATA",arrdata.toString());
                        List<String> list=new ArrayList<String>();
                        kodeProvinsi.clear();
                        for(int i=0;i<arrdata.length();i++){
                            JSONObject data=arrdata.getJSONObject(i);
                            list.add(data.getString("provinsi"));
                            kodeProvinsi.add(data.getString("id"));
                        }
                        ArrayAdapter<String> dataAdapter=new ArrayAdapter<String>(getApplicationContext(),R.layout.spinner_style,list);
                        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown_style);
                        spinProv.setAdapter(dataAdapter);

                        if(initProv==1){
                            try{
                                String provid = Config.credentials.getKelurahanId().substring(0,2);
                                int selectedProvIndex=0;
                                for(int i=0;i<kodeProvinsi.size();i++){
                                    if(kodeProvinsi.get(i).equals(provid)){
                                        selectedProvIndex=i;
                                    }
                                }
                                spinProv.setSelection(selectedProvIndex);
                                initProv=0;
                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode== REQUEST_TAKE_PHOTO && resultCode==RESULT_OK){
            setPic();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case REQUEST_TAKE_PHOTO: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    dispatchTakePictureIntent();
                }
                return;
            }
        }
    }

    private void dispatchTakePictureIntent() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_TAKE_PHOTO);
            }
        }
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.example.android.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                List<ResolveInfo> resInfoList = getPackageManager().queryIntentActivities(takePictureIntent, PackageManager.MATCH_DEFAULT_ONLY);
                for (ResolveInfo resolveInfo : resInfoList) {
                    String packageName = resolveInfo.activityInfo.packageName;
                    grantUriPermission(packageName, photoURI, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);
            }
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        photoUri=Uri.parse(mCurrentPhotoPath);
        return image;
    }

    private void setPic() {
        Display display=getWindowManager().getDefaultDisplay();
        Point size=new Point();
        display.getSize(size);
        // Get the dimensions of the View
        int targetW = size.x/2;
        int targetH = size.x/2;

        // Get the dimensions of the bitmap
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(mCurrentPhotoPath, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

        // Determine how much to scale down the image
        int scaleFactor = Math.min(photoW/targetW, photoH/targetH);

        // Decode the image file into a Bitmap sized to fill the View
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;
        bmOptions.inPurgeable = true;

        Bitmap bitmap = BitmapFactory.decodeFile(mCurrentPhotoPath, bmOptions);
        imgAccount.setVisibility(View.VISIBLE);
        imgAccount.setImageBitmap(bitmap);
    }

    private void doSaveAccount() {
        String encodedId= EncodeDecode.encode(userId);
        Call<Object> call;

        RequestBody name=RequestBody.create(MultipartBody.FORM,editName.getText().toString());
        RequestBody phone=RequestBody.create(MultipartBody.FORM,editPhone.getText().toString());
        RequestBody birth_at=RequestBody.create(MultipartBody.FORM,editBirth.getText().toString());
        RequestBody gender=RequestBody.create(MultipartBody.FORM,String.valueOf(selectedGender));
        RequestBody address=RequestBody.create(MultipartBody.FORM,editAddress.getText().toString());
        RequestBody kelurahan_id=RequestBody.create(MultipartBody.FORM,selectedKelurahan);
        RequestBody mrs=RequestBody.create(MultipartBody.FORM,editMR.getText().toString());
        RequestBody method=RequestBody.create(MultipartBody.FORM,"PUT");

        if(photoFile != null){
            RequestBody requestFile=RequestBody.create(MediaType.parse("*/*"),photoFile);
            MultipartBody.Part photo=MultipartBody.Part.createFormData("upload",photoFile.getName(),requestFile);
            call= ApiClient.connect().editAccount(encodedId,name,phone,birth_at,gender,address,kelurahan_id,mrs,method,photo);
        }else{
            call= ApiClient.connect().editAccount(encodedId,name,phone,birth_at,gender,address,kelurahan_id,mrs,method);
        }

        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(getApplicationContext(),HomeActivity.class);
                        startActivity(intent);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }
}
