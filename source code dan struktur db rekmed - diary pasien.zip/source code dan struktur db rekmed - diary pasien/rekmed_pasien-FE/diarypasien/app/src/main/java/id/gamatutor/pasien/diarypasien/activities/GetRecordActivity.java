package id.gamatutor.pasien.diarypasien.activities;

import android.content.Intent;
import android.graphics.Point;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetRecordActivity extends AppCompatActivity {
    private TextView txtTitle,txtContent,txtFile, txtDate, txtMR;
    private ImageView imgRecord,imgEditRecord,imgBack;
    private String urlFile,urlImage, title;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_record);
//        Initialize
        txtTitle=(TextView)findViewById(R.id.txtTitleGetRecord);
        txtContent=(TextView)findViewById(R.id.txtContentGetRecord);
        txtFile=(TextView)findViewById(R.id.txtFileGetRecord);
        txtDate=(TextView)findViewById(R.id.txtDateGetRecord);
        txtMR=(TextView)findViewById(R.id.txtMRGetRecord);
        imgRecord=(ImageView)findViewById(R.id.imgGetRecord);
        imgEditRecord=(ImageView)findViewById(R.id.imgEditRecord);
        imgBack=(ImageView)findViewById(R.id.imgGetRecordBack);

        imgRecord.setVisibility(View.GONE);
        txtFile.setVisibility(View.GONE);
        final Bundle extras=getIntent().getExtras();
        Log.i("EXTRAS",String.valueOf(extras.getInt("id")));
        getRecord(extras.getInt("id"));

        imgEditRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),EditRecordActivity.class);
                intent.putExtra("id",extras.getInt("id"));
                startActivity(intent);
            }
        });

        txtFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(urlFile));
                startActivity(intent);
            }
        });
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
        imgRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),ImageActivity.class);
                intent.putExtra("url",urlImage);
                intent.putExtra("title",title);
                startActivity(intent);
            }
        });
    }

    private void getRecord(int id) {
        String encodedId= EncodeDecode.encode(id);
        Call<Object> call= ApiClient.connect().getRecord(encodedId);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        JSONObject data=obj.getJSONObject("data");
                        Log.i("RESPONSE",data.toString());
                        title=data.getString("title");
                        txtTitle.setText(title);
                        txtDate.setText(data.getString("updated_at"));
                        txtContent.setText(data.getString("content"));
                        if(data.getString("filetype").equals("image")){
                            Display display=getWindowManager().getDefaultDisplay();
                            Point size=new Point();
                            display.getSize(size);
                            urlImage="http://api.rekmed.com/uploads/"+data.getString("attachment");
                            Picasso.with(getApplicationContext())
                                    .load(urlImage)
                                    .resize(size.x,size.y)
                                    .centerInside()
                                    .into(imgRecord);
                            imgRecord.setVisibility(View.VISIBLE);
                        }else if(data.getString("filetype").equals("file")){
                            txtFile.setText(data.getString("attachment"));
                            urlFile= Config.getBaseUrl()+"/uploads/"+data.getString("attachment");
                            txtFile.setVisibility(View.VISIBLE);
                        }
                        if(data.getString("mr").equals("")==false){
                            txtMR.setText("Kode MR : "+data.getString("mr"));
                        }else{
                            txtMR.setText("");
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }
}
