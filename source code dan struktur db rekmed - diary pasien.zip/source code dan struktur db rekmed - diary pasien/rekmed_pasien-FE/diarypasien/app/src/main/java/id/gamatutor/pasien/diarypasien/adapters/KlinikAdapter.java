package id.gamatutor.pasien.diarypasien.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.activities.KunjunganActivity;
import id.gamatutor.pasien.diarypasien.objects.Klinik;

/**
 * Created by zmachmobile on 8/29/17.
 */

public class KlinikAdapter extends RecyclerView.Adapter<KlinikAdapter.MyViewHolder>{
    private List<Klinik> klinikList;
    private Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView txtTitleRow,txtAddressRow,txtPhoneRow;

        public MyViewHolder(View itemView) {
            super(itemView);
            txtTitleRow=(TextView)itemView.findViewById(R.id.txtTitleRow);
            txtAddressRow=(TextView)itemView.findViewById(R.id.txtAddressRow);
            txtPhoneRow=(TextView)itemView.findViewById(R.id.txtPhoneRow);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Klinik klinik=klinikList.get(getAdapterPosition());
                    Intent intent=new Intent(context, KunjunganActivity.class);
                    intent.putExtra("klinikId",klinik.id);
                    intent.putExtra("klinikTitle",klinik.title);
                    intent.putExtra("klinikAddress",klinik.address);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
        }
    }

    public KlinikAdapter(Context context, List<Klinik> klinikList){
        this.context=context;
        this.klinikList=klinikList;
    }

    @Override
    public KlinikAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.klinik_list_row,parent,false);
        return new KlinikAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(KlinikAdapter.MyViewHolder holder, final int position) {
        final Klinik klinik=klinikList.get(position);
        holder.txtTitleRow.setText(klinik.title);
        holder.txtAddressRow.setText(klinik.address);
        holder.txtPhoneRow.setText(klinik.phone);
    }

    @Override
    public int getItemCount() {
        return klinikList.size();
    }
}
