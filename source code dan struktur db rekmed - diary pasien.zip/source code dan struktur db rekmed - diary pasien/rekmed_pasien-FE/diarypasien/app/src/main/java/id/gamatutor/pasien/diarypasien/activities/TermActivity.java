package id.gamatutor.pasien.diarypasien.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;

public class TermActivity extends AppCompatActivity {

    private ImageView imgBack;
    private WebView webTerm;
    private RelativeLayout loadingLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term);

        imgBack=(ImageView)findViewById(R.id.imgTermBack);
        webTerm=(WebView)findViewById(R.id.webTerm);
        loadingLayout=(RelativeLayout)findViewById(R.id.layoutTerm);

        webTerm.getSettings().setJavaScriptEnabled(true);
        webTerm.loadUrl(Config.termUrl);
        webTerm.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageFinished(WebView view, String url) {
                loadingLayout.setVisibility(View.GONE);
            }
        });

        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
    }
}
