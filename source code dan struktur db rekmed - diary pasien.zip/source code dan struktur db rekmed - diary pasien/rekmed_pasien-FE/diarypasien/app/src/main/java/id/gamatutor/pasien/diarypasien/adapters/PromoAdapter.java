package id.gamatutor.pasien.diarypasien.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import java.util.List;

import id.gamatutor.pasien.diarypasien.objects.Promo;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.activities.GetPromoActivity;

/**
 * Created by zmachmobile on 5/1/17.
 */

public class PromoAdapter extends RecyclerView.Adapter<PromoAdapter.MyViewHolder> {
    private List<Promo> promoList;
    private Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txtTitle,txtDescription;
        public ImageView imgPromo;
        public MyViewHolder(View itemView) {
            super(itemView);
            txtTitle=(TextView)itemView.findViewById(R.id.txtTitlePromo);
            txtDescription=(TextView)itemView.findViewById(R.id.txtDescriptionPromo);
            imgPromo=(ImageView)itemView.findViewById(R.id.imgPromo);
        }
    }

    public PromoAdapter(Context context,List promoList){
        this.context=context;
        this.promoList=promoList;
    }

    @Override
    public PromoAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.promo_list_row,parent,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(PromoAdapter.MyViewHolder holder, int position) {
        final Promo promo=promoList.get(position);
        holder.txtTitle.setText(promo.getTitle());
        if(promo.getDescription().length() > 100){
            holder.txtDescription.setText(promo.getDescription().substring(0,100)+"...");
        }else{
            holder.txtDescription.setText(promo.getDescription());
        }
        Picasso.with(context)
                .load(promo.getImg())
                .resize(600,150)
                .centerCrop()
                .into(holder.imgPromo);
        holder.imgPromo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Gson gson=new Gson();
                String promoJson=gson.toJson(promo);
                Intent intent=new Intent(context, GetPromoActivity.class);
                intent.putExtra("promo",promoJson);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return promoList.size();
    }
}
