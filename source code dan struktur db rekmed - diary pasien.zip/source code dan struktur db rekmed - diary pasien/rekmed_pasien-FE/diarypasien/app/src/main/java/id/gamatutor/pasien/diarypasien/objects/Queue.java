package id.gamatutor.pasien.diarypasien.objects;

/**
 * Created by zmachmobile on 5/13/17.
 */

public class Queue {
    private int order;
    private String timeAlert;
    private String timeToCall;

    public Queue(int order,String timeAlert, String timeToCall){
        this.order=order;
        this.timeAlert=timeAlert;
        this.timeToCall=timeToCall;
    }

    public int getOrder(){
        return this.order;
    }

    public String getTimeAlert(){
        return this.timeAlert;
    }

    public String getTimeToCall(){
        return this.timeToCall;
    }
}
