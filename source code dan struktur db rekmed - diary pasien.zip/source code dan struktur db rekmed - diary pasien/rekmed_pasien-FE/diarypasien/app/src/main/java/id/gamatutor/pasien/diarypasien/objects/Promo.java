package id.gamatutor.pasien.diarypasien.objects;

/**
 * Created by zmachmobile on 5/1/17.
 */

public class Promo {
    private String title,description,img,url;

    public Promo(String title,String description, String img, String url){
        this.title=title;
        this.description=description;
        this.img=img;
        this.url=url;
    }

    public String getTitle(){
        return this.title;
    }

    public String getDescription(){
        return this.description;
    }

    public String getImg(){
        return this.img;
    }

    public String getUrl(){
        return this.url;
    }
}
