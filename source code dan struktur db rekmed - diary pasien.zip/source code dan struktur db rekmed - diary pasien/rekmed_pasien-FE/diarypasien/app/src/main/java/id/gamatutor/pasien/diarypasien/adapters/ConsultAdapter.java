package id.gamatutor.pasien.diarypasien.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.Consult;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.activities.EditConsultActivity;
import id.gamatutor.pasien.diarypasien.receivers.ConsultBroadcastReceiver;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by zmachmobile on 6/13/17.
 */

public class ConsultAdapter extends RecyclerView.Adapter<ConsultAdapter.MyViewHolder> {
    private List<Consult> consultList;
    private Context context;
    private ConsultBroadcastReceiver consultBroadcastReceiver;
    private SharedPreferences savedConsult;

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView title, due;
        public SwitchCompat switchConsult;
        public RelativeLayout relativeConsultRow;
        public ImageView remove;
        public View separatorConsult;
        public MyViewHolder(View itemView) {
            super(itemView);
            title=(TextView)itemView.findViewById(R.id.txtTitleConsult);
            due=(TextView)itemView.findViewById(R.id.txtDueConsult);
            switchConsult=(SwitchCompat)itemView.findViewById(R.id.switchConsult);
            relativeConsultRow=(RelativeLayout)itemView.findViewById(R.id.layoutConsultRow);
            remove=(ImageView)itemView.findViewById(R.id.imgRemoveConsult);
            separatorConsult=(View)itemView.findViewById(R.id.separatorConsult);
        }
    }
    public ConsultAdapter (Context context,List<Consult> consultList){
        this.context=context;
        this.consultList=consultList;
        consultBroadcastReceiver=new ConsultBroadcastReceiver();
        savedConsult=context.getSharedPreferences(Config.sharedPrefConsult, MODE_PRIVATE);
    }
    @Override
    public ConsultAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.consult_list_row,parent,false);
        return new ConsultAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ConsultAdapter.MyViewHolder holder, final int position) {
        final Consult consult=consultList.get(position);
        if(consult.id!=0){
            holder.title.setText(consult.title);
            SimpleDateFormat dateFormat=new SimpleDateFormat("dd MMM yyyy");
            String tgl=consult.due.split(" ")[0];
            String jam=consult.due.split(" ")[1];
            Calendar calendar=Calendar.getInstance();
            calendar.set(Integer.parseInt(tgl.split("-")[0]),Integer.parseInt(tgl.split("-")[1])-1,Integer.parseInt(tgl.split("-")[2]));
            holder.due.setText(dateFormat.format(calendar.getTime())+"\t\t\t"+jam.split(":")[0]+":"+jam.split(":")[1]);
            if(consult.active==true){
                holder.switchConsult.setChecked(true);
                startAlert(consult);
            }else{
                holder.switchConsult.setChecked(false);
                cancelAlert(consult);
            }
            holder.switchConsult.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked==true){
                        consult.active=true;
                        startAlert(consult);
                        Toast.makeText(context,"Pengingat diaktifkan",Toast.LENGTH_SHORT).show();
                    }else{
                        cancelAlert(consult);
                        consult.active=false;
                        Toast.makeText(context,"Pengingat dibatalkan",Toast.LENGTH_SHORT).show();
                    }
                    SharedPreferences.Editor editor= savedConsult.edit();
                    Gson gson=new Gson();
                    editor.putString("data",gson.toJson(consultList));
                    editor.commit();

                    doUpdateConsult(consult);
                }
            });
            holder.relativeConsultRow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(context,EditConsultActivity.class);
                    intent.putExtra("id",consult.id);
                    Gson gson=new Gson();
                    intent.putExtra("data",gson.toJson(consult));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
            holder.remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new AlertDialog.Builder(v.getContext())
                            .setTitle("Konfirmasi")
                            .setMessage("Anda yakin ingin menghapus ini?")
                            .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    doDelete(consult.id,position);
                                }
                            }).setNegativeButton("TIDAK",null).show();
                }
            });
        }else{
            holder.remove.setVisibility(View.GONE);
            holder.switchConsult.setVisibility(View.GONE);
            holder.due.setVisibility(View.INVISIBLE);
            holder.title.setVisibility(View.INVISIBLE);
            holder.separatorConsult.setVisibility(View.INVISIBLE);
            holder.relativeConsultRow.setClickable(false);
        }
    }

    private void doDelete(int id, final int position) {
        String cid=EncodeDecode.encode(id);
        Call<Object> call= ApiClient.connect().deleteConsult(cid);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(context,obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        consultList.remove(position);
                        notifyItemRemoved(position);
                        Toast.makeText(context,obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private void doUpdateConsult(final Consult consult) {
        String id=EncodeDecode.encode(consult.id);
        RequestBody reqUserId=RequestBody.create(MultipartBody.FORM,String.valueOf(Config.credentials.getId()));
        RequestBody reqTitle=RequestBody.create(MultipartBody.FORM,consult.title);
        RequestBody reqDue=RequestBody.create(MultipartBody.FORM,consult.due);
        RequestBody reqActive=RequestBody.create(MultipartBody.FORM,String.valueOf(0));
        if(consult.active==true){
            reqActive=RequestBody.create(MultipartBody.FORM,String.valueOf(1));
        }
        RequestBody reqMethod=RequestBody.create(MultipartBody.FORM,"PUT");

        Call<Object> call= ApiClient.connect().editConsult(id,reqUserId,reqTitle,reqDue,reqActive,reqMethod);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(context,obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(context,obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private void startAlert(Consult consult){
        consultBroadcastReceiver.startAlert(context,consult.pid,consult.title,consult.due);
    }

    private void cancelAlert(Consult consult){
        consultBroadcastReceiver.cancelAlert(context,consult.pid);
    }

    @Override
    public int getItemCount() {
        return consultList.size();
    }
}
