package id.gamatutor.pasien.diarypasien.activities;

import android.app.SearchManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.adapters.RecordAdapter;
import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.objects.Record;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RecordActivity extends AppCompatActivity {

    private SwipeRefreshLayout swipeRefresh;
    private SharedPreferences settings;
    private List<Record> recordList=new ArrayList<>();
    private RecyclerView recyclerView;
    private RecordAdapter recordAdapter;
    private FloatingActionButton fab;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Catatan Medis");
        setSupportActionBar(toolbar);

        ActionBar actionBar=getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),AddRecordActivity.class));
            }
        });

        settings=getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        swipeRefresh=(SwipeRefreshLayout)findViewById(R.id.swipeRefreshRecord);
        recyclerView=(RecyclerView)findViewById(R.id.recyclerView);

        userId=settings.getInt("userId",0);

        recordAdapter=new RecordAdapter(getApplicationContext(),recordList);
        RecyclerView.LayoutManager mLayoutManager=new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(recordAdapter);

        prepareRecordData("");

        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefresh.setRefreshing(true);
                recordList.clear();
                recordAdapter.notifyDataSetChanged();
                prepareRecordData("");
            }
        });
//        handle search
        handleIntent(getIntent());
    }

    private void handleIntent(Intent intent) {
        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            String query = intent.getStringExtra(SearchManager.QUERY);
            Toast.makeText(getApplicationContext(),query,Toast.LENGTH_SHORT).show();
            //use the query to search your data somehow
            prepareRecordData(query);
        }
    }

    private void prepareRecordData(String query) {
        recordList.clear();
        recordAdapter.notifyDataSetChanged();
        String encodedId= EncodeDecode.encode(userId);
        Call<Object> call;
        if(query.equals("")==true){
            call= ApiClient.connect().getRecords(encodedId);
        }else{
            call= ApiClient.connect().searchRecord(encodedId,query);
        }
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        JSONArray arrdata=obj.getJSONArray("data");
                        for(int i=0;i<arrdata.length();i++){
                            JSONObject data=arrdata.getJSONObject(i);
                            Log.i("RECORDS",data.toString());
                            Record record=new Record(data.getInt("id"),data.getString("title"),data.getString("content"),data.getString("updated_at"));
                            record.setFiletype(data.getString("filetype"));
                            if(data.getString("filetype").equals("none")==false){
                                record.setAttachment(Config.getBaseUrl()+"/uploads/"+data.getString("attachment"));
                            }
                            recordList.add(record);
                        }
                        recordAdapter.notifyDataSetChanged();
                        swipeRefresh.setRefreshing(false);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);

        // Associate searchable configuration with the SearchView
        SearchManager searchManager=(SearchManager)getSystemService(SEARCH_SERVICE);
        SearchView searchView=(SearchView)menu.findItem(R.id.action_search).getActionView();
//        search in another activity
//        ComponentName cn = new ComponentName(this, SearchResultsActivity.class);
//        searchView.setSearchableInfo(searchManager.getSearchableInfo(cn));
//        search in own activity
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));

        MenuItem searchItem=menu.findItem(R.id.action_search);
        MenuItemCompat.setOnActionExpandListener(searchItem, new MenuItemCompat.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                prepareRecordData("");
                return true;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                Intent intent=new Intent(getApplicationContext(),HomeActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        handleIntent(intent);
    }
}
