package id.gamatutor.pasien.diarypasien.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.objects.Record;
import id.gamatutor.pasien.diarypasien.activities.GetRecordActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by zmachmobile on 4/16/17.
 */

public class RecordAdapter extends RecyclerView.Adapter<RecordAdapter.MyViewHolder> {

    private List<Record> recordList;
    private Context context;

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView txtTitleRow,txtContentRow,txtDateRow;
        public ImageView imgPreviewRow,imgTrashRow;
        public RelativeLayout layoutRecordRow;
        public View separatorRecord;

        public MyViewHolder(View itemView) {
            super(itemView);
            layoutRecordRow=(RelativeLayout)itemView.findViewById(R.id.layoutRecordRow);
            txtTitleRow=(TextView)itemView.findViewById(R.id.txtTitleRow);
            txtContentRow=(TextView)itemView.findViewById(R.id.txtContentRow);
            txtDateRow=(TextView)itemView.findViewById(R.id.txtDateRow);
            imgPreviewRow=(ImageView)itemView.findViewById(R.id.imgPreviewRow);
            imgTrashRow=(ImageView)itemView.findViewById(R.id.imgTrashRow);
            separatorRecord=(View)itemView.findViewById(R.id.separatorRecord);
        }
    }

    public RecordAdapter(Context context,List<Record> recordList){
        this.context=context;
        this.recordList=recordList;
    }

    @Override
    public RecordAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.record_list_row,parent,false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(RecordAdapter.MyViewHolder holder, final int position) {
        final Record record=recordList.get(position);
        holder.txtTitleRow.setText(record.getTitle());
        if(record.getContent().length() > 100){
            holder.txtContentRow.setText(record.getContent().substring(0,100)+"...");
        }else{
            holder.txtContentRow.setText(record.getContent());
        }
        try{
            holder.txtDateRow.setText(record.getModified().toString());
        }catch (Exception e){
            e.printStackTrace();
        }
        try{
            if(record.getFiletype().equals("image")){
                Picasso.with(context)
                        .load(record.getAttachment())
                        .resize(150,150)
                        .centerCrop()
                        .into(holder.imgPreviewRow);
            }else if(record.getFiletype().equals("file")){
                holder.imgPreviewRow.setImageResource(R.drawable.file);
            }else if(record.getFiletype().equals("none")){
                holder.imgPreviewRow.setImageResource(R.drawable.writing);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        if(record.getId()==0){
            holder.imgTrashRow.setVisibility(View.GONE);
            holder.txtDateRow.setVisibility(View.GONE);
            holder.imgPreviewRow.setVisibility(View.INVISIBLE);
            holder.separatorRecord.setVisibility(View.GONE);
            holder.layoutRecordRow.setClickable(false);
        }else{
            holder.imgTrashRow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new AlertDialog.Builder(v.getContext())
                            .setTitle("Konfirmasi")
                            .setMessage("Anda yakin ingin menghapus ini?")
                            .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    doDelete(record.getId(),position);
                                }
                            }).setNegativeButton("TIDAK",null).show();
                }
            });
            holder.layoutRecordRow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(context,GetRecordActivity.class);
                    intent.putExtra("id",record.getId());
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            });
        }
    }

    private void doDelete(int id, final int position) {
        String encodedId= EncodeDecode.encode(id);
        Call<Object> call= ApiClient.connect().deleteRecords(encodedId);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    recordList.remove(position);
                    notifyItemRemoved(position);
                    JSONObject data=new JSONObject(responseStr);
                    Toast.makeText(context,data.getString("message"),Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    @Override
    public int getItemCount() {
        return recordList.size();
    }

}
