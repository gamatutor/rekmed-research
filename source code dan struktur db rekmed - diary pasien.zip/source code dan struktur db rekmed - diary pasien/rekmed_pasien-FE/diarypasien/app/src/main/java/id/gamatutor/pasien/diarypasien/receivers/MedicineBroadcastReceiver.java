package id.gamatutor.pasien.diarypasien.receivers;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.activities.MedicineActivity;
import id.gamatutor.pasien.diarypasien.objects.ReminderDetail;
import io.realm.RealmList;

import static android.content.Context.NOTIFICATION_SERVICE;

public class MedicineBroadcastReceiver extends BroadcastReceiver {
    Bundle extras;
    String title,content;
    @Override
    public void onReceive(Context context, Intent intent) {
        extras=intent.getExtras();
        title=extras.getString("title");
        content=extras.getString("content");

        Intent mainIntent;
        PendingIntent pendingIntent;
        mainIntent=new Intent(context, MedicineActivity.class);
        pendingIntent=PendingIntent.getActivity(context,0,mainIntent,PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(context)
                        .setSmallIcon(R.drawable.logo_mini)
                        .setContentTitle(title)
                        .setContentText(content)
                        .setContentIntent(pendingIntent)
                        .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        Random random = new Random();
        int randomized = random.nextInt(9999 - 1000) + 1000;
        notificationManager.notify(randomized, mBuilder.build());
    }

    public void startAlert(Context context, ArrayList<ReminderDetail> schedules){
        AlarmManager alarmMgr;
        PendingIntent alarmIntent;
        Intent pendingintent;

        alarmMgr = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        pendingintent = new Intent(context, MedicineBroadcastReceiver.class);
        pendingintent.putExtra("title","Saatnya minum obat");

        Log.i("SCHEDULE",title+":"+schedules.toString());

        for(int i=0;i<schedules.size();i++){
            ReminderDetail detail=schedules.get(i);
            Calendar calendar=Calendar.getInstance();
            calendar.setTimeInMillis(detail.getCalendarMillis());
            pendingintent.putExtra("content",title+" (jam "+calendar.get(Calendar.HOUR_OF_DAY)+")");
            alarmIntent= PendingIntent.getBroadcast(context,detail.getPid(),pendingintent,PendingIntent.FLAG_UPDATE_CURRENT);
            alarmMgr.set(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),alarmIntent);
        }
    }

    public void cancelAlert(Context context,int pid){
        AlarmManager alarmMgr;
        PendingIntent alarmIntent;
        Intent pendingintent;
        pendingintent = new Intent(context, MedicineBroadcastReceiver.class);
        alarmIntent = PendingIntent.getBroadcast(context, pid, pendingintent, PendingIntent.FLAG_UPDATE_CURRENT);
        alarmMgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmMgr.cancel(alarmIntent);
    }

    public void startAlertbyPid(Context context,int pid, Calendar calendar){
        AlarmManager alarmMgr;
        PendingIntent alarmIntent;
        Intent pendingintent;

        alarmMgr = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        pendingintent = new Intent(context, MedicineBroadcastReceiver.class);
        pendingintent.putExtra("title","Saatnya minum obat");
        pendingintent.putExtra("content",title+" (jam "+calendar.get(Calendar.HOUR_OF_DAY)+")");
        alarmIntent= PendingIntent.getBroadcast(context,pid,pendingintent,PendingIntent.FLAG_UPDATE_CURRENT);
        alarmMgr.set(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),alarmIntent);
    }

    public ArrayList generateSchedule(String expiredDate, int signa){
        ArrayList<String> result=new ArrayList<String>();
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
        int year=Integer.parseInt(expiredDate.split("-")[0]);
        int month=Integer.parseInt(expiredDate.split("-")[1])-1;
        int day=Integer.parseInt(expiredDate.split("-")[2]);
        Calendar expired=Calendar.getInstance();
        expired.set(Calendar.YEAR,year);
        expired.set(Calendar.MONTH,month);
        expired.set(Calendar.DAY_OF_MONTH,day);

        Calendar now=Calendar.getInstance();
//        now.set(Calendar.YEAR,2016);
//        now.set(Calendar.MONTH,10);
//        now.set(Calendar.DAY_OF_MONTH,20);

        if(expired.getTimeInMillis() > now.getTimeInMillis()){
            int startHour=6;
            int intervalHour=(24-startHour)/signa;
            long dayLeftLong=(expired.getTimeInMillis()-now.getTimeInMillis())/1000/24/60/60;
            int dayLeft=(int)dayLeftLong;
            Log.i("DAY LEFT",dayLeft+" days");
            ArrayList<String> listHours=new ArrayList<String>();
            for(int i=0;i<=dayLeft;i++){
                Calendar nextDay=Calendar.getInstance();
                nextDay.add(Calendar.DATE,i);
                long tanggal=nextDay.getTimeInMillis();
                for(int j=0;j<signa;j++){
                    int nextHour=startHour+(intervalHour*j);
                    int currentHour=now.get(Calendar.HOUR_OF_DAY);
                    int currentDay=now.get(Calendar.DAY_OF_MONTH);
                    DateFormat dateFormat=new SimpleDateFormat("dd");
                    if(Integer.parseInt(dateFormat.format(tanggal)) == currentDay){
                        if(currentHour < nextHour){
                            listHours.add(""+(format.format(tanggal))+" "+nextHour+":00");
                        }
                    }else{
                        listHours.add(""+(format.format(tanggal))+" "+nextHour+":00");
                    }
                    Log.i("MILLIS",""+tanggal);
                }
            }
            result=listHours;
        }
        return result;
    }
}
