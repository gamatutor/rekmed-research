package id.gamatutor.pasien.diarypasien.interfaces;

import android.os.Bundle;

import java.util.ArrayList;

public interface BaseModel {
    public ArrayList getAll();
    public Object getItem(int key);
    public void addItem(Bundle bundle);
    public void updateItem(int key, Bundle bundle);
    public void deleteItem(int key);
    public void flushAll();
}
