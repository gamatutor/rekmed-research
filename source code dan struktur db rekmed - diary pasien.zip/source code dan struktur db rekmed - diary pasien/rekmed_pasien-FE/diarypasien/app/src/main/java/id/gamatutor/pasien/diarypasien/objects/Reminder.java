package id.gamatutor.pasien.diarypasien.objects;

import java.util.ArrayList;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by zmachmobile on 4/30/17.
 */

public class Reminder extends RealmObject{
    private int pid;
    private int signa;
    private String obat, expired;
    private boolean active=true;
    private int amount;

    public Reminder(){

    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public void setObat(String obat) {
        this.obat = obat;
    }

    public void setSigna(int signa) {
        this.signa = signa;
    }

    public void setExpired(String expired) {
        this.expired = expired;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getPid(){
        return this.pid;
    }

    public String getObat(){
        return this.obat;
    }

    public int getSigna(){
        return this.signa;
    }

    public String getExpired(){
        return this.expired;
    }

    public boolean getActive(){
        return this.active;
    }

    public int getAmount(){return this.amount;}

    public void setActive(boolean active){
        this.active=active;
    }

}
