package id.gamatutor.pasien.diarypasien.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.polites.android.GestureImageView;
import com.squareup.picasso.Picasso;

import id.gamatutor.pasien.diarypasien.R;

public class ImageActivity extends AppCompatActivity {
    private GestureImageView img;
    private Bundle bundle;
    private String url;
    private ImageView imgBack;
    private TextView txtTitle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);

        imgBack=(ImageView)findViewById(R.id.imgImageBack);
        img=(GestureImageView) findViewById(R.id.imgImage);
        txtTitle=(TextView)findViewById(R.id.txtImageTitle);

        bundle=getIntent().getExtras();
        url=bundle.getString("url");
        txtTitle.setText(bundle.getString("title"));
        Picasso.with(getApplicationContext())
                .load(url)
                .into(img);
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
    }
}
