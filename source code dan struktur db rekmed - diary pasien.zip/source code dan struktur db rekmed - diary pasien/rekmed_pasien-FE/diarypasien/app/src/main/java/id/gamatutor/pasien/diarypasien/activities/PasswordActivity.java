package id.gamatutor.pasien.diarypasien.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wang.avi.AVLoadingIndicatorView;

import org.json.JSONException;
import org.json.JSONObject;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PasswordActivity extends AppCompatActivity {

    private AVLoadingIndicatorView loadingPassword;
    private Button btnChangePassword;
    private EditText editPasswordPassword,editRepasswordPassword;
    private TextView txtAlertPassword;
    private SharedPreferences settings;
    private int userId;
    private ImageView imgBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);

        loadingPassword=(AVLoadingIndicatorView)findViewById(R.id.loadingPassword);
        btnChangePassword=(Button)findViewById(R.id.btnChangePassword);
        editPasswordPassword=(EditText)findViewById(R.id.editPasswordPassword);
        editRepasswordPassword=(EditText)findViewById(R.id.editRepasswordPassword);
        txtAlertPassword=(TextView)findViewById(R.id.txtAlertPassword);
        imgBack=(ImageView)findViewById(R.id.imgPasswordBack);
        settings=getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        userId=settings.getInt("userId",0);

        loadingPassword.hide();
        txtAlertPassword.setVisibility(View.GONE);
        btnChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doChange();
            }
        });
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
    }

    private void doChange() {
        loadingPassword.show();
        String encodedId= EncodeDecode.encode(userId);
        Call<Object> call= ApiClient.connect().changePassword(encodedId,editPasswordPassword.getText().toString(),editRepasswordPassword.getText().toString());
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                Log.i("RESPONSE",responseStr.toString());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        loadingPassword.hide();
                        txtAlertPassword.setText(obj.getString("message"));
                        txtAlertPassword.setVisibility(View.VISIBLE);
                    }else {
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_LONG).show();
                        loadingPassword.hide();
                        txtAlertPassword.setVisibility(View.GONE);
                        startActivity(new Intent(getApplicationContext(),HomeActivity.class));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                loadingPassword.hide();
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }
}
