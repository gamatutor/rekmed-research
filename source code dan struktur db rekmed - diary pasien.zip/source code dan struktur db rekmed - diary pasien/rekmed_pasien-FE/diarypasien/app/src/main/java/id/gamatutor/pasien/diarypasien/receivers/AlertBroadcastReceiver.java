package id.gamatutor.pasien.diarypasien.receivers;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;

import java.util.Calendar;

import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.activities.QueueActivity;

import static android.content.Context.NOTIFICATION_SERVICE;

/**
 * Created by zmachmobile on 5/12/17.
 */

public class AlertBroadcastReceiver extends BroadcastReceiver {
    Bundle extras;
    String title,description;
    @Override
    public void onReceive(Context context, Intent intent) {
        extras=intent.getExtras();
        title=extras.getString("title");
        description=extras.getString("description");

        Intent mainIntent;
        PendingIntent pendingIntent;
        mainIntent=new Intent(context, QueueActivity.class);
        pendingIntent=PendingIntent.getActivity(context,0,mainIntent,PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(context)
                        .setSmallIcon(R.drawable.logo_mini)
                        .setContentTitle(title)
                        .setContentText(description)
                        .setContentIntent(pendingIntent)
                        .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
        notificationManager.notify(1, mBuilder.build());
    }

    public void startAlert(Context context, int pid,String time,String title, String description){
        AlarmManager alarmMgr;
        PendingIntent alarmIntent;
        Intent pendingintent;
        Calendar calendar=Calendar.getInstance();

        alarmMgr = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        pendingintent = new Intent(context, AlertBroadcastReceiver.class);
        pendingintent.putExtra("title",title);
        pendingintent.putExtra("description",description);

        int hour=Integer.parseInt(time.split(":")[0]);
        int minute=Integer.parseInt(time.split(":")[1]);
        int second=Integer.parseInt(time.split(":")[2]);
        calendar.set(Calendar.HOUR_OF_DAY,hour);
        calendar.set(Calendar.MINUTE,minute);
        calendar.set(Calendar.SECOND,second);
        alarmIntent= PendingIntent.getBroadcast(context,pid,pendingintent,PendingIntent.FLAG_UPDATE_CURRENT);
        alarmMgr.set(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),alarmIntent);
    }

    public void cancelAlert(Context context,int pid){
        AlarmManager alarmMgr;
        PendingIntent alarmIntent;
        Intent pendingintent;
        pendingintent = new Intent(context, AlertBroadcastReceiver.class);
        alarmIntent = PendingIntent.getBroadcast(context, pid, pendingintent, PendingIntent.FLAG_UPDATE_CURRENT);
        alarmMgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmMgr.cancel(alarmIntent);
    }

//    public void setAlarm(Context context){
//        AlarmManager alarmMgr;
//        PendingIntent alarmIntent;
//        Intent pendingintent;
//        alarmMgr = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
//        pendingintent= new Intent(context, AlertBroadcastReceiver.class);
//        final Calendar calendar = Calendar.getInstance();
//
//        for(int i=1;i<60;i++){
//            calendar.set(Calendar.HOUR_OF_DAY, 22);
//            calendar.set(Calendar.MINUTE, i);
//            calendar.set(Calendar.SECOND,0);
//            alarmIntent= PendingIntent.getBroadcast(context,i,pendingintent,PendingIntent.FLAG_UPDATE_CURRENT);
//            alarmMgr.set(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),alarmIntent);
//        }
//    }

//    public void cancelAlarm(Context context){
//        AlarmManager alarmMgr;
//        PendingIntent alarmIntent;
//        Intent pendingintent;
//        pendingintent = new Intent(context, AlertBroadcastReceiver.class);
//        for(int i=1;i<60;i++){
//            alarmIntent = PendingIntent.getBroadcast(context, i, pendingintent, PendingIntent.FLAG_UPDATE_CURRENT);
//            alarmMgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
//            alarmMgr.cancel(alarmIntent);
//        }
//    }
}
