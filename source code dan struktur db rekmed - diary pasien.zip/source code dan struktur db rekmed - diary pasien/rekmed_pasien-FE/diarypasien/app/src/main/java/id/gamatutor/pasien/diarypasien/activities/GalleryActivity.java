package id.gamatutor.pasien.diarypasien.activities;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.adapters.ImageAdapter;

public class GalleryActivity extends AppCompatActivity {
    public static final String CAMERA_IMAGE_BUCKET_NAME = Environment.getExternalStorageDirectory().toString();
    public static final String CAMERA_IMAGE_BUCKET_ID = getBucketId(CAMERA_IMAGE_BUCKET_NAME);
    public static String getBucketId(String path) {return String.valueOf(path.toLowerCase().hashCode());}
    private List<String> imageList=new ArrayList<String>();
    GridView gridView;
    ImageView imgBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        imgBack=(ImageView)findViewById(R.id.imgGalleryBack);
        gridView=(GridView)findViewById(R.id.gridView);
        imageList=getCameraImages(getApplicationContext());
        gridView.setAdapter(new ImageAdapter(getApplicationContext(),imageList));
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent();
                intent.putExtra("data",imageList.get(position));
                setResult(RESULT_OK,intent);
                finish();
            }
        });
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });

    }

    public static List<String> getCameraImages(Context context) {
        final String[] projection = { MediaStore.Images.Media.DATA };
        final String selection = MediaStore.Images.Media.BUCKET_ID + " = ?";
//        final String[] selectionArgs = { CAMERA_IMAGE_BUCKET_ID };
        final String[] selectionArgs = { getBucketId(CAMERA_IMAGE_BUCKET_NAME + "/DCIM/Camera") };
        final Cursor cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                null);
        ArrayList<String> result = new ArrayList<String>(cursor.getCount());
        if (cursor.moveToLast()) {
            final int dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            do {
                final String data = cursor.getString(dataColumn);
                result.add(data);
            } while (cursor.moveToPrevious());
        }
        cursor.close();
//        Log.i("PATH 1",Environment.getExternalStorageDirectory().toString()+"/DCIM/Camera");
//        Log.i("PATH 2",Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString());
//        Log.i("PATH 3",Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getPath());
//        Log.i("PATH 4",Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getAbsolutePath());
//        Log.i("PATH 4",Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getAbsolutePath());
        return result;
    }
}
