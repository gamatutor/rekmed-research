package id.gamatutor.pasien.diarypasien.fragments;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.login.LoginManager;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.activities.EditAccountActivity;
import id.gamatutor.pasien.diarypasien.activities.LoginActivity;
import id.gamatutor.pasien.diarypasien.activities.PasswordActivity;
import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.objects.Credentials;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.receivers.MedicineBroadcastReceiver;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.MODE_PRIVATE;

/**
 * A simple {@link Fragment} subclass.
 */
public class AccountFragment extends Fragment {

    private ImageView imgAccount,imgEditAccount;
    private TextView txtName, txtEmail, txtPhone, txtBirthAt, txtAddress, txtGender, txtKodeMR;
    private Button btnChangePassword, btnExit;
    private SharedPreferences settings, totalReminderId, savedObat, savedQueue, settingServer;
    private MedicineBroadcastReceiver medicineBroadcastReceiver;
    private int userId;

    public AccountFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_account, container, false);

        imgAccount=(ImageView)view.findViewById(R.id.imgAccount);
        imgEditAccount=(ImageView)view.findViewById(R.id.imgEditAccount);
        txtName=(TextView)view.findViewById(R.id.txtAccountName);
        txtEmail=(TextView)view.findViewById(R.id.txtAccountEmail);
        txtPhone=(TextView)view.findViewById(R.id.txtAccountPhone);
        txtBirthAt=(TextView)view.findViewById(R.id.txtAccountBirthAt);
        txtAddress=(TextView)view.findViewById(R.id.txtAccountAddress);
        txtGender=(TextView)view.findViewById(R.id.txtAccountGender);
        txtKodeMR=(TextView)view.findViewById(R.id.txtAccountMR);
        btnChangePassword=(Button)view.findViewById(R.id.btnChangePassword);
        btnExit=(Button)view.findViewById(R.id.btnExit);
        settings=getActivity().getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        userId=settings.getInt("userId",0);

        settings=getContext().getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        settingServer=getContext().getSharedPreferences(Config.sharedPrefServer, MODE_PRIVATE);
        totalReminderId=getContext().getSharedPreferences(Config.sharedPrefTotalReminderId,MODE_PRIVATE);
        savedObat=getContext().getSharedPreferences(Config.sharedPrefObat,MODE_PRIVATE);
        savedQueue=getContext().getSharedPreferences(Config.sharedPrefQueue,MODE_PRIVATE);

        updateCredentials(userId);

        try{
            txtName.setText(Config.credentials.getName());
        }catch (Exception e){
            e.printStackTrace();
        }
        try{
            txtEmail.setText(Config.credentials.getEmail());
        }catch (Exception e){
            e.printStackTrace();
        }
        try{
            txtPhone.setText(Config.credentials.getPhone());
        }catch (Exception e){
            e.printStackTrace();
        }

        DateFormat dateFormat=new SimpleDateFormat("dd-MMM-yyyy");
        try{
            txtBirthAt.setText(dateFormat.format(Config.credentials.getBirth()));
        }catch (Exception e){
            e.printStackTrace();
        }
        try{
            txtAddress.setText(Config.credentials.getAddress());
        }catch (Exception e){
            e.printStackTrace();
        }
        try{
            if(Config.credentials.getGender() == 0){
                txtGender.setText("WANITA");
            }else{
                txtGender.setText("PRIA");
            }
        }catch (Exception e){
            txtGender.setText("WANITA");
        }
        if(Config.credentials.getImg()==null){
            imgAccount.setImageResource(R.drawable.anonymous);
        }else{
            try{
                Picasso.with(getContext())
                        .load(Config.getBaseUrl()+"/uploads/"+ Config.credentials.getImg())
                        .resize(150,150)
                        .centerCrop()
                        .into(imgAccount);
            }catch (Exception e){
                e.printStackTrace();
            }
        }

        String mrs= Config.credentials.getMrs().toString();
        mrs=mrs.replaceAll("\\[", "").replaceAll("\\]","");
        Log.i("MRS",mrs);
        txtKodeMR.setText(mrs);

        imgEditAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(),EditAccountActivity.class));
            }
        });

        btnChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(),PasswordActivity.class));
            }
        });

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doLogout();
            }
        });
        return view;
    }

    private void updateCredentials(int id) {
        String encodedId= EncodeDecode.encode(id);
        Call<Object> call= ApiClient.connect().getCredentials(encodedId);
        call.enqueue(new Callback<Object>() {

            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
//                Log.i("RESPONSE",responseStr.toString());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
//                        Toast.makeText(getContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        JSONObject data=obj.getJSONObject("data");
                        Config.credentials=new Credentials(data.getInt("id"),data.getString("email"));
                        Config.credentials.setAddress(data.getString("address"));
                        DateFormat dateFormat=new SimpleDateFormat("yyyy-mm-dd");
                        try {
                            Config.credentials.setBirth(dateFormat.parse(data.getString("birth_at")));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        if(data.getString("gender").equals("MALE")){
                            Config.credentials.setGender(1);
                        }else{
                            Config.credentials.setGender(0);
                        }
                        Config.credentials.setImg(Config.baseUrl+"/uploads/"+data.getString("img"));
                        Config.credentials.setKelurahanId(data.getString("kelurahan_id"));
                        List<String> mrs=new ArrayList<String>();
                        JSONArray mrArray=data.getJSONArray("mr");
                        for (int i=0;i<mrArray.length();i++){
                            mrs.add(mrArray.getString(i));
                        }
                        Config.credentials.setMrs(mrs);
                        Config.credentials.setName(data.getString("name"));
                        Config.credentials.setPhone(data.getString("phone"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
//                    Toast.makeText(getContext(),e.toString(),Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    private void doLogout() {
//        clear reminder obat
        int totalId=totalReminderId.getInt("total",0);
        if(totalId != 0){
            medicineBroadcastReceiver=new MedicineBroadcastReceiver();
            for(int i=100;i<=totalId;i++){
                medicineBroadcastReceiver.cancelAlert(getContext(),i);
            }
        }

        SharedPreferences.Editor editor=settings.edit();
        editor.clear();
        editor.commit();

        editor=totalReminderId.edit();
        editor.clear();
        editor.commit();

        editor=savedObat.edit();
        editor.clear();
        editor.commit();

        editor=savedQueue.edit();
        editor.clear();
        editor.commit();

        LoginManager.getInstance().logOut();

        Toast.makeText(getContext(),"Berhasil keluar, mengarahkan...",Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(getContext(),LoginActivity.class);
        startActivity(intent);
    }

}
