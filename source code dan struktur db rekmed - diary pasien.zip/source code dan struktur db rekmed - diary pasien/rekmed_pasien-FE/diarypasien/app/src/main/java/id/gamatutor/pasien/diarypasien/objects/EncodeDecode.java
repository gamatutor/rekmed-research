package id.gamatutor.pasien.diarypasien.objects;

import java.util.Calendar;
import java.util.Random;
import java.util.TimeZone;

/**
 * Created by zmachmobile on 4/15/17.
 */

public class EncodeDecode {
    private EncodeDecode(){}

    private static String generateRandomString(int length){
        char[] chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < length; i++) {
            char c = chars[random.nextInt(chars.length)];
            sb.append(c);
        }
        String output = sb.toString();
        return output;
    }

    public static String encode(int number){
        String randomized=generateRandomString(5);
        Calendar cal=Calendar.getInstance();
        cal.setTimeZone(TimeZone.getTimeZone("Asia/Jakarta"));

        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH)+1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        int uniqueNumber=number+(year*month*day);
        String uniqueString=Base62.fromBase10(uniqueNumber);
        return randomized+uniqueString;
    }

    public static int decode(String encoded){
        Calendar cal=Calendar.getInstance();
        cal.setTimeZone(TimeZone.getTimeZone("Asia/Jakarta"));

        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH)+1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        String trimmed=encoded.substring(5);
        int uniqueNumber=Base62.toBase10(trimmed);
        return uniqueNumber-(year*month*day);
    }

    public static int uniq(int number){
        Calendar cal=Calendar.getInstance();
        cal.setTimeZone(TimeZone.getTimeZone("Asia/Jakarta"));

        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH)+1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
//        String uniqueNumber=number+"+"+"("+year+"*"+month+"*"+day+")";
        int uniqueNumber=number+(year*month*day);
        return uniqueNumber;
    }
}
