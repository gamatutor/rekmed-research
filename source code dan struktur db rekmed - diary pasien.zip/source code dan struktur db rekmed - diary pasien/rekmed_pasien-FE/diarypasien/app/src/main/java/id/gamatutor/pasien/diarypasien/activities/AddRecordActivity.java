package id.gamatutor.pasien.diarypasien.activities;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.wang.avi.AVLoadingIndicatorView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddRecordActivity extends AppCompatActivity {
    private EditText editTitle,editContent;
    private TextView alert,txtFilePreview;
    private Button btnAdd;
    private ImageButton btnCamera,btnAttach,btnGallery,btnFile;
    private Spinner spinMr;
    private ImageView imgCameraPreview,imgClose, imgBack;
    private AVLoadingIndicatorView loading;
    private SharedPreferences settings;
    private int userId;
    static final int REQUEST_TAKE_PHOTO = 1;
    static final int OPEN_GALLERY = 2;
    static final int OPEN_FILE = 3;
    private File photoFile;
    private Uri photoUri;
    private int selectedMrPos;
    private String mCurrentPhotoPath,fileTypeString,selectedMR;
    private boolean isButtonExposed=false;
    private Animation anim_open,anim_close,rotate_forward,rotate_backward;
    private List<String> list=new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_record);
//        initialize
        editTitle=(EditText)findViewById(R.id.editTitleAddRecord);
        editContent=(EditText)findViewById(R.id.editContentAddRecord);
        btnAdd=(Button)findViewById(R.id.btnAddRecord);
        btnCamera=(ImageButton)findViewById(R.id.btnCamera);
        btnAttach=(ImageButton)findViewById(R.id.btnAttach);
        btnGallery=(ImageButton)findViewById(R.id.btnGallery);
        btnFile=(ImageButton)findViewById(R.id.btnFile);
        loading=(AVLoadingIndicatorView)findViewById(R.id.loadingAddRecord);
        settings=getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        alert=(TextView)findViewById(R.id.txtAlertAddRecord);
        txtFilePreview=(TextView)findViewById(R.id.txtFilePreview);
        imgCameraPreview=(ImageView)findViewById(R.id.imgCamerapreview);
        imgClose=(ImageView)findViewById(R.id.imgClose);
        imgBack=(ImageView)findViewById(R.id.imgAddRecordBack);
        spinMr=(Spinner)findViewById(R.id.spinMrAddRecord);
        anim_open= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anim_open);
        anim_close= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anim_close);
        rotate_forward=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anim_rotate_forward);
        rotate_backward=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anim_rotate_backward);
        fileTypeString="none";
        selectedMR="";

        userId=settings.getInt("userId",0);
        loading.hide();
        btnCamera.setVisibility(View.INVISIBLE);
        btnGallery.setVisibility(View.INVISIBLE);
        btnFile.setVisibility(View.INVISIBLE);
        imgCameraPreview.setVisibility(View.GONE);
        imgClose.setVisibility(View.GONE);
        alert.setVisibility(View.GONE);
        txtFilePreview.setVisibility(View.GONE);

        loadMr();
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doAddRecord();
            }
        });
        btnAttach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                animateButton();
            }
        });
        btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dispatchTakePictureIntent();
            }
        });
        btnGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dispatchOpenGalleryIntent();
            }
        });
        btnFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dispatchOpenFileIntent();
            }
        });
        imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeAttachment();
            }
        });
        spinMr.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position != 0){
                    selectedMR= Config.credentials.getMrs().get(position-1);
                    selectedMrPos=position;
                }else{
                    selectedMrPos=position;
                    selectedMR="";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
    }

    private void loadMr() {
        list.clear();
        list.add("pilih no rekam medis untuk sharing");
        for(int i = 0; i< Config.credentials.getMrs().size(); i++){
            list.add(Config.credentials.getMrs().get(i));
        }
        Log.i("CREDENTIALS", Config.credentials.getMrs().toString());

        ArrayAdapter<String> dataAdapter=new ArrayAdapter<String>(getApplicationContext(),R.layout.spinner_style,list);
        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown_style);
        spinMr.setAdapter(dataAdapter);
    }

    private void removeAttachment() {
        photoFile=null;
        fileTypeString="none";
        imgCameraPreview.setVisibility(View.GONE);
        imgClose.setVisibility(View.GONE);
        txtFilePreview.setVisibility(View.GONE);
    }

    private void dispatchOpenFileIntent() {
        Intent intent = new Intent();
        intent.setType("*/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Pilih Berkas"),OPEN_FILE);
    }

    private void dispatchOpenGalleryIntent() {
//        Intent intent = new Intent();
//        intent.setType("image/*");
//        intent.setAction(Intent.ACTION_GET_CONTENT);//
//        startActivityForResult(Intent.createChooser(intent, "Pilih Gambar"),OPEN_GALLERY);
        Intent intent=new Intent(getApplicationContext(),GalleryActivity.class);
        startActivityForResult(intent,OPEN_GALLERY);
    }

    private void animateButton() {
        if(isButtonExposed==false){
            btnAttach.startAnimation(rotate_forward);
            btnCamera.startAnimation(anim_open);
//            btnFile.startAnimation(anim_open);
//            btnGallery.startAnimation(anim_open);
            btnFile.setVisibility(View.GONE);
            btnGallery.setVisibility(View.GONE);
            isButtonExposed=true;
        }else{
            btnAttach.startAnimation(rotate_backward);
            btnCamera.startAnimation(anim_close);
//            btnFile.startAnimation(anim_close);
//            btnGallery.startAnimation(anim_close);
            btnFile.setVisibility(View.GONE);
            btnGallery.setVisibility(View.GONE);
            isButtonExposed=false;
        }
    }

    private void dispatchTakePictureIntent() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_TAKE_PHOTO);
            }
        }
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.example.android.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                List<ResolveInfo> resInfoList = getPackageManager().queryIntentActivities(takePictureIntent, PackageManager.MATCH_DEFAULT_ONLY);
                for (ResolveInfo resolveInfo : resInfoList) {
                    String packageName = resolveInfo.activityInfo.packageName;
                    grantUriPermission(packageName, photoURI, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode== REQUEST_TAKE_PHOTO && resultCode==RESULT_OK){
            fileTypeString="image";
            txtFilePreview.setVisibility(View.GONE);
            imgClose.setVisibility(View.VISIBLE);
            setPic();
        }else if(requestCode== OPEN_GALLERY && resultCode==RESULT_OK){
            if(data != null){
                fileTypeString="image";
//                mCurrentPhotoPath=getImagePathFromUri(getApplicationContext(),data.getData());
                Bundle extras=data.getExtras();
                mCurrentPhotoPath=extras.getString("data");
                Uri uri=Uri.parse(mCurrentPhotoPath);
                photoFile=new File(uri.getPath());
                txtFilePreview.setVisibility(View.GONE);
                imgClose.setVisibility(View.VISIBLE);
                setPic();
            }
        }else if(requestCode== OPEN_FILE && resultCode==RESULT_OK){
            if(data != null){
                fileTypeString="file";
                imgCameraPreview.setVisibility(View.GONE);
                mCurrentPhotoPath=getFilePathFromUri(getApplicationContext(),data.getData());
                Uri uri=Uri.parse(mCurrentPhotoPath);
                photoFile=new File(uri.getPath());
                txtFilePreview.setText(mCurrentPhotoPath.substring(mCurrentPhotoPath.lastIndexOf("/")+1));
                txtFilePreview.setVisibility(View.VISIBLE);
                imgClose.setVisibility(View.VISIBLE);
            }
        }
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        photoUri=Uri.parse(mCurrentPhotoPath);
        return image;
    }

    private void setPic() {
        Display display=getWindowManager().getDefaultDisplay();
        Point size=new Point();
        display.getSize(size);
        // Get the dimensions of the View
        int targetW = size.x/2;
        int targetH = size.x/2;

        // Get the dimensions of the bitmap
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(mCurrentPhotoPath, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

        // Determine how much to scale down the image
        int scaleFactor = Math.min(photoW/targetW, photoH/targetH);

        // Decode the image file into a Bitmap sized to fill the View
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;
        bmOptions.inPurgeable = true;

        Bitmap bitmap = BitmapFactory.decodeFile(mCurrentPhotoPath, bmOptions);
        imgCameraPreview.setVisibility(View.VISIBLE);
        imgCameraPreview.setImageBitmap(bitmap);
    }

    private void doAddRecord() {
        loading.show();
        Call<Object> call;

        RequestBody userid=RequestBody.create(MultipartBody.FORM,String.valueOf(userId));
        RequestBody title=RequestBody.create(MultipartBody.FORM,editTitle.getText().toString());
        RequestBody content=RequestBody.create(MultipartBody.FORM,editContent.getText().toString());
        RequestBody attachment=RequestBody.create(MultipartBody.FORM,"");
        RequestBody filetype=RequestBody.create(MultipartBody.FORM,fileTypeString);
        RequestBody mr=RequestBody.create(MultipartBody.FORM,selectedMR);

        if(photoFile != null){
            RequestBody requestFile=RequestBody.create(MediaType.parse("*/*"),photoFile);
            MultipartBody.Part photo=MultipartBody.Part.createFormData("upload",photoFile.getName(),requestFile);
            call= ApiClient.connect().addRecord(userid,title,content,attachment,filetype,mr,photo);
        }else{
            call=ApiClient.connect().addRecord(userid,title,content,filetype,mr);
        }

        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        alert.setText(obj.getString("message"));
                        alert.setVisibility(View.VISIBLE);
                        Log.i("STATUS UPLOAD",obj.getString("message"));
                    }else{
                        Log.i("STATUS UPLOAD",obj.getString("message"));
                        alert.setVisibility(View.GONE);
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(getApplicationContext(),HomeActivity.class);
                        startActivity(intent);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.i("STATUS UPLOAD",e.toString());
                }
                loading.hide();
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    public static String getImagePathFromUri(Context context, Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = { MediaStore.Images.Media.DATA };
            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public String getFilePathFromUri(Context context, Uri contentUri) {
        String result;
        Cursor cursor = getContentResolver().query(contentUri, null, null, null, null);
        if (cursor == null) { // Source is Dropbox or other similar local file path
            result = contentUri.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }
}
