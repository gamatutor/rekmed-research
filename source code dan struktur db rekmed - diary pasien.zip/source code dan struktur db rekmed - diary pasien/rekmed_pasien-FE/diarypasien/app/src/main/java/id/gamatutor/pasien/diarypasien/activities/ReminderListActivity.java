package id.gamatutor.pasien.diarypasien.activities;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.adapters.ReminderAdapter;
import id.gamatutor.pasien.diarypasien.models.ReminderDetailModel;
import id.gamatutor.pasien.diarypasien.objects.ReminderDetail;
import io.realm.Realm;

public class ReminderListActivity extends AppCompatActivity {
    @BindView(R.id.recyclerReminder) RecyclerView recyclerView;
    @BindView(R.id.imgReminderBack) ImageView imgBack;
    @BindView(R.id.fab) FloatingActionButton btnAdd;
    private ReminderAdapter reminderAdapter;
    private List<ReminderDetail> schedules = new ArrayList<ReminderDetail>();
    private Bundle extras;
    private ReminderDetailModel reminderDetailModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_list);
        ButterKnife.bind(this);

        reminderDetailModel=new ReminderDetailModel();
        extras=getIntent().getExtras();

        reminderAdapter=new ReminderAdapter(getApplicationContext(),schedules);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(reminderAdapter);

        loadData();
    }

    @OnClick(R.id.imgReminderBack)
    void getBack(){
        //                startActivity(new Intent(getApplicationContext(),MedicineActivity.class));
        finish();
        overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
    }

    @OnClick(R.id.fab)
    void gotoAdd(){
        startActivity(new Intent(getApplicationContext(),AddReminderActivity.class));
    }

    private void loadData() {
        int reminderId = extras.getInt("reminderId");
        schedules.clear();
        schedules.addAll(reminderDetailModel.getItemByPid(reminderId));
        reminderAdapter.notifyDataSetChanged();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }
}
