package id.gamatutor.pasien.diarypasien.activities;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import id.gamatutor.pasien.diarypasien.BuildConfig;
import id.gamatutor.pasien.diarypasien.R;

public class AboutActivity extends AppCompatActivity {

    private ImageView btnBack;
    private TextView contactWeb, contactPhone, version;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        btnBack = (ImageView) findViewById(R.id.imgAboutBack);
        contactWeb = (TextView) findViewById(R.id.contactWeb);
        contactPhone = (TextView) findViewById(R.id.contactPhone);
        version = (TextView)findViewById(R.id.txtVersionAbout);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
        contactWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(getResources().getString(R.string.contact_web)));
                startActivity(intent);
            }
        });
        contactPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://api.whatsapp.com/send?phone="+getResources().getString(R.string.contact_phone_number)));
                intent.setPackage("com.whatsapp");
                startActivity(intent);

//                PackageManager pm=getPackageManager();
//                try {
//                    PackageInfo info=pm.getPackageInfo("com.whatsapp",PackageManager.GET_META_DATA);
//                    Intent intent = new Intent("android.intent.action.MAIN");
//                    intent.setAction(Intent.ACTION_SEND);
//                    intent.setType("text/plain");
//                    intent.setPackage("com.whatsapp");
//                    intent.putExtra("jid","+6282133762905@s.whatsapp.net");
//                    startActivity(intent);
//                } catch (PackageManager.NameNotFoundException e) {
//                    Toast.makeText(getApplicationContext(),"WhatsApp tidak terpasang di perangkat Anda",Toast.LENGTH_SHORT).show();
//                    e.printStackTrace();
//                }
            }
        });

        version.setText("v"+BuildConfig.VERSION_NAME);
    }
}
