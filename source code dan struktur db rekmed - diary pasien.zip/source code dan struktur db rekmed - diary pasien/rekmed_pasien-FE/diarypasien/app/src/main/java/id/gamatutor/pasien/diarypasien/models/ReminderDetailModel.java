package id.gamatutor.pasien.diarypasien.models;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

import id.gamatutor.pasien.diarypasien.interfaces.BaseModel;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.objects.Reminder;
import id.gamatutor.pasien.diarypasien.objects.ReminderDetail;
import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmResults;
import io.realm.Sort;

public class ReminderDetailModel implements BaseModel {
    Realm realm;

    public ReminderDetailModel(){
        realm=Realm.getDefaultInstance();
    }

    @Override
    public ArrayList getAll() {
        return null;
    }

    @Override
    public Object getItem(int key) {
        ReminderDetail response = realm.where(ReminderDetail.class).equalTo("pid",key).findFirst();
        return response;
    }

    @Override
    public void addItem(Bundle bundle) {
        realm.beginTransaction();
        ReminderDetail detail=realm.createObject(ReminderDetail.class);
        detail.setReminderId(bundle.getInt("reminderId"));
        detail.setPid(bundle.getInt("pid"));
        detail.setTitle(bundle.getString("title"));
        detail.setCalendarMillis(bundle.getLong("calendarMillis"));
        detail.setActive(bundle.getBoolean("isActive"));
        realm.commitTransaction();
    }

    @Override
    public void updateItem(int key, Bundle bundle) {
        realm.beginTransaction();
        ReminderDetail detail=realm.where(ReminderDetail.class).equalTo("pid",key).findFirst();
        detail.setTitle(bundle.getString("title"));
        detail.setCalendarMillis(bundle.getLong("calendarMillis"));
        detail.setActive(bundle.getBoolean("isActive"));
        realm.commitTransaction();
    }

    @Override
    public void deleteItem(int key) {
        realm.beginTransaction();
        realm.where(ReminderDetail.class).equalTo("pid",key).findFirst().deleteFromRealm();
        realm.commitTransaction();
    }

    @Override
    public void flushAll() {

    }

    public ArrayList<ReminderDetail> getItemByPid(int reminderId){
        RealmResults<ReminderDetail> responses = realm.where(ReminderDetail.class).equalTo("reminderId",reminderId).findAll();
        ArrayList<ReminderDetail> results = new ArrayList<>();
        for(int i=0;i<responses.size();i++){
            results.add(responses.get(i));
        }
        return results;
    }

    public int getLastPid(){
        ReminderDetail reminderDetail = realm.where(ReminderDetail.class).sort("pid", Sort.DESCENDING).findFirst();
        return reminderDetail.getPid();
    }

    public void addAll(ArrayList<Bundle> bundles){
        realm.beginTransaction();
        for(int i=0;i<bundles.size();i++){
            Bundle bundle = bundles.get(i);
            ReminderDetail detail=realm.createObject(ReminderDetail.class);
            detail.setReminderId(bundle.getInt("reminderId"));
            detail.setPid(bundle.getInt("pid"));
            detail.setTitle(bundle.getString("title"));
            detail.setCalendarMillis(bundle.getLong("calendarMillis"));
            detail.setActive(bundle.getBoolean("isActive"));
        }
        realm.commitTransaction();
    }

    public void updateAll(int reminderId, boolean isActive){
        realm.beginTransaction();
        RealmResults<ReminderDetail> reminderDetails = realm.where(ReminderDetail.class).equalTo("reminderId", reminderId).findAll();
        for(int i=0;i<reminderDetails.size();i++){
            ReminderDetail reminderDetail = reminderDetails.get(i);
            reminderDetail.setActive(isActive);
        }
        realm.commitTransaction();
    }
}
