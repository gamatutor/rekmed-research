package id.gamatutor.pasien.diarypasien.activities;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.objects.Promo;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.adapters.PromoAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PromoActivity extends AppCompatActivity {
    private SharedPreferences settings;
    private int userId;
    private float y1,y2;
    private RecyclerView recyclerView;
    private ImageView imgBack;
    private PromoAdapter promoAdapter;
    private List<Promo> promoList=new ArrayList<>();
    static final int MIN_DISTANCE = 400;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_promo);
//        Initialize
        recyclerView=(RecyclerView)findViewById(R.id.recyclerPromo);
        settings=getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        imgBack=(ImageView)findViewById(R.id.imgPromoBack);
        userId=settings.getInt("userId",0);
        promoAdapter=new PromoAdapter(getApplicationContext(),promoList);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(promoAdapter);

        preparePromoData();

//        recyclerView.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                switch (event.getAction()){
//                    case MotionEvent.ACTION_DOWN:
//                        y1=event.getY();
//                    case MotionEvent.ACTION_UP:
//                        y2=event.getY();
//                        float deltaY=y2-y1;
//                        if(Math.abs(deltaY) > MIN_DISTANCE){
//                            promoList.clear();
//                            promoAdapter.notifyDataSetChanged();
//                            preparePromoData();
//                            Toast.makeText(getApplicationContext(),"Reloading...",Toast.LENGTH_SHORT).show();
//                        }
//                        break;
//                }
//                return true;
//            }
//        });

        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
    }

    private void preparePromoData() {
        promoList.clear();
        promoAdapter.notifyDataSetChanged();
        String encodedId= EncodeDecode.encode(userId);
        Call<Object> call= ApiClient.connect().getPromo(encodedId);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        JSONArray arrdata=obj.getJSONArray("data");
                        for(int i=0;i<arrdata.length();i++){
                            JSONObject data=arrdata.getJSONObject(i);
                            Log.i("DATA",data.toString());
                            promoList.add(
                                    new Promo(
                                            data.getString("title"),
                                            data.getString("description"),
                                            Config.getBaseUrl()+"/uploads/"+data.getString("img"),
                                            data.getString("url")
                                    ));
                            promoAdapter.notifyDataSetChanged();
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }
}
