package id.gamatutor.pasien.diarypasien.objects;

/**
 * Created by zmachmobile on 8/29/17.
 */

public class Klinik {
    public int id;
    public String title, address, phone;
    public Klinik(int id, String title, String address, String phone){
        this.id=id;
        this.title=title;
        this.address=address;
        this.phone=phone;
    }
}
