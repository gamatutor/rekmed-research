package id.gamatutor.pasien.diarypasien.objects;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by zmachmobile on 6/29/17.
 */

public class FBClient {
    public static FBInterface connect(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Config.fbUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        FBInterface service = retrofit.create(FBInterface.class);
        return service;
    }
}
