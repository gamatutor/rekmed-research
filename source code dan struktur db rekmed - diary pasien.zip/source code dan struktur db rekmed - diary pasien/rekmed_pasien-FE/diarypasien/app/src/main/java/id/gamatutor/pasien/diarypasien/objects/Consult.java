package id.gamatutor.pasien.diarypasien.objects;

/**
 * Created by zmachmobile on 6/13/17.
 */

public class Consult {
    public int id,pid;
    public String title, due;
    public boolean active;
    public Consult(int id, int pid, String title, String due, boolean active){
        this.id=id;
        this.pid=pid;
        this.title=title;
        this.due=due;
        this.active=active;
    }
}
