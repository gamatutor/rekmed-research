package id.gamatutor.pasien.diarypasien.modules;

import android.content.Context;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.LinearSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;

import java.util.ArrayList;

import dagger.Module;
import dagger.Provides;
import id.gamatutor.pasien.diarypasien.adapters.MedicineAdapter;
import id.gamatutor.pasien.diarypasien.objects.Reminder;

@Module
public class MedicineModule {

    ArrayList<Reminder> reminders;
    RecyclerView recyclerView;
    Context context;

    public MedicineModule(ArrayList<Reminder> reminders, RecyclerView recyclerView,Context context){
        this.reminders=reminders;
        this.recyclerView=recyclerView;
        this.context=context;
    }

    @Provides
    public MedicineAdapter medicineAdapter(){
        MedicineAdapter medicineAdapter=new MedicineAdapter(this.context,this.reminders);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(this.context);
        this.recyclerView.setLayoutManager(layoutManager);
        this.recyclerView.setItemAnimator(new DefaultItemAnimator());
        this.recyclerView.setAdapter(medicineAdapter);
        SnapHelper helper = new LinearSnapHelper();
        helper.attachToRecyclerView(this.recyclerView);
        return medicineAdapter;
    }
}
