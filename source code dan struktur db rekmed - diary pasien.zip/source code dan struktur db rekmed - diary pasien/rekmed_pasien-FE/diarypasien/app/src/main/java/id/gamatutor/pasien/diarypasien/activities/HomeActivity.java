package id.gamatutor.pasien.diarypasien.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.adapters.NavbarAdapter;
import id.gamatutor.pasien.diarypasien.fragments.AboutFragment;
import id.gamatutor.pasien.diarypasien.fragments.AccountFragment;
import id.gamatutor.pasien.diarypasien.fragments.HomeFragment;
import id.gamatutor.pasien.diarypasien.fragments.TermFragment;
import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.Cell;
import id.gamatutor.pasien.diarypasien.objects.Credentials;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ArrayList<Cell> cells=new ArrayList<>();
    private NavbarAdapter navbarAdapter;
    private SharedPreferences settings,settingServer;
    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;
    private int userId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        settings=getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        settingServer=getSharedPreferences(Config.sharedPrefServer, MODE_PRIVATE);
        userId=settings.getInt("userId",0);

        if(userId==0){
            startActivity(new Intent(this,LoginActivity.class));
        }else{
            getBasicCredentials(userId);
        }

        fragmentManager=getSupportFragmentManager();
        fragmentTransaction=fragmentManager.beginTransaction();

        fragmentTransaction.add(R.id.frameLayout,new HomeFragment());
        fragmentTransaction.commit();

        navbarAdapter=new NavbarAdapter(getApplicationContext(),cells,fragmentManager);
        recyclerView=(RecyclerView) findViewById(R.id.recyclerView);

        loadNavbar();

        Config.baseUrl=settingServer.getString("server", Config.getBaseUrl());
    }

    private void loadNavbar() {
        Fragment fragment=new HomeFragment();
        Cell cell=new Cell(1,R.drawable.icon_home,"Beranda","#8D33CC",fragment);
        cells.add(cell);

        fragment=new AboutFragment();
        cell=new Cell(2,R.drawable.icon_info,"Tentang","#8D33CC",fragment);
        cells.add(cell);

        fragment= new TermFragment();
        cell=new Cell(3,R.drawable.icon_book,"Ketentuan","#8D33CC",fragment);
        cells.add(cell);

        fragment=new AccountFragment();
        cell=new Cell(4,R.drawable.icon_user,"Akun Saya","#8D33CC",fragment);
        cells.add(cell);

        recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(),cells.size()));
        recyclerView.setAdapter(navbarAdapter);
        navbarAdapter.notifyDataSetChanged();

    }

    private void getBasicCredentials(final int id) {
        String encodedId= EncodeDecode.encode(id);
        Log.i("ENCODED",encodedId);
        Call<Object> call= ApiClient.connect().getCredentials(encodedId);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                Log.i("RESPONSE",responseStr);
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_LONG).show();
                    }else{
                        JSONObject data=obj.getJSONObject("data");
                        DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd");
                        if(data.has("email")){
                            Config.credentials=new Credentials(id,data.getString("email"));
                        }
                        if(data.has("name")){
                            Config.credentials.setName(data.getString("name"));
                        }
                        if(data.has("address")){
                            Config.credentials.setAddress(data.getString("address"));
                        }
                        if(data.has("birth_at")){
                            try {
                                Config.credentials.setBirth(dateFormat.parse(data.getString("birth_at")));
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                        }
                        if(data.has("gender")){
                            if(data.getString("gender").equals("MALE")){
                                Config.credentials.setGender(1);
                            }else{
                                Config.credentials.setGender(0);
                            }
                        }
                        if(data.has("phone")){
                            Config.credentials.setPhone(data.getString("phone"));
                        }
                        if(data.has("kelurahan_id")){
                            Config.credentials.setKelurahanId(data.getString("kelurahan_id"));
                        }
                        if(data.has("mr")){
                            Log.i("MR",data.getJSONArray("mr").toString());
                            List<String> mrsList=new ArrayList<String>();
                            JSONArray arrdata=data.getJSONArray("mr");
                            for(int i=0;i<arrdata.length();i++){
                                mrsList.add(arrdata.get(i).toString());
                            }
                            Config.credentials.setMrs(mrsList);
                        }
                        if(data.has("img")){
                            if(data.getString("img").equals("")==false){
                                Config.credentials.setImg(data.getString("img"));
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }
}
