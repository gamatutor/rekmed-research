package id.gamatutor.pasien.diarypasien.activities;

import android.app.SearchManager;
import android.content.Intent;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.adapters.KlinikAdapter;
import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.EndlessRecyclerViewScrollListener;
import id.gamatutor.pasien.diarypasien.objects.Klinik;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class KlinikActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private KlinikAdapter klinikAdapter;
    private ArrayList<Klinik> klinikList=new ArrayList<Klinik>();
    private Toolbar toolbar;
    private String query="";
    private SwipeRefreshLayout swipeRefresh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_klinik);

        toolbar=(Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle("Pilih dokter/klinik/RS");
        setSupportActionBar(toolbar);

        ActionBar actionBar=getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        recyclerView=(RecyclerView)findViewById(R.id.recyclerView);
        swipeRefresh=(SwipeRefreshLayout)findViewById(R.id.swipeRefresh);

        RecyclerView.LayoutManager mLayoutManager=new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addOnScrollListener(new EndlessRecyclerViewScrollListener(mLayoutManager) {
            @Override
            public void onLoadMore(int page, int totalItemsCount) {
                Log.i("DEBUG","LOAD MORE");
                loadData(page,query);
            }
        });

        klinikAdapter=new KlinikAdapter(getApplicationContext(),klinikList);
        recyclerView.setAdapter(klinikAdapter);

        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadData(1,"");
            }
        });

        loadData(1,query);

        handleIntent(getIntent());
    }

    private void handleIntent(Intent intent) {
        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            query = intent.getStringExtra(SearchManager.QUERY);
            Toast.makeText(getApplicationContext(),query,Toast.LENGTH_SHORT).show();
            loadData(1,query);
            //use the query to search your data somehow
        }
    }

    private void loadData(int page,String query) {
        swipeRefresh.setRefreshing(false);
        if (page==1){
            klinikList.clear();
            klinikAdapter.notifyDataSetChanged();
        }
        Call<Object> call= ApiClient.connect().getKlinik(page,query);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                Log.i("DEBUG",responseStr);
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        JSONArray arrdata=obj.getJSONArray("data");
                        for(int i=0;i<arrdata.length();i++){
                            JSONObject data=arrdata.getJSONObject(i);
                            int dataid=data.getInt("id");
                            String nama,alamat,telp;
                            try{
                                nama=data.getString("nama");
                            }catch (Exception e){
                                nama="Anonymous";
                            }
                            try{
                                alamat=data.getString("alamat");
                            }catch (Exception e){
                                alamat="Nowhere";
                            }
                            try{
                                telp=data.getString("telp");
                            }catch (Exception e){
                                telp="None";
                            }
                            Klinik klinik=new Klinik(dataid,nama,alamat,telp);
                            klinikList.add(klinik);
                        }
                        klinikAdapter.notifyDataSetChanged();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);

        // Associate searchable configuration with the SearchView
        SearchManager searchManager=(SearchManager)getSystemService(SEARCH_SERVICE);
        SearchView searchView=(SearchView)menu.findItem(R.id.action_search).getActionView();
//        search in another activity
//        ComponentName cn = new ComponentName(this, SearchResultsActivity.class);
//        searchView.setSearchableInfo(searchManager.getSearchableInfo(cn));
//        search in own activity
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));

        MenuItem search=menu.findItem(R.id.action_search);
        MenuItemCompat.setOnActionExpandListener(search, new MenuItemCompat.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                loadData(1,"");
                return true;
            }
        });

        return true;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        handleIntent(intent);
    }
}
