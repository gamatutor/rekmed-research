package id.gamatutor.pasien.diarypasien.activities;

import android.app.SearchManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import id.gamatutor.pasien.diarypasien.objects.ApiClient;
import id.gamatutor.pasien.diarypasien.objects.EncodeDecode;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.R;
import id.gamatutor.pasien.diarypasien.objects.Record;
import id.gamatutor.pasien.diarypasien.adapters.RecordAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchResultsActivity extends AppCompatActivity {
    private SharedPreferences settings;
    private int userId;
    private List<Record> recordList=new ArrayList<>();
    private RecyclerView recyclerView;
    private RecordAdapter recordAdapter;
    private SwipeRefreshLayout swipeRefresh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbarSearch);
        setSupportActionBar(myToolbar);
        ActionBar ab = getSupportActionBar();
        ab.setDisplayHomeAsUpEnabled(true);
        ab.setTitle("Hasil pencarian");

        swipeRefresh=(SwipeRefreshLayout)findViewById(R.id.swipeRefreshRecord);
        settings=getSharedPreferences(Config.sharedPrefName, MODE_PRIVATE);
        userId=settings.getInt("userId",0);

        recyclerView=(RecyclerView)findViewById(R.id.recyclerViewSearch);
        recordAdapter=new RecordAdapter(getApplicationContext(),recordList);
        RecyclerView.LayoutManager mLayoutManager=new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(recordAdapter);

        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            String query = intent.getStringExtra(SearchManager.QUERY);
            prepareRecordData(query);
        }

    }

    private void prepareRecordData(String query) {
        String encodedId= EncodeDecode.encode(userId);
        Call<Object> call= ApiClient.connect().searchRecord(encodedId,query);
        call.enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                String responseStr=new Gson().toJson(response.body());
                try {
                    JSONObject obj=new JSONObject(responseStr);
                    if(obj.getInt("status")==0){
                        Toast.makeText(getApplicationContext(),obj.getString("message"),Toast.LENGTH_SHORT).show();
                    }else{
                        JSONArray arrdata=obj.getJSONArray("data");
                        for(int i=0;i<arrdata.length();i++){
                            JSONObject data=arrdata.getJSONObject(i);
                            Log.i("RECORDS",data.toString());
                            Record record=new Record(data.getInt("id"),data.getString("title"),data.getString("content"),data.getString("updated_at"));
                            record.setFiletype(data.getString("filetype"));
                            if(data.getString("filetype").equals("none")==false){
                                record.setAttachment(Config.getBaseUrl()+"/uploads/"+data.getString("attachment"));
                            }
                            recordList.add(record);
                        }
//                        add empty record
                        Record record=new Record(0,"","","");
                        recordList.add(record);
                        recordAdapter.notifyDataSetChanged();
                        swipeRefresh.setRefreshing(false);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Log.e("ERROR",t.toString());
            }
        });
    }
}
