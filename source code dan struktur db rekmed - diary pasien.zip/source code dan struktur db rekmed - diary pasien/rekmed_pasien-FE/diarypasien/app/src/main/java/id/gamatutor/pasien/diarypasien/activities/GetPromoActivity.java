package id.gamatutor.pasien.diarypasien.activities;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import id.gamatutor.pasien.diarypasien.objects.Promo;
import id.gamatutor.pasien.diarypasien.R;

public class GetPromoActivity extends AppCompatActivity {
    private ImageView imgBack, imgPreview;
    private Button btnVisit;
    private TextView txtTitle, txtDescription;
    private Promo promo;
    private Bundle extras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_promo);

        imgBack=(ImageView)findViewById(R.id.imgGetPromoBack);
        imgPreview=(ImageView)findViewById(R.id.imgPreviewGetPromo);
        btnVisit=(Button)findViewById(R.id.btnVisitGetPromo);
        txtTitle=(TextView)findViewById(R.id.txtTitleGetPromo);
        txtDescription=(TextView)findViewById(R.id.txtDescriptionGetPromo);

        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(),PromoActivity.class));
                finish();
                overridePendingTransition(R.anim.anim_slide_enter, R.anim.anim_slide_exit);
            }
        });
        btnVisit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(promo.getUrl()!=null && promo.getUrl().equals("")==false){
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(promo.getUrl()));
                    startActivity(intent);
                }
            }
        });
        imgPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),ImageActivity.class);
                intent.putExtra("url",promo.getImg());
                intent.putExtra("title",promo.getTitle());
                startActivity(intent);
            }
        });

        extras=getIntent().getExtras();
        try {
            JSONObject data=new JSONObject(extras.getString("promo"));
            promo=new Promo(data.getString("title"),data.getString("description"),data.getString("img"),data.getString("url"));
            txtTitle.setText(promo.getTitle());
            txtDescription.setText(promo.getDescription());
            Picasso.with(getApplicationContext())
                    .load(promo.getImg())
                    .into(imgPreview);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }
}
