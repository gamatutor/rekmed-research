package id.gamatutor.pasien.diarypasien.objects;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.DELETE;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Created by zmachmobile on 4/14/17.
 */

public interface ApiInterface {
//    User
    @FormUrlEncoded
    @POST("signup")
    Call<Object> doSignup(@Field("email") String email,@Field("password") String password);

    @FormUrlEncoded
    @POST("login")
    Call<Object> doLogin(@Field("email") String email,@Field("password") String password);

    @FormUrlEncoded
    @POST("change/{id}")
    Call<Object> changePassword(@Path("id") String id, @Field("password") String password,@Field("password_again") String password_again);

    @GET("account/{id}")
    Call<Object> getCredentials(@Path("id") String id);

    @GET("forget")
    Call<Object> doForget(@Query("email") String email);

    @Multipart
    @POST("update/{uid}")
    Call<Object> editAccount(@Path("uid") String uid, @Part("name") RequestBody name, @Part("phone") RequestBody phone, @Part("birth_at") RequestBody birth_at, @Part("gender") RequestBody gender, @Part("address") RequestBody address, @Part("kelurahan_id") RequestBody kelurahan_id, @Part("mrs") RequestBody mrs, @Part("_method") RequestBody method, @Part MultipartBody.Part upload);

    @Multipart
    @POST("update/{uid}")
    Call<Object> editAccount(@Path("uid") String uid, @Part("name") RequestBody name, @Part("phone") RequestBody phone, @Part("birth_at") RequestBody birth_at, @Part("gender") RequestBody gender, @Part("address") RequestBody address, @Part("kelurahan_id") RequestBody kelurahan_id, @Part("mrs") RequestBody mrs, @Part("_method") RequestBody method);

    @GET("gettoken")
    Call<Object> getToken();

    @FormUrlEncoded
    @POST("fblogin")
    Call<Object> fbLogin(@Field("email") String email, @Field("name") String name, @Field("gender") int gender,@Field("token") String accessToken);

//    Update
    @GET("checkupdates/{id}")
    Call<Object> getUpdates(@Path("id") int version);

//    Record
    @GET("record/{id}")
    Call<Object> getRecords(@Path("id") String id);

    @GET("getrecord/{id}")
    Call<Object> getRecord(@Path("id") String id);

    @GET("searchrecord/{id}")
    Call<Object> searchRecord(@Path("id") String id, @Query("search") String search);

    @Multipart
    @POST("record")
    Call<Object> addRecord(@Part("user_id") RequestBody id, @Part("title") RequestBody title, @Part("content") RequestBody content, @Part("attachment") RequestBody attachment, @Part("filetype") RequestBody filetype, @Part("mr") RequestBody mr, @Part MultipartBody.Part upload);

    @Multipart
    @POST("record")
    Call<Object> addRecord(@Part("user_id") RequestBody id, @Part("title") RequestBody title, @Part("content") RequestBody content, @Part("filetype") RequestBody filetype, @Part("mr") RequestBody mr);

    @Multipart
    @POST("record/{rid}")
    Call<Object> editRecord(@Path("rid") String rid, @Part("user_id") RequestBody userId, @Part("title") RequestBody title, @Part("content") RequestBody content, @Part("attachment") RequestBody attachment, @Part("filetype") RequestBody filetype, @Part("mr") RequestBody mr, @Part MultipartBody.Part upload, @Part("_method") RequestBody method);

    @Multipart
    @POST("record/{rid}")
    Call<Object> editRecord(@Path("rid") String rid, @Part("user_id") RequestBody userId, @Part("title") RequestBody title, @Part("content") RequestBody content, @Part("filetype") RequestBody filetype, @Part("mr") RequestBody mr, @Part("_method") RequestBody method);

    @DELETE("record/{id}")
    Call<Object> deleteRecords(@Path("id") String id);

//    Queue
    @GET("checkqueue/{id}")
    Call<Object> getQueue(@Path("id") String id);

//    Medicine
    @GET("checkmedicine/{id}")
    Call<Object> getMedicine(@Path("id") String id);

//    Promo
    @GET("promo/{id}")
    Call<Object> getPromo(@Path("id") String id);

//    Local
    @GET("getprovinsi")
    Call<Object> getProvinsi();

    @GET("getkabupaten/{id}")
    Call<Object> getKabupaten(@Path("id") String id);

    @GET("getkecamatan/{id}")
    Call<Object> getKecamatan(@Path("id") String id);

    @GET("getkelurahan/{id}")
    Call<Object> getKelurahan(@Path("id") String id);

//    Consult
    @GET("consult/{id}")
    Call<Object> getConsults(@Path("id") String id);

    @GET("getconsult/{id}")
    Call<Object> getConsult(@Path("id") String id);

    @Multipart
    @POST("consult")
    Call<Object> addConsult(@Part("user_id") RequestBody userId, @Part("title") RequestBody title, @Part("due") RequestBody due, @Part("active") RequestBody active);

    @Multipart
    @POST("consult/{id}")
    Call<Object> editConsult(@Path("id") String id, @Part("user_id") RequestBody userId, @Part("title") RequestBody title, @Part("due") RequestBody due, @Part("active") RequestBody active, @Part("_method") RequestBody method);

    @DELETE("consult/{id}")
    Call<Object> deleteConsult(@Path("id") String id);

//    Daftar online
    @GET("klinik")
    Call<Object> getKlinik(@Query("page") int page, @Query("query") String query);

    @FormUrlEncoded
    @POST("syncpasien")
    Call<Object> syncPasien(@Field("user_id") String userId, @Field("klinik_id") int klinikId, @Field("tanggal_periksa") String tglPeriksa, @Field("dokter_id") int dokterId);

    @GET("dokter/{id}")
    Call<Object> getDokter(@Path("id") String klinikId);
}
