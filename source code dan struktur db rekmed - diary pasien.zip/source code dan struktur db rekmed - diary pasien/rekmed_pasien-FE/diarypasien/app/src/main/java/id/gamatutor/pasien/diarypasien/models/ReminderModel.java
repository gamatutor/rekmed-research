package id.gamatutor.pasien.diarypasien.models;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

import id.gamatutor.pasien.diarypasien.interfaces.BaseModel;
import id.gamatutor.pasien.diarypasien.objects.Config;
import id.gamatutor.pasien.diarypasien.objects.Reminder;
import id.gamatutor.pasien.diarypasien.objects.ReminderDetail;
import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmResults;

public class ReminderModel implements BaseModel{
    private Realm realm;

    public ReminderModel(){
        realm = Realm.getDefaultInstance();
    }

    @Override
    public ArrayList<Reminder> getAll(){
        RealmResults<Reminder> results = realm.where(Reminder.class).findAll();
        ArrayList<Reminder> response=new ArrayList<>();
        for(int i=0;i<results.size();i++){
            response.add(results.get(i));
        }
        return response;
    }

    @Override
    public Object getItem(int pid){
        Reminder reminder = realm.where(Reminder.class).equalTo("pid",pid).findFirst();
        return reminder;
    }

    @Override
    public void addItem(Bundle bundle){
        realm.beginTransaction();
        Reminder reminder = realm.createObject(Reminder.class);
        reminder.setPid(bundle.getInt("pid"));
        reminder.setObat(bundle.getString("obat"));
        reminder.setSigna(bundle.getInt("signa"));
        reminder.setExpired(bundle.getString("expired"));
        reminder.setAmount(bundle.getInt("amount"));
        reminder.setActive(bundle.getBoolean("isActive"));
        realm.commitTransaction();
        Log.d("DEBUG","added");
    }

    @Override
    public void updateItem(int pid, Bundle bundle){
        realm.beginTransaction();
        Reminder reminder = realm.where(Reminder.class).equalTo("pid",pid).findFirst();
        reminder.setObat(bundle.getString("obat"));
        reminder.setSigna(bundle.getInt("signa"));
        reminder.setExpired(bundle.getString("expired"));
        reminder.setAmount(bundle.getInt("amount"));
        reminder.setActive(bundle.getBoolean("isActive"));
        realm.commitTransaction();
    }

    @Override
    public void deleteItem(int pid){
        realm.beginTransaction();
        realm.where(Reminder.class).equalTo("pid",pid).findFirst().deleteFromRealm();
        realm.where(ReminderDetail.class).equalTo("reminderId",pid).findAll().deleteAllFromRealm();
        realm.commitTransaction();
    }

    @Override
    public void flushAll() {
        realm.beginTransaction();
        realm.where(Reminder.class).findAll().deleteAllFromRealm();
        realm.where(ReminderDetail.class).findAll().deleteAllFromRealm();
        realm.commitTransaction();
    }
}
